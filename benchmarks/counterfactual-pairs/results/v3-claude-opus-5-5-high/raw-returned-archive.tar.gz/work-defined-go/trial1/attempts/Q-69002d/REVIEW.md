# Review: Address Backfill Geocoding Plan

## Checking the numbers

**Throughput and duration**
- 4 workers × 1.25 req/s = 5 req/s maximum. ✓
- 240,000 requests ÷ 5 req/s = 48,000 s ≈ 13.3 hours. ✓

**Per-second limit (20 req/s)**
- Combined peak is 5 (backfill) + 3 (signup peak) = 8 req/s, which is 40% of the limit. ✓
- This leaves 12 req/s of headroom. That margin covers:
  - **Limiter burstiness.** Workers might align, or a token bucket might allow short bursts. Even if the backfill briefly doubled to 10 req/s, the total would be 13.
  - **Signup traffic above its 6-month peak.** Signup would have to run at 15 req/s, five times its historical high, to cause a breach.

**Daily limit (1,000,000 req/day)**
- The backfill sends at most 240,000 requests in total because nothing is retried, so no single day can carry more than that from the job.
- Adding the signup peak of 50,000 gives a 290,000 worst case. This holds even if the 13.3-hour run falls entirely within one calendar day.
- That is 29% of the limit. ✓

**Request cap**
- Not retrying within the run caps the job at exactly 240,000 calls. That makes the daily bound hard rather than an estimate. ✓

## Assessment

The plan meets its own rule of never exceeding the provider's limits.
- Every figure is internally consistent.
- The limits are confirmed in writing.
- Both rate dimensions (per second and per day) are covered with large margins.
- The design choices that make the bounds provable are sound:
  - Client-side per-worker limiters
  - A fixed worker count
  - No retries

Some optional hardening would make the plan more robust, but it does not need any of these changes:
- Have the job back off if it sees HTTP 429 responses or rate-limit headers.
- Add a kill switch.
- Monitor combined account usage during the run.

VERDICT: GO