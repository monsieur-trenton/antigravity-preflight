# Review: 4.12 unique constraint on `customers (tenant_id, email)`

## What holds up

- **The opening `DROP INDEX IF EXISTS` is safe.** It does nothing on the first production run. It also makes the migration re-runnable if an earlier concurrent build failed and left an invalid index behind.
- **The build approach is right for a 38M-row table.** `CREATE UNIQUE INDEX CONCURRENTLY` followed by `ALTER TABLE ... ADD CONSTRAINT ... UNIQUE USING INDEX` avoids holding a long write lock. The attach step only needs a brief exclusive lock.
- **New duplicates can't appear during the build.** Since 4.9, writes lock the tenant row and reject an email the tenant already has.

## The problem: no one has checked the data before 4.9

The whole release depends on an assumption that hasn't been tested. If any pre-4.9 rows share a `(tenant_id, email)` pair, the index build fails with a unique violation. Under the runbook, that aborts the release and 4.12 doesn't ship.

This is a real risk. The 4.9 guard was presumably added because duplicates were possible before it. Nothing in the plan rules them out, and nothing in it handles them.

**Required change:** run the duplicate check against production (or a fresh replica) before the release window:

```sql
SELECT tenant_id, email, count(*)
FROM customers
GROUP BY tenant_id, email
HAVING count(*) > 1;
```

- **Zero rows:** the plan works as written.
- **Any rows:** the plan will fail. You'll need a separate step, done ahead of 4.12, to merge or dedupe those accounts. That is a business decision, so it shouldn't be improvised during the release.

## Smaller points to confirm

- **Transactions:** `CREATE INDEX CONCURRENTLY` can't run inside a transaction block. Check that your migration framework doesn't wrap this migration in one (many do by default).
- **Email casing and normalization:** if the 4.9 check compares emails case-insensitively but the index is on raw `email`, the index is the weaker of the two. That won't break the build. But if 4.12 sign-up relies on the constraint to catch `Foo@x.com` versus `foo@x.com`, it won't.
- **NULL emails:** a standard unique index allows multiple NULLs. That's fine unless sign-up assumes otherwise.

## Summary

The mechanics are sound. The missing duplicate check is a change the plan needs, not an optional extra, because the release depends on it. If the check finds duplicates, treat the plan as NO_GO until a cleanup step is added.

VERDICT: GO_WITH_CHANGES