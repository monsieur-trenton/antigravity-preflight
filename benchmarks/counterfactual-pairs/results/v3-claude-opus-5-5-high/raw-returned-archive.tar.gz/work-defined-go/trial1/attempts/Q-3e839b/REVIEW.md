# Review: orders-api TLS certificate and root CA rotation

The plan follows the correct order: trust first, then serve, then remove the old trust. Each step depends on a condition that is met before it starts.

**Sequencing check**

- **Day 1, new bundle with both roots.** Clients re-read the bundle every 15 minutes without closing connections. Within about 15 minutes, every client trusts both roots. Nothing changes on the server side yet, so this step carries no risk to connectivity.
- **Day 3, inventory gate.** The day 7 switch is only scheduled after the inventory shows every client's bundle hash covers both roots. This verifies the precondition on the real fleet instead of assuming it.
- **Day 7, server switches to the 2026-signed certificate with the full chain.**
  - New handshakes validate against the 2026 root, which every client now has.
  - Connections opened earlier against the 2023 certificate stay valid. That certificate is good until day 60, and bundle reloads don't close them.
  - Serving the full chain means clients don't have to build or fetch intermediates themselves.
- **Day 30, 2023 root removed from bundles and its key destroyed.** By then the server has been serving only the 2026 chain for 23 days, so no new handshake depends on 2023. Connections that have stayed open since before day 7 were already validated and aren't re-checked on reload. The 2023 certificate is also still within its validity period.
- **Rollback window.** Between days 7 and 30, the server can go back to the still-valid 2023 certificate, because clients still trust both roots.

**Shared subject name**

Both roots have the same subject name and differ only by key identifier. This is the main way the rotation could fail, because some TLS stacks pick an issuer by subject name alone. The plan covers this with a staging test: clients holding both roots accepted certificates from each one. That is the right test.

**Optional hardening (not required)**

- Make sure clients provisioned after day 1 get the dual-root bundle. Between days 30 and 60 they should get the 2026-only bundle. The plan's scope is existing clients, so this is outside it.
- Before destroying the 2023 key on day 30, confirm nothing still needs it. Examples are CRL or OCSP signing for certificates issued under 2023, or other services chained to that root.
- Run a short canary at the day 7 switch, and watch handshake-failure metrics on day 30.

None of these are needed for the plan to work as written.

VERDICT: GO