# Review: Checkout Capture Retry Plan

## What's sound

- **Retry triggers are reasonable.** Timeouts and 5xx are the usual transient failures, and the plan doesn't retry 4xx.
- **The retry cap and backoff are bounded.** Five resends wait 200, 400, 800, 1600 and 3200 ms, about 6.2 s of waiting plus per-attempt timeouts.
- **Library-level retries are disabled.** This avoids hidden extra requests multiplying the attempt count.
- **The idempotency key is well scoped.** One UUID per order, generated once and reused on every attempt, is the right design.

## The blocking problem

The plan states a hard rule: a capture must **never** take effect more than once. It also admits that a resend can reach the server after a charge already succeeded. The only thing preventing a second charge in that case is the server collapsing requests that share an idempotency key. **That behavior is unverified, and the payments team hasn't confirmed it.**

If the endpoint ignores the key, or only partly honors it, every timeout after a successful capture becomes a duplicate charge. Up to 5 extra charges are possible per order. The client side is correctly built, but sending a key does nothing unless the server enforces it. As written, the plan cannot guarantee its own core rule, and in a plausible failure mode it breaks it directly.

## Required before this can ship

1. **Get explicit confirmation from the payments team, or the API contract, that the capture endpoint deduplicates on the idempotency key.** Confirm specifically:
   - **In-flight requests:** a retry that arrives while the first attempt is still processing must be blocked or rejected, not run a second time. This matters because client timeouts fire precisely when the server is slow.
   - **Retention window:** keys must be kept at least as long as the full retry window, and ideally much longer.
   - **Replayed responses:** a replay should return the original result, so the client can tell "already captured" apart from a new failure.
   - **Key conflicts:** decide what happens if the same key arrives with a different payload.
2. **Verify it with a test.** Send duplicate captures with the same key, both sequentially and concurrently, against staging, and assert that exactly one charge results.
3. **If dedup isn't supported,** do not retry captures blindly on timeout. Instead:
   - Query capture status by order before resending, or
   - Route ambiguous timeouts to reconciliation instead of resending.

## Minor notes (non-blocking)

- Add jitter to the backoff to avoid synchronized retry storms during a payments outage.
- Log the idempotency key and attempt number on every attempt, for reconciliation.

VERDICT: NO_GO