# Review: orders-api TLS certificate and CA rotation (Internal Root 2023 → 2026)

The plan follows the standard trust-overlap sequence, and each step depends safely on the one before.

## Timeline check

- **Day 0–1:** Clients trust only 2023, and the server presents its 2023 certificate. Connectivity holds.
- **Day 1:** The bundle changes to {2023, 2026}. Clients pick it up within about 15 minutes, and open connections stay up. The server still presents the 2023 certificate, which every bundle version trusts. Connectivity holds.
- **Day 3:** Fleet inventory must show every client reporting a hash for the dual-root bundle. This gate checks what clients actually loaded, not just what was delivered. The switch can only be scheduled once no client lacks 2026.
- **Day 7:** The server presents the 2026 certificate with its full chain. Every client trusts 2026 by now. Long-lived connections made before the switch with the 2023 certificate are unaffected, because trust is checked at handshake. Connectivity holds.
- **Days 7–30:** Both roots stay trusted, so the old certificate (valid until day 60) remains available as a rollback.
- **Day 30:** 2023 is removed from the bundle. No server presents a 2023-chained certificate, so new handshakes succeed. Connections still open from before day 7 survive the reload, because reloads don't drop connections and validation happens only at handshake. Destroying the offline 2023 root key afterwards is correct hygiene.
- **Clients that join mid-rotation:** They receive whichever bundle is current, and each bundle matches what the server presents at that time.

## The identical-subject roots

Two roots with the same subject name, differing only in key identifier, is the one real hazard here. Some chain builders choose an issuer by name and can pick the wrong one. The plan addresses this: staging clients holding both roots accepted certificates from each. Sending the full chain also gives clients the correct intermediates, so they don't have to build the path themselves.

## Optional hardening (not required)

- **Restate the day-3 gate before day 7.** Confirm that no client has fallen off the dual-root hash between day 3 and the switch, for example after a config revert.
- **Check again before day 30.** Confirm that no endpoint, such as a canary, secondary listener, or load-balancer pool member, still serves a 2023-chained certificate.
- **Note the end of rollback.** After day 30, falling back to the old certificate is impossible, so you may want an explicit go/no-go before removing the old root.
- **Watch handshake-failure metrics** in the hours after day 7 and after day 30.

None of these are needed for the plan to work as written.

VERDICT: GO