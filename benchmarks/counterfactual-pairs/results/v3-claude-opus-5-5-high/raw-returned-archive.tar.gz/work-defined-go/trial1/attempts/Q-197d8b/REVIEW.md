# Review: Inventory Service Lock Plan

**Verdict: the plan cannot deadlock.**

## Why it is deadlock-free

A deadlock needs a cycle in the wait-for graph: one thread holds A and waits for B, while another holds B and waits for A. Here is every lock acquisition in the service:

| Path | Order | Nested? |
|---|---|---|
| Checkout handler | stock_mu → reserve_mu | yes |
| Restock worker | stock_mu → reserve_mu | yes |
| Nightly audit | stock_mu only | no |

- **One global order.** Both nested paths take `stock_mu` first and `reserve_mu` second. No thread ever holds `reserve_mu` while waiting for `stock_mu`, so a cycle cannot form.
- **Checkout and restock contend safely.** When they run together, one gets `stock_mu` and the other blocks on it while holding nothing. The winner gets `reserve_mu` uncontested, finishes, and releases both locks. The waiter then proceeds.
- **The audit is a leaf.** It holds only `stock_mu` and takes nothing else while holding it. It can delay other paths but cannot be part of a cycle.
- **The plan is closed.** "No other code path acquires either mutex" means these three paths are the complete set. The analysis is exhaustive.

Missing timeouts would matter if a cycle were possible. Since none is, every wait eventually ends.

## Not deadlocks, but worth knowing

- **Audit stall.** While the audit holds `stock_mu` for up to 2 seconds, every checkout and the restock worker block. That is a latency spike of up to 2 seconds per night. It resolves on its own, so it does not violate the requirement.
- **Assumptions behind "never deadlock."** The guarantee holds only if:
  - every path always releases both locks, including on errors and exceptions (use RAII/`defer`/`with`, not manual unlock calls);
  - no code inside the critical sections blocks indefinitely, such as a network call with no timeout;
  - the mutexes are not re-entered recursively on the same thread.

  None of these are stated as problems in the plan, so they are things to verify in the code, not plan defects.

## Optional hardening (not required)

- Write the lock order (`stock_mu` before `reserve_mu`) in a comment or lock-order checker so future code paths keep to it.
- Consider merging the two mutexes, or acquiring both through one helper. Both nested paths always need both locks anyway.
- Since a stuck pod passes liveness, consider a liveness probe that checks whether the lock can be acquired or whether checkouts are making progress. This guards against bugs outside this plan.
- If audit latency matters, have the audit copy a snapshot under the lock and do the slow work after releasing it.

These are robustness improvements to a plan that already works, so they do not change the verdict.

VERDICT: GO