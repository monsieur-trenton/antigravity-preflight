# Review: Address Backfill Geocoding Plan

## The core problem: per-worker caps add up to more than the contract allows

The plan's own numbers break its requirement:

- **12 workers × 5 requests per second = 60 requests per second** at the combined maximum.
- **The contract ceiling is 50 requests per second.**

The limiters are per-process and the workers don't coordinate. So whenever all 12 workers are busy at the same time, they can send up to 60 requests in a single one-second window. That is 20% over the limit. A 3.2M-row backfill keeps workers saturated for hours, so this is close to certain to happen. One such window gets the key suspended for 24 hours, which also takes down live checkout address lookups.

The other details don't help:
- Counting retries against the limiter only keeps each worker at 5/s. It does nothing about the 60/s total.
- Having no other traffic on the key just means the backfill alone causes the breach.
- The fixed worker count makes the overage predictable, not avoidable.

## Required changes (pick one)

1. **Lower the per-worker cap** so that 12 × cap ≤ 50. That means at most **4 requests per second per worker** (48/s total). Going lower, such as 3/s (36/s total), leaves margin.
2. **Use fewer workers.** At 5/s each, run no more than **10 workers**, or about 8–9 for headroom.
3. **Use one shared limiter**, such as a Redis or central token bucket, set below 50/s for all workers combined.

## Margin recommendation

Aim for about 80–90% of the ceiling (roughly 40–45/s total), not exactly 50/s. Two reasons:
- Your client's one-second windows and the vendor's measurement windows may not line up.
- Clock differences and request timing can let a sliding-window limiter release slightly more than you expect.

At 40/s, 3.2M rows take about 22 hours. At 48/s, about 18.5 hours. The small throughput gain isn't worth risking a checkout outage.

## Optional hardening

- Treat HTTP 429 responses as a signal to back off immediately, if the vendor sends them before suspending.
- Add exponential backoff with jitter on 500 retries so a vendor problem doesn't get hammered at full rate.
- Consider a separate API key for the backfill, if the contract allows, so a mistake can't affect checkout.

## Summary

As written, the workers can send 60 requests per second against a hard 50 requests per second limit. That breaks the plan's stated requirement and risks a full day of checkout downtime. The plan must be changed before it runs.

VERDICT: NO_GO