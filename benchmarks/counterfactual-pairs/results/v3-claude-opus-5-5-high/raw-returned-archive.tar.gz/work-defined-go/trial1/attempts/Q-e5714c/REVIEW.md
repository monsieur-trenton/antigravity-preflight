# Review: Date-Parsing Library Upgrade (2.8 → 3.0)

**The plan has no step showing the 14 existing callers behave the same on 3.0, which is what its own rule requires.**

## What's sound

- **Runtime compatibility:** 3.0 needs runtime 11 or later, and every billing host runs 12. No issue.
- **Archived reporting tool:** It has its own pinned copy of 2.8, is not one of the 14 callers and is not redeployed. The upgrade doesn't touch it.
- **Timing:** A 14:00 deploy leaves 12 hours before the 02:00 invoice run. That window is useful, but the plan doesn't use it for anything.
- **Motivation:** Picking up a fix the refunds module needs is a reasonable reason to upgrade.

## The blocking problem

- **The rule:** The 14 existing callers must behave exactly as they do today. Any change in their output puts wrong due dates on invoices that can't be recalled once emailed at 06:00.
- **The evidence:** None. Only the new refunds module has been run against 3.0. The 14 callers haven't been run against it at all.
- **Why this matters for a 2.x → 3.0 jump:** A major version change is exactly where changed defaults, parsing rules or behaviour are most likely. Date libraries are a common source of quiet changes, such as:
  - timezone or DST handling
  - lenient versus strict parsing
  - two-digit year handling
  - end-of-month arithmetic
  - locale defaults
- **Why it's silent:** Any of these could shift a due date without raising an error. The first sign would be wrong invoices already in customers' inboxes.
- **No safeguard:** The plan has no check that would catch a difference before 02:00, and no gate on the invoice run. As written, the plan states its central rule but does nothing to meet it.

## Required changes

1. **Run all 14 callers against 3.0 before the deploy.** Compare their output with 2.8 on representative and edge-case inputs: month ends, leap years, DST transitions, timezones and whatever input formats production actually sees. Read the 3.0 release notes and migration guide for breaking changes and check each one against the callers.
2. **Only deploy if the outputs match exactly.** If any caller differs, fix or pin that behaviour, or isolate the refunds module's use of 3.0, before shipping.
3. **Add a check before the 02:00 run (recommended).** For example, generate the night's invoice due dates on 3.0 and diff them against a 2.8 baseline. If they differ, hold the run or roll back, since there's plenty of time between 14:00 and 02:00.

VERDICT: NO_GO