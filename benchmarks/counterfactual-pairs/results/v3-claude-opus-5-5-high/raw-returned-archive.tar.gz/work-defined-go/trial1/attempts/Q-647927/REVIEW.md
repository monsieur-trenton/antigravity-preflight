# Review: Release 4.12 unique constraint on customers (tenant_id, email)

**The plan holds together.** The only thing that could stop the release is the constraint failing to apply, and nothing in the plan makes that likely.

## Why the constraint should apply cleanly

- **Duplicates before 4.9:** The `GROUP BY ... HAVING COUNT(*) > 1` check ran on the primary, so it saw current data, not a lagging replica. It returned zero rows.
- **Duplicates since 4.9:** The only write path locks the tenant row and rejects an email the tenant already has. So no new row can duplicate another new row or an older one. Pre-4.9 data plus that guarantee covers every pair.
- **Writes during the build:** Sign-ups during the concurrent build go through the same locked path, so no duplicate can appear mid-build and fail the index.
- **Matching rules:** The check and the index compare `email` the same way. The check treats NULLs as equal, which is stricter than the index, and it still found nothing.
- **Retry safety:** `DROP INDEX IF EXISTS` does nothing on the first run. If a concurrent build fails, it leaves an INVALID index behind, and this drop clears it so a rerun can start fresh. That is the right pattern.
- **Locking:** `CREATE UNIQUE INDEX CONCURRENTLY` avoids long write locks on a 38M-row table. Attaching the finished index as the constraint (`ADD CONSTRAINT ... UNIQUE USING INDEX`) needs only a brief lock.

The 4.12 sign-up code depends on the constraint existing. The abort rule guarantees the build never ships without it, so that dependency is safe.

## Optional suggestions (not required)

- Run the migration outside a transaction block. Many frameworks wrap migrations in one by default, and `CONCURRENTLY` fails inside one. If yours does, mark this migration as non-transactional.
- Set a modest `lock_timeout` on the drop and attach steps. A long-running query could otherwise make those brief locks queue behind it and stall other traffic.
- Before attaching, confirm the index is valid (`pg_index.indisvalid`), so a failure shows up as a clear error.

VERDICT: GO