# Review: orders-api TLS certificate and CA rotation

The overall sequence is sound: distribute a dual-root bundle, verify fleet-wide adoption, switch the leaf certificate, then retire the old root. But the retirement step is scheduled before the switch, which breaks the plan's own no-downtime requirement.

## Blocking issue: old root is removed while still in use

- **Day 5:** 'Internal Root 2023' is dropped from every client's trust bundle.
- **Days 5–7:** The server still presents its 'Internal Root 2023' certificate, because the switch doesn't happen until day 7.

Within about 15 minutes of the day-5 bundle change, each client re-reads its bundle. From then on, no client can chain the server's certificate to a trusted root. Already-open connections survive, since the reload doesn't close them. Every new TLS handshake fails until day 7. That is roughly two days of failed connections across the whole fleet, which violates "connectivity must never drop for any client."

**Fix:** Remove 'Internal Root 2023' only after the day-7 switch, and only once you've confirmed that:

1. every server instance is presenting the 2026 chain, and
2. no client still depends on the 2023 root.

A fleet-inventory gate, like the one used on day 3, works well here. Destroy the 2023 private key at the same point or later. Key destruction doesn't affect certificates that are already issued, but it removes your ability to reissue under the old root if you need to roll back.

## Points that are fine as written

- **Day-1 bundle with both roots, gated by the day-3 inventory:** This correctly ensures every client trusts the 2026 root before the server depends on it.
- **Same subject name, distinguished only by key identifier:** This is a known source of chain-building problems. However, staging showed clients holding both roots accepting certificates from each, and the server sends the full chain. That's adequate evidence.
- **2023 certificate valid until day 60:** This leaves plenty of room to push the root removal past day 7.

## Optional hardening

- Keep the 2023 certificate deployable as a rollback option for a defined window after day 7.
- Watch handshake-failure metrics after each step.

## Summary

The plan fails as written. Dropping the 2023 root on day 5, while the server serves a 2023-chained certificate until day 7, guarantees new-connection failures for all clients. Move the root removal and key destruction to after a verified day-7 switch.

VERDICT: NO_GO