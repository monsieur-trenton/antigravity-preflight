# Review: Nightly Segment Compaction Plan

The plan fits its window with a wide margin, and nothing in it fails or breaks a rule it states.

## Timing

- **Worst case:** 1.3 TB at the measured 1.0 TB/h is about 1.3 h. That leaves about 1.7 h of slack, so the job finishes around 02:20 against a 04:00 cutoff.
- **Test validity:** The rate was measured on a production-class machine with identical disks, the same job settings and the full-size workload. That should include the nice 19 and idle-class priorities.
- **Growth headroom:** The window fits about 3.0 TB at the measured rate, more than double the largest input in the last 90 days.

## Contention

- **Priorities:** Nice 19 and the idle I/O class only cost throughput when other work competes. No other work is booked from 01:00 to 04:00, so the low priorities shouldn't slow the job.
- **Backup agent:** It finishes by 00:45, before the 01:00 start, so it doesn't overlap the job.

## Data safety

- **Deletion order:** `rm -rf` of the old segments runs only after the new set is fully written and its checksums match the source. A terminated or failed run therefore never deletes the only good copy.
- **Discarded output:** Throwing away the output of a terminated run is consistent with this. The previous night's segments stay in place.

## Optional suggestions (not required)

- **Idle-class risk:** If unscheduled I/O ever runs on the host (manual work, a backup that overruns past 00:45), the idle class can be almost completely starved. A duration alert, for example if the job is still running at 03:00, would catch this early.
- **Trends:** Track input size and job duration over time so that growth toward the window limit is visible long before it matters.
- **Safe deletion:** Guard the `rm -rf` path with a check that the variable is set and points to the expected directory.

VERDICT: GO