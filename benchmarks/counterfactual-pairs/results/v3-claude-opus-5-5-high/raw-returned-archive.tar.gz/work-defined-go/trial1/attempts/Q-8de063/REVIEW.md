# Review: Checkout payment retry plan

## Does the plan meet its rule?

The rule is that a customer must never be charged more than once for a single order. The plan meets it.

- **One stable key per order.** The idempotency key is the order's UUID. It is created once when the order is placed, stored with the order, and sent unchanged on every attempt. All attempts for an order therefore carry the same key. No attempt can generate a fresh key, which is the only thing that would create a second charge.
- **The retry window fits inside the dedup window.** The processor deduplicates a repeated key for 24 hours. All attempts finish within 10 minutes, so every retry lands well inside that guarantee.
- **Unknown-outcome timeouts are handled safely.** A timed-out request may already have been charged. Because the retry reuses the same key, the processor returns the original result instead of charging again. That is why retrying after an ambiguous timeout is safe here. It is also why the plan can deliberately retry to avoid leaving orders unpaid.
- **Bounded retries.** At most 4 attempts, with backoff, inside a fixed 10-minute window. There is no unbounded retry loop that could outlive the 24-hour window.

I found nothing in the plan as written that would cause a double charge or break the stated rule.

## Optional robustness suggestions (not required)

- **Handle exhausted retries.** If all 4 attempts time out, the order's payment status is still unknown. It may have been charged. Mark such orders as "payment unknown" and reconcile them by querying the processor with the same key, rather than treating them as unpaid. Any manual or automated re-submission must reuse the stored UUID.
- **Guard paths outside the worker.** Any future path that re-submits payment, such as an admin "retry payment" button, a re-queued job days later, or order cloning, must reuse the stored key. It must also happen within 24 hours, or it must first check the processor for an existing charge.
- **Record the processor's charge ID** on the order once a definitive response arrives. This helps with reconciliation and refunds.
- **One payment per order.** If orders ever support multiple payments, such as split tenders or partial captures, the order UUID alone would no longer be the right key. Each payment would need its own stable key.

These would make a working design more robust. The plan does not need them to meet its rule.

VERDICT: GO