# Plan Review: Nightly Customer Export to exports-prod/nightly/

## The main problem: svc-export's write access has never been checked

Tonight's run has no margin for error:
- **It runs once.** svc-export runs at 01:00 and nothing retries a failure.
- **A failure stops the release.** The 09:00 release pipeline needs this export, so a failed run means nothing ships today.
- **The write path is untested.** Nobody has written to `exports-prod/nightly/` with svc-export's credentials, and nobody has checked its permissions on that bucket.

The bucket policy has no pending changes, but that only means the policy will stay as it is. It doesn't tell us whether the current policy lets svc-export write. If it can't, the first sign will be a failed run at 01:00, and the next sign will be a blocked release at 09:00.

I can't say the plan will fail, because the permissions may be fine. But the plan's success depends on an untested assumption, and a failure can't be recovered in time. Verifying this is a required change, not an optional extra.

**Required change before 01:00 tonight:**
1. Check svc-export's effective permissions on `exports-prod/nightly/` in the bucket policy in the infrastructure repo, plus any IAM or role policies attached to svc-export. It needs at least the put-object permission. If the export uses multipart upload, it also needs the multipart permissions (create, upload part, complete, abort). If the bucket uses customer-managed encryption, it needs the encrypt and generate-data-key permissions on that key.
2. Write and then delete a small test object under `nightly/` using svc-export's actual credentials, not a person's or an admin's.
3. Fix any gaps through the infrastructure repo before tonight's run.

## Other items to confirm

- **Release pipeline input location.** The plan doesn't say the 09:00 pipeline has been switched from the shared drive to `exports-prod/nightly/`. If it hasn't, the export could succeed and the release would still block or read stale data. The pipeline's identity also needs read access to `nightly/`.
- **Upload method for a ~30 GB object.** 30 GB is far below the 5 TB object limit, so object size is fine. But some object stores cap a single PUT well below the object maximum (S3 caps it at 5 GB). Confirm the export client uses multipart or chunked upload, which also bears on the permissions in item 1. A test with a tiny object won't reveal this.

## Points that are fine as written

- **Lifecycle rule.** Objects are deleted after 7 days, and the pipeline reads each export within 8 hours. No conflict.
- **Object size limit.** 30 GB against 5 TB leaves plenty of room.
- **Policy stability.** No pending changes before tonight means no surprise changes. It doesn't remove the need to verify the current permissions.

## Optional, not required

- Add a retry or a manual rerun procedure for the export, so one failure doesn't decide whether the day's release ships.
- Add an alert if the export hasn't finished by a set time well before 09:00, so someone can still fix it.

VERDICT: GO_WITH_CHANGES