# Review: Order Service 7.3 Release and Rollback Plan

**The plan holds up.** Each requirement it states is met by evidence in the plan itself.

- **15-minute rollback rule:** The full rollback job (down-migration plus 7.2 redeploy) was timed three times on a production-sized copy. It took 5, 6 and 6 minutes, which is less than half the limit. The job starts automatically when the release is declared failed, so no human hand-off adds delay. The timing also covers the right span: from the start of the job until 7.2 serves traffic, which is when the contract's outage clock stops.
- **Down-migration safety:** Dropping `discount_code` only removes data 7.3 created. 7.2 never reads or writes that column, so the rollback leaves 7.2 working correctly.
- **Skipping the canary:** This is reasonable. 7.2 has served all production traffic for 30 days against the same schema it will see after the column is dropped. A canary would add time without lowering any real risk.
- **Order of operations:** While the column is being dropped, 7.3 is briefly still running and will throw errors. That happens inside an outage that has already been declared and is already being timed, so it changes nothing.

## Optional hardening (not required)

1. **Lock contention under live load.** The test copy had no concurrent traffic. In production, `ALTER TABLE ... DROP COLUMN` needs an exclusive lock. If long-running transactions or a backlog of queries hold the table, the drop could wait, and on some engines queued queries pile up behind it. Setting a lock timeout with a retry, or terminating blocking sessions before the drop, would protect the 9–10 minutes of margin.
2. **Engine behavior.** Make sure the test copy used the same engine, version and table settings as production. A drop that only changes metadata on one setup can force a full rewrite of 400 GB on another. The plan's timings suggest this was handled, but it is worth confirming.
3. **Discount codes written by 7.3.** The plan is correct that 7.2 doesn't need them. Still, any codes customers applied during the 7.3 window will be lost. If the business might want them later, for example to reconcile orders, a quick `SELECT id, discount_code ... WHERE discount_code IS NOT NULL` export before the drop would keep them.
4. **Manual fallback.** Keep a documented manual path in case the pipeline itself is down when you need to roll back.

None of these fix a flaw in the plan as written. They only add robustness to a plan that already works.

VERDICT: GO