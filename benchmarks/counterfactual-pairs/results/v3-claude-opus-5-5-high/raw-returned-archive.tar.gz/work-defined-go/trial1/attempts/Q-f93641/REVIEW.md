# Review: Order Service 7.3 Release and Rollback Plan

## The core problem: the rollback can't be shown to meet the 15-minute limit

The plan states a hard rule: a failed release must be fully rolled back within 15 minutes. Missing it is a contract breach, with a fixed penalty and mandatory disclosure. The only mechanism for meeting that rule has never been timed at production scale.

The job's ordering makes this worse. It runs the down-migration first and redeploys 7.2 afterward. So the outage clock keeps running for the whole column drop on a 400 GB table. How long that takes depends on factors the plan doesn't address:

- **Engine behavior.** On some engines and versions, such as older MySQL/InnoDB or certain ALTER algorithms, dropping a column rebuilds the table. At 400 GB that takes far longer than 15 minutes.
- **Lock acquisition.** Even where the drop is metadata-only, as in PostgreSQL, it needs an exclusive lock on `orders`. It can queue behind long-running queries or transactions. While it waits, it blocks all later reads and writes on the table. During an incident this can stall indefinitely.
- **Redeploy time.** The 7.2 redeploy time at production scale is also unmeasured.

This is the plan's only path to meeting a rule it states, and nothing shows it can. I'm treating that as a blocking defect, not a hardening suggestion.

## The down-migration doesn't belong in the rollback path

The plan itself says 7.2 neither reads nor writes `discount_code`. Restoring service therefore doesn't require dropping the column. 7.2 can serve traffic with the column still present.

**Required changes:**
1. **Change the rollback job to redeploy 7.2 only.** Leave the column in place. This removes the 400 GB DDL from the 15-minute window entirely.
2. **Drop the column later, if at all,** as a separate, scheduled step after the incident, outside the contract clock. Use a lock timeout or an online schema-change tool appropriate to your engine.
3. **Time the redeploy-only rollback** against a production-sized environment, or at least time the 7.2 redeploy itself, before tonight. Confirm it fits within 15 minutes with margin, including the time to declare failure if that counts toward the clock.
4. **Confirm 7.2 tolerates the extra column.** Check for `SELECT *` mapped into strict structs, ORM schema validation at startup, or `INSERT` statements without column lists. These are usually fine, but it's a cheap check.

## Points that are fine as written

- **Skipping canary for 7.2** is reasonable. It carried all production traffic for 30 days, and adding a canary stage would eat into the 15-minute budget.
- **The automatic trigger on failure declaration** is good. It removes human latency from the clock.
- **No data loss for 7.2:** correct, given that 7.2 doesn't use the column.

## Secondary note

The forward migration also adds a column to a 400 GB table. If that runs as a blocking table rebuild, it could cause an outage during the release itself. It's worth confirming that it's an instant, metadata-only operation on your engine. This doesn't affect the rollback verdict.

## Summary

As written, restoring service depends on an untimed, potentially long-running, lock-heavy DDL operation on a 400 GB table. The 15-minute contractual limit can't be shown to hold. The fix is straightforward: take the column drop out of the rollback path and time what remains.

VERDICT: NO_GO