# Review: date-parsing library upgrade from 2.8 to 3.0

**The core problem: the plan's main promise is unverified.**
The plan requires that none of the 14 existing callers change behaviour. No step checks this. Version 3.0 has only been run with the new refunds module, which is not one of the 14. A major version bump is exactly where libraries put breaking changes. For a date parser, likely candidates are:

- default time zone or locale handling
- lenient versus strict parsing of ambiguous formats
- two-digit years
- month-end and DST arithmetic
- changed defaults in format strings

Any of these could quietly shift invoice due dates.

**Why this blocks the plan rather than just weakening it:**
- **The damage can't be undone.** The 02:00 invoice run emails customers at 06:00, and the emails can't be recalled. A behaviour change would be discovered by customers, not by us.
- **The plan sets a rule it can't show it meets.** "No caller may show any difference" is the requirement. "Ship and hope" is not a way to meet it.

**What checks out:**
- **Runtime:** version 3.0 needs runtime 11 or newer, and all hosts run 12.
- **Archived reporting tool:** its pinned 2.8 copy is separate and is not redeployed, so it is unaffected.
- **Timing:** the 14:00 deploy leaves about 12 hours before the 02:00 run. However, the plan does not use that window for any checking.

**Required changes before the 14:00 deploy:**
1. **Compare old and new output for every caller.** Run each of the 14 callers on both 2.8 and 3.0 with representative and edge-case inputs, and diff the results. Inputs should include month-ends, leap days, DST transitions, ambiguous formats and time-zone-bearing strings. Ideally, replay a real night's invoice inputs and compare the computed due dates.
2. **Read the 3.0 changelog and migration guide.** Check every breaking change against how the 14 callers actually use the library.
3. **Gate the invoice run.** Before 02:00, compare due dates computed under 3.0 with 2.8 for that night's batch, or at least sample them. Have a way to hold the 06:00 email if anything differs.
4. **Prepare a rollback path to 2.8.** Alternatively, scope 3.0 to the refunds module only, if the library can be isolated the way the archived tool's copy is.

Without step 1 at minimum, the plan can break its own stated rule, and the consequence cannot be reversed.

VERDICT: NO_GO