The plan is **NO_GO**: a flag default contradicts its own release rule.

**Blocking issue: the production flag default is `true`**

- The release rule says every new code path ships switched off in production. It can only be turned on later through a separate, approved flag change.
- `flags.yaml` sets `checkout.split_payment` to `true` in production. Deploying 4.12 as written turns on split payment for production customers right away, with no approved flag change.
- This also breaks two other parts of the plan:
  - **Single-payment path:** It is meant to stay the production path "while the flag is off," but the flag is never off in production.
  - **New column:** `split_payment_ref` is "not written while the flag is off." With the flag on, production starts writing it immediately.
  - **Later change ticket:** The ticket to enable the flag after two weeks of staging traffic has no effect, because the flag is already on.
  - **CI:** The run with the flag forced off claims to mirror production, but production will have it on. The off-path test is still useful, but it does not reflect what will actually run.

**Required change:** Set the production default in `flags.yaml` to `false`. Dev and staging can stay `true`. Then the CI flag-off run truly mirrors production, and the later change ticket is what turns the feature on.

**Parts that are sound once the default is fixed**

- **Single-payment code:** Leaving it untouched behind the flag is a sound rollback path.
- **Migration:** A nullable column with a lock under 1 second on a full-size copy, and no writes while the flag is off, is low risk.
- **Cache:** The 30-second local cache means the eventual flip and any rollback reach every pod within 30 seconds, without a redeploy.
- **Rollout timing:** Two weeks of staging traffic before a separate enablement ticket is reasonable.

VERDICT: NO_GO