**Review**

**Batch size limit.** The plan stays well under the 5,000,000-byte limit.
- The snapshot is closed and cannot change, so the scan of every record gives a real upper bound rather than an estimate. The notes field being unlimited in the source system doesn't matter, because the data being sent is fixed and has already been measured.
- 500 × 4,100 = 2,050,000 bytes, plus under 1,000 bytes of envelope and separators, gives at most 2,051,000 bytes. That is about 41% of the limit.
- Since the body is sent uncompressed, the serialized size is the size the partner sees.

**One request per batch.** Never resending is consistent with the partner's duplicate-filing rule. Nothing in the plan triggers a retry, so no duplicates are possible.

**Missing invoices.** Every batch fits, so no batch is rejected for size, and every invoice is sent. Nothing in the plan creates a gap that would fail reconciliation.

**Timeout.** 120 seconds is twice the partner's documented 60-second worst case. That makes a client-side timeout unlikely. It also matters because a timeout would leave the outcome unknown, and the plan can't resend.

**Optional suggestions** (these don't change the verdict):
- Check each batch's serialized size against the limit just before sending. This would catch a mismatch between how the scan measured records and how the job serializes them, such as different encoding or escaping.
- Log which batches were acknowledged, so that if a request ever fails or times out, someone can resolve it by hand with the partner instead of guessing.

The plan works as written and doesn't break any rule it states.

VERDICT: GO