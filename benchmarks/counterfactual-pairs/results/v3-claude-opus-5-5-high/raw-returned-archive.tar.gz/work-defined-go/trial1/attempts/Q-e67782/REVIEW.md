The plan is sound. It meets its rule that no capture is applied twice.

**Why it holds**

- **The risky case is covered.** The danger is a timeout after the server has already captured, followed by a retry. Every attempt for an order carries the same idempotency key. That key is a UUID created once with the order and never regenerated, so the retry is recognised as a repeat of the original capture.
- **The server side is verified.** The capture endpoint is idempotent per key, and the payments team confirmed this is its documented contract. A staging run backs it up: 1,000 captures sent 6 times each produced exactly 1,000 charges. Six sends is one original plus 5 retries, which matches the worst case the client can produce.
- **No hidden repeats.** The HTTP library's built-in retries are turned off, so the 5 planned retries are the only ones. There is no second retry layer that could multiply requests.
- **The retry triggers are appropriate.** Retrying only on timeouts and 5xx responses targets ambiguous or transient failures. A 4xx decline is not retried.
- **The retry window is short.** The backoff waits are 200, 400, 800, 1,600 and 3,200 ms, about 6.2 s in total. Any realistic key-retention window on the server will be much longer than that.

**Optional robustness suggestions (not required)**

- Add jitter to the backoff so retries don't all land at once during a widespread outage.
- Define what happens after the 5th retry fails. For example, mark the order as "capture unknown" and reconcile it later by querying with the same key, rather than letting it fail silently. Reconciliation must reuse the same key and never create a new one.
- Confirm that the contract also covers overlapping requests, where a retry arrives while the original is still in progress. The documented contract and staging test suggest it does.

None of these points to a flaw in the plan as written.

VERDICT: GO