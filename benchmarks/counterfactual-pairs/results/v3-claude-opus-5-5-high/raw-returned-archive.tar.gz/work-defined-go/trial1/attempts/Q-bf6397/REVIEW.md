# Review: Nightly Compaction Job Plan

The plan's mechanics are sound. Its one hard requirement, finishing inside the window, is not backed by any measurement. That gap needs fixing before the plan can be relied on.

## What holds up

- **Safe deletion.** Old segments are removed only after the new set is fully written and its checksums match the source. If a run is killed or fails, the source data survives, so there is no data-loss path.
- **No contention.** The backup agent finishes by 00:45, before the 01:00 start, and nothing else is scheduled on the host during the window. Running at nice 19 with idle I/O class costs nothing here, because there is no competing work.
- **Bounded input.** 90 days of data put daily volume between 1.0 and 1.3 TB, so the planning target is clear.

## Required change: measure throughput against the window

The plan says every run must finish within 3 hours. It also says throughput on a production-class host is unknown. Together, those mean the central requirement is unverified.

- Finishing 1.3 TB in 3 hours needs a sustained rate of about **120 MB/s** end to end. That covers reading, merging, writing, checksum verification and the `rm -rf`.
- This rate is plausible on decent storage, but it is not guaranteed. Checksumming adds a second read pass. Merge work may also be CPU-bound or limited by random I/O rather than sequential speed.
- **Change:** before go-live, benchmark a full 1.3 TB run (or a scaled run you can extrapolate from) on a production-class host. Confirm it finishes with clear headroom, for example 30% or more under 3 hours, to allow for volume growth and variance.

## Worth addressing (not blocking)

- **Missed nights.** The plan doesn't say what happens after a killed run. If the next night has to process two days of data, a single overrun could keep repeating. Define the catch-up behavior, or add an alert on kill.
- **Growth.** Volume reached 1.3 TB within the observed range. Track the trend so the headroom from the benchmark doesn't erode unnoticed.
- **Guarded `rm -rf`.** Make sure the deletion target path is validated, so it is never empty and never outside the expected segment directory, before the command runs.

The mechanics are correct and nothing shows the plan will fail. However, its stated hard constraint rests on an unmeasured number, and measuring it is a needed change rather than an optional one.

VERDICT: GO_WITH_CHANGES