# Review: Address Backfill Geocoding Plan

**The plan stays within the contracted rate. Peak load is 40 requests per second against a limit of 50.**

## Checking the rate limit

| Factor | Value |
|---|---|
| Workers (fixed for the whole run) | 8 |
| Limit per worker, in any one-second window | 5 req |
| **Most requests possible in any one-second window** | **8 × 5 = 40 req** |
| Contracted limit | 50 req/s |
| Headroom | 10 req/s (20%) |

Each part of the plan closes off one way the limit could be exceeded:

- **No coordination between workers.** This is fine because each worker's limit is enforced on its own. The 40 req/s ceiling holds even if all 8 workers burst at the same moment.
- **The limiter covers "any one-second window."** This means it is a sliding-window limit, not one tied to the clock's second boundaries. Two bursts on either side of a boundary therefore can't combine to exceed 5. It also means the vendor's window alignment doesn't matter.
- **Retries draw from the same limiter.** A wave of HTTP 500s therefore can't add traffic beyond the worker's rate.
- **The worker count is fixed.** No autoscaling or restart can add a ninth worker partway through.
- **No other users of the key.** The full 50 req/s belongs to the backfill, and the plan uses only 40 of it.

Every request the vendor could see from this key is accounted for, and the worst case stays under the limit. The requirement is met.

## Optional suggestions (the plan works without these)

1. **Network timing.** The limiter measures when requests are sent, but the vendor counts when they arrive. Network delays could bunch requests from consecutive windows into one vendor second. The 10 req/s of headroom should absorb normal variation. If you want more margin, set each worker to 4 req/s, for a total of 32.
2. **Stop on HTTP 429.** If the vendor returns a rate-limit warning before suspending the key, have workers pause or stop when they see it.
3. **Run time.** At 40 req/s, 3.2M rows take about 80,000 seconds, roughly 22 hours. Plan for checkpointing and resuming so a crash doesn't force you to redo finished rows.
4. **Retry backoff.** Retries are already rate-limited, so this is about efficiency, not safety. Adding backoff keeps a vendor outage from using up the run's capacity on repeated 500s.

VERDICT: GO