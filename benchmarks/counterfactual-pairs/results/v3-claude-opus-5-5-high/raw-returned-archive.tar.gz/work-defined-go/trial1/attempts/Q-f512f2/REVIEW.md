# Review: Address Backfill Geocoding Plan

**Verdict: the arithmetic is correct, but the plan cannot show it meets its own central requirement.**

## What holds up

- **Throughput and duration:** 4 workers × 1.25 req/s = 5 req/s. 240,000 ÷ 5 = 48,000 s ≈ 13.3 h. Correct.
- **Combined peak rate:** 5 req/s from the job plus a 3 req/s historical signup peak gives 8 req/s.
- **Daily total:** The run is shorter than a day but may cross midnight. Its whole volume could still land in one calendar day, so 240,000 + 50,000 = 290,000 is the right worst case.
- **Job volume cap:** Not resending failed lookups does keep the job at 240,000 requests or fewer.

## The blocking problem

The plan says the account must stay within the provider's rate limits **at all times**, because a breach suspends the account and breaks live signup lookups. But:

- Nobody has confirmed which limits apply to the account.
- The plan contains no limit figures.

So "8 req/s peak, 290,000/day" is never compared to anything. The plan can't show it satisfies the rule it treats as non-negotiable, and the stakes are high. Many geocoding tiers sit at or below these numbers, for example:

- 5 req/s or fewer per account, which 8 req/s would exceed.
- Daily caps of 100k or 250k requests, which 290,000 would exceed.

If either kind of limit applies, the run breaches it and takes signup down with it. Running the job as written is a gamble on an unknown number, which fails the plan's own "at all times" requirement.

## Required changes

1. **Get the account's actual limits** from the provider or the account dashboard, in writing. Cover every window they enforce: per-second, per-minute, daily, and monthly. Also find out how they count failed or errored requests.
2. **Put those figures in the plan** and show that each one is above the combined load:
   - 8 req/s peak
   - 290,000/day
   - the monthly total, meaning 240,000 plus about a month of signup traffic
   
   Leave real headroom, since the 3 req/s and 50k/day signup figures are historical peaks, not guarantees.
3. **Lower the job's rate if the numbers don't fit.** For example, reduce the per-worker limit or spread the run across days so its daily share stays under the cap.

## Worth adding (not blocking)

- Check that the client-side limiter is smooth, not bursty. If the provider enforces per-second windows strictly, a token bucket that allows bursts could briefly exceed 1.25 req/s per worker.
- Consider a global kill switch: pause the job automatically if signup lookup errors rise or the provider returns 429s.
- Because failures aren't retried, record the failed address IDs so a later, separately rate-checked pass can geocode them.

VERDICT: NO_GO