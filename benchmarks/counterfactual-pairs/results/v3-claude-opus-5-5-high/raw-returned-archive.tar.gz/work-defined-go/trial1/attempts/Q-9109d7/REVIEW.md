# Review: Orders PostgreSQL Point-in-Time Recovery Plan

**Recovery point objective (5 minutes).** Each WAL segment is archived within 60 seconds of being written. The newest restorable point is therefore at most about a minute old, which meets the 5-minute requirement.

**Recovery window (14 days).**
- **Worst case:** The worst-case target is 14 days back, just before a Sunday 02:00 backup. Restoring it needs the previous week's base backup, which is about 21 days old, plus all WAL from then onward.
- **Long-running backup:** A target that falls during a running base backup must use the prior backup. That pushes the requirement only to about 21 days plus the backup's duration.
- **Retention covers it:** Base backups and WAL are both kept for 28 days. That leaves about a week of margin, so the slack in a nightly deletion run doesn't matter.
- **Both pieces kept equally:** Base backups and WAL share the same retention. No base backup is left without the WAL it needs.

**Deletion safety.**
- The lifecycle job can delete, but its rule only matches objects older than 28 days. Nothing inside the needed 21-day window is at risk.
- The backup bucket sits in a separate account, and the database hosts can only write new objects. A compromised or faulty database host cannot overwrite or delete backups.

**Verification.** The monthly rehearsal restores to a random point 13–14 days back. That is the deep end of the window, where the oldest base backup and the longest WAL replay are exercised. It tests the hardest case regularly.

**Optional hardening (not required):**
- Alert on gaps in WAL archiving and on base backups that fail or are missing. A silently skipped Sunday backup would stretch the required chain to about 28 days, right at the retention limit.
- Occasionally rehearse a restore to a recent point too, to confirm the 5-minute end of the window.
- Record the restore duration during rehearsals, to track recovery time.

The plan meets every requirement it states, and none of its pieces contradict each other.

VERDICT: GO