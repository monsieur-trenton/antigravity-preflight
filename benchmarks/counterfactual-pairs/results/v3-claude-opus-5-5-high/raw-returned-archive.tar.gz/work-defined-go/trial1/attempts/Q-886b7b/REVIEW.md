# Review: Tenant-Scoped Dashboard Cache

## Isolation analysis

The plan meets its isolation rule.

- **The tenant is in the key.** Dashboard 42 in tenant A is `dash:A:42:{range}`, and in tenant B it is `dash:B:42:{range}`. These are different keys, so the per-tenant ID numbering cannot cause collisions.
- **The tenant_id comes from a trusted source.** The gateway authenticates the caller and attaches tenant_id. The client does not supply it, so a caller cannot pick another tenant's namespace.
- **Every lookup is scoped to the caller.** The handler only reads or writes the key built from the current request. A caller in tenant B can therefore only reach `dash:B:*` keys.
- **Leaving out the user ID is correct.** Every dashboard is visible to all users in its tenant, so sharing a cache entry within a tenant exposes nothing a user couldn't already see. The isolation rule is about tenants, not users.
- **The shared Redis cluster is fine.** Isolation comes from the key namespace, and the handler never builds a key for another tenant.

## Freshness

The 300-second TTL and delete-on-edit keep data reasonably fresh. Neither affects isolation.

## Optional hardening (not required)

1. **Delimiter safety.** Keys are joined with `:`. If tenant_id and `range` could both contain `:`, two different tuples could produce the same string. For example, tenant `a:1` / dash `2` / range `x` and tenant `a` / dash `1` / range `2:x` both give `dash:a:1:2:x`. This only matters if tenant IDs are free-form and `range` is unvalidated input. Validating `range` against an allowlist or a strict format (which you likely want anyway), or encoding the components, removes the risk.
2. **Invalidating every range.** "Deletes its cached entries" means removing all `range` variants for a dashboard. Do this with a known set of ranges, a per-dashboard index set, or a version counter in the key. Avoid `KEYS`/`SCAN` on a shared cluster.
3. **Stale write after edit.** A request that started before an edit can finish afterward and write old data back into the cache. A version or generation number in the key prevents this. The worst case without it is one stale entry for up to 300 seconds, within the same tenant.
4. **Changing visibility later.** If per-user or per-role permissions on dashboards are ever added, the key will need a user or permission component. Writing that assumption down near the key-building code would help.

None of these are needed for the plan to work or to meet its isolation rule as described.

VERDICT: GO