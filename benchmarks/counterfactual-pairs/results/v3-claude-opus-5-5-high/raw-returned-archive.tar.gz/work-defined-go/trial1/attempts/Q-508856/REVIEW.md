# Review: Checkout capture retry plan

## What holds up

- **Stable idempotency key.** One UUID per order, created once and reused on every attempt, is the right design. It gives the server what it needs to collapse duplicates.
- **No hidden retries.** Turning off the HTTP library's built-in retries keeps the retry count bounded and visible. Without this, retries could multiply (5 × library retries).
- **Retry triggers.** Retrying on timeouts and 5xx responses, and not on 4xx, is sensible.
- **Backoff.** Delays of 200, 400, 800, 1600 and 3200 ms add about 6.2 s of waiting. That is reasonable for a checkout flow.
- **Known risk.** The plan correctly states that a timeout can occur after the capture has been applied.

## The blocking problem

The plan's safety rests on one assumption: that the capture endpoint treats repeated requests with the same idempotency key as a single capture. The plan says this **has not been checked and the payments team has not confirmed it.**

The plan itself describes how a double charge would happen:

1. Attempt 1 reaches the server and the capture is applied.
2. The response is lost or slow, and the client times out.
3. The client retries with the same key.
4. If the server does not deduplicate on that key, it applies a second capture and charges the customer again.

The same applies to a 5xx returned after the capture was committed, for example a failure while writing the response or in a downstream step. Up to 5 retries means up to 6 charges for one order in the worst case.

Sending an idempotency key does nothing unless the server enforces it. As written, the plan cannot guarantee its own rule that no capture is applied twice. On the ordinary timeout path it will break that rule if the assumption is false. This is the core of the design, not an optional hardening step.

## Required before this can proceed

1. **Get written confirmation from the payments team** that the capture endpoint deduplicates on the idempotency key. Specifically, confirm:
   - which header or field carries the key;
   - how long keys are retained, which must exceed the full retry window;
   - what happens to a request that arrives while the first one is still in flight (it should get a 409 or wait, not run a second capture);
   - that a replayed request returns the original result.
2. **Verify it in a test environment.** Force a timeout after the capture commits, then confirm that a retry with the same key produces one charge.
3. **If dedup is not supported,** do not retry blindly on timeout or 5xx. Instead, look up the order's capture status (or reconcile) before any retry, or get the payments team to add idempotency support.

## Optional, once the above is resolved

- Add jitter to the backoff to avoid synchronized retry bursts.
- Treat an idempotency-conflict response (such as 409 or 422) as "already processed or in progress" rather than as a failure.
- Log the idempotency key with every attempt so double-charge investigations can be traced.

VERDICT: NO_GO