# Review: Shared Redis cache for rendered dashboards

## The blocking problem: the cache key has no tenant

The key is `dash:{dashboard_id}:{range}`, but dashboard IDs are only unique within a tenant. The plan itself says ID 42 exists in many tenants and points to different data in each. So:

1. A caller in Tenant A requests dashboard 42 with range `7d`. The handler renders it and caches it under `dash:42:7d`.
2. Within 300 seconds, a caller in Tenant B requests their own dashboard 42 with range `7d`. The handler derives the same key `dash:42:7d`, gets a cache hit, and returns Tenant A's rendered dashboard.

This directly breaks the stated isolation rule. It isn't a rare edge case. Low IDs like 1, 2, 3 exist in nearly every tenant, so collisions will be constant on a shared cluster.

The plan's safeguards don't help:
- **Gateway authentication and tenant stamping** are correct, but the tenant_id never reaches the key, so the cache can't use it.
- **Touching only the key derived from the request** doesn't prevent this. The derived key is the problem.
- **Leaving out the user ID** is fine on its own, since access is tenant-wide. It just means the tenant has to be in the key instead.

## A second effect: invalidation crosses tenants

Editing dashboard 42 in Tenant A deletes `dash:42:*`. That evicts every tenant's dashboard 42. This doesn't leak data, but tenants affect each other's cache hit rates. It would also hide the fact that entries are being shared. The fix below solves this too.

## Required change

Put the gateway-stamped tenant in the key, for example `dash:{tenant_id}:{dashboard_id}:{range}`. Apply the same scoping to invalidation: an edit in tenant T should delete only `dash:{T}:{dashboard_id}:*`.

Two notes on doing this:
- Take `tenant_id` only from the gateway-stamped value. Never take it from a client-supplied parameter.
- If `range` comes from user input, normalize or validate it, and make sure no key component can contain the `:` delimiter. Otherwise one key's components could be shifted to match another key. This hardening matters less once tenant_id comes from a trusted source.

## Optional suggestions (not required)

- **Invalidation without key scans.** Deleting `dash:{T}:{id}:*` needs a SCAN or a list of known ranges. On a cluster, SCAN has to run on every node. Two alternatives: keep a per-dashboard set of cached range keys, or put a per-dashboard version number in the key so an edit just bumps the version.
- **Hash tags.** On Redis Cluster, a hash tag like `dash:{T:42}:7d` puts all ranges for one dashboard on the same slot. That makes multi-key deletes simpler.
- **Isolation test.** Add a test that renders the same dashboard ID and range in two tenants and checks that the responses differ. This catches any future change that drops the tenant from the key.

## Summary

The plan sends one tenant's cached dashboards to other tenants whenever their dashboard IDs and ranges match. This happens routinely and violates the plan's own isolation rule. Adding the gateway-stamped tenant_id to the key and to invalidation fixes it.

VERDICT: NO_GO