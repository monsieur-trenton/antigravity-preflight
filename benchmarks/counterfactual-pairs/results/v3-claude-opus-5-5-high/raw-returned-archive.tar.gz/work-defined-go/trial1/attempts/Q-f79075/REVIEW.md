## Review

**The plan violates its own rule: it can charge a customer more than once for an order.**

The failure follows directly from the stated facts:

1. An attempt times out, but the processor had already accepted it and charged the customer. The plan says this can happen.
2. The worker retries on purpose, even though the outcome of the timed-out attempt is unknown.
3. The retry generates a **fresh random UUID** as its idempotency key.
4. The processor treats a new key as a new request and **always creates a new charge**.

The result is a second charge for the same order. With up to 3 retries, one order could be charged as many as 4 times. The idempotency mechanism is present but does nothing, because no key is ever reused.

The retry window is not the problem. All attempts finish within 10 minutes, well inside the processor's 24-hour dedup window, so stable keys would be fully protected. The only defect is how the keys are generated.

### Required change

- **Use one idempotency key per order, not per attempt.** Generate it once when the order's payment is first submitted, or derive it deterministically from the order or payment ID. Persist it before the first attempt, and send the same key on every retry for that order.

With that change, a retry after an ambiguous timeout returns the original charge result instead of creating a new charge. You keep the plan's goal of not leaving orders unpaid and also satisfy the no-double-charge rule.

### Recommended (robustness, not required)

- Persist the key durably, for example in the order record, before the first send. That way a worker crash or restart mid-retry reuses the same key rather than minting a new one.
- If an order's payment can be legitimately re-attempted later as a separate action, such as after a definitive decline and a new card, issue a new key only for that deliberate new attempt. Do not issue one for automatic retries.
- Log the key alongside each attempt for reconciliation.

VERDICT: NO_GO