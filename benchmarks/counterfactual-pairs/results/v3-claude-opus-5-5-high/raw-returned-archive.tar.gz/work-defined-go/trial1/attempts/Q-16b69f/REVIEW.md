# Review: Point-in-Time Recovery Plan for the Orders Database

The plan works as written. Each requirement it sets is met by the mechanisms it describes.

**Recovery window, 14 days back to 5 minutes ago**
- **Recent end:** every WAL segment lands in the archive within 60 seconds of being written. That leaves the newest recoverable moment about 1 minute behind, well inside the 5-minute target.
- **Old end:** the plan correctly reasons that a target 14 days back may need a base backup up to 21 days old. With weekly Sunday backups, the latest backup before any moment is at most 7 days older than it. So 14 + 7 = 21 days is the worst case.

**Retention**
- Base backups and WAL are both kept for 28 days, which covers the 21-day worst case with a 7-day margin.
- The nightly deletion job only selects objects older than 28 days. It therefore never removes the base backup or WAL that a 14-day recovery needs.
- Because WAL is kept as long as base backups, a chain is never left with a backup but no WAL to replay.

**Protection against loss or tampering**
- The bucket sits in a separate account.
- Database hosts can add objects but cannot overwrite or delete them. A compromised or faulty host cannot destroy the recovery chain.
- The only deleter is the lifecycle job, and its rule is limited to objects past retention.

**Testing**
- The monthly drill restores to a random moment 13 to 14 days back. That is the hardest part of the window, where the base backup can be up to 21 days old and the WAL replay is longest. It checks the backup chain and retention in practice, not just on paper.

**Optional improvements (not required)**
- Also restore to a recent moment, around 5 to 10 minutes ago, during some drills. This checks the recent end of the window.
- Alert if WAL archiving lags or a Sunday base backup fails. A missed backup pushes the worst case to 28 days, which is exactly the retention limit.
- Make sure the WAL upload command treats an already-uploaded, identical segment as success. Otherwise, after a retry, add-only permissions could block it and stall archiving.
- Confirm `archive_timeout` is set, so segments close and ship promptly when there is little write activity.

VERDICT: GO