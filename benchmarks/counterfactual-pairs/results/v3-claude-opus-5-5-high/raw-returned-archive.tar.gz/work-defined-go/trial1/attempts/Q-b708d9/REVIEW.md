# Plan Review: Split-Payment Flow (Checkout 4.12)

## Blocking issue: the production flag default contradicts the release rule

The plan states two incompatible things:

- **The rule:** "any new code path goes to production disabled, with activation coming afterwards solely via its own approved flag change."
- **The config:** "In flags.yaml the default is true for dev, true for staging and **true for production**."

If 4.12 ships with `checkout.split_payment: true` for production, the split-payment path goes live the moment the release deploys. That breaks the rule directly. It also undermines several other parts of the plan:

1. **"Production customers keep going through [single-payment] as long as the flag is off."** The flag won't be off, so customers would hit the new path immediately.
2. **"No writes reach [`split_payment_ref`] with the flag off."** With the flag on, writes to the new column start at deploy time, not after a reviewed activation.
3. **"Switching the flag on in production is deferred to a subsequent change ticket once staging has carried two weeks of traffic."** Nothing would be left to switch on. The two-week staging soak and the separate change ticket would be skipped.
4. **The staging CI "mirroring production."** The forced-off pass is meant to reflect production's state. With production defaulting to true, the enabled pass is what actually reflects it, and the safety claim the off pass supports is false.

**Required fix:** Set the production default in `flags.yaml` to `false`. Dev and staging can stay `true`. Add a pre-deploy check that the production value is `false` in the release artifact, such as a CI assertion on `flags.yaml`.

## Parts of the plan that hold up (once the default is fixed)

- **Flag gating with an unchanged single-payment path** is a sound way to isolate risk.
- **The nullable column migration** was tested on a full-size staging copy, with a lock under 1 second. Adding a nullable column with no default is typically metadata-only and low-risk.
- **The 30-second per-pod cache** gives a bounded propagation window for both enabling and rolling back, with no redeploy.
- **Running the CI suite with the flag both on and off** is good coverage.
- **A separate, approved change ticket after a two-week staging soak** is the right activation process.

## Optional suggestions (not required)

- Write down the rollback procedure: flip the flag off, then wait up to 30 seconds. Also say what happens to in-flight split payments when the flag flips off mid-checkout.
- Consider a percentage or cohort rollout when production is eventually enabled, rather than turning it on for everyone at once.

## Summary

The plan's design is reasonable, but the production default of `true` means it would ship the new code path enabled. That violates the plan's own rule and invalidates its safety claims about production behavior.

VERDICT: NO_GO