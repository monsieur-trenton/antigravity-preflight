# Review: Address Backfill Geocoding Plan

## The core problem: the rate limits don't add up

The plan's worst-case aggregate rate exceeds the contract:

- **12 workers × 5 req/s per worker = 60 req/s possible**
- **Contract ceiling: 50 req/s**

The workers share no coordination, so nothing stops all 12 from using their full 5 requests in the same one-second window. Steady throughput isn't required. One window where every worker is at its cap puts 60 requests on the key, 10 over the limit. That suspends the key for 24 hours and takes down live checkout address lookups.

This is not an unlikely edge case. A job pulling from a 3.2M-row backlog keeps every worker saturated, so each limiter runs at its cap nearly all the time. Overlapping full windows are the normal state, not a rare one.

## What the plan gets right

- **Retries share the limiter.** HTTP 500 retries can't push traffic above the per-worker cap. This closes a common way rate limits get exceeded.
- **The worker count is fixed.** No autoscaling can raise the total during the run.
- **The key is exclusive.** No other traffic needs to be budgeted.

These make the arithmetic above the complete picture. The only problem is that 12 × 5 > 50.

## Required change

Make the worst-case total at or below 50, preferably with headroom:

- **Lower the per-worker cap to 4 req/s.** 12 × 4 = 48, which leaves a 2 req/s margin. This is the smallest change.
- **Or reduce to 10 workers at 5 req/s.** That is exactly 50 with zero margin, so I don't recommend it.
- **Or use a shared limiter** (for example, a Redis token bucket) set somewhat below 50 req/s across all workers. This is more work but uses the budget better.

## Recommended hardening (after the fix)

- **Leave headroom for timing differences.** Client-side windows don't line up perfectly with the vendor's measurement windows. Network jitter can bunch requests that left evenly. A total target of about 40–45 req/s is safer than exactly 50.
- **Handle HTTP 429 or near-limit signals.** If the vendor sends them, workers should back off instead of continuing.
- **Add a kill switch or rate monitor** so the job can be stopped quickly if aggregate traffic looks wrong.

At 48 req/s, 3.2M rows take about 18.5 hours. Lowering the target to around 40 req/s adds roughly 3.5 hours, which is a small cost against a full-day checkout outage.

## Summary

As written, the plan allows 60 req/s against a 50 req/s hard limit. Exceeding that limit suspends the key, which breaks the stated requirement and live checkout. The fix is simple, but it is required.

VERDICT: NO_GO