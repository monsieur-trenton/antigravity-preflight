**Review: Release 4.12, split-payment flow behind `checkout.split_payment`**

**Release rule: new code paths ship off in production**
- `flags.yaml` sets the production default to `false`, so the split-payment path is off at deploy.
- Turning it on requires a separate change ticket, which matches the "separate, approved flag change" requirement.
- The single-payment path is untouched and remains the production path while the flag is off.
- The rule is met as written.

**Schema change (`split_payment_ref`)**
- A nullable column add is backward-compatible. Existing single-payment code doesn't need to know about it.
- The lock measured under 1 second on a full-size staging copy, so production risk is low.
- The column isn't written while the flag is off, so production data doesn't change before enablement.
- This is a schema change, not a code path, so shipping it unflagged doesn't break the release rule.

**Flag propagation**
- With a 30-second local cache, enabling (or killing) the flag reaches all pods within 30 seconds without a redeploy. That's acceptable both for rollout and as a kill switch.

**Testing**
- Staging defaults the flag on, so CI's second run with the flag forced off is the right way to mirror production.
- Running both modes covers the new path and confirms the old path still works with the new code and column present.

**Rollout**
- Two weeks of staging traffic before a separately ticketed production enablement is a sound, conservative sequence.

**Optional suggestions** (they make the plan sturdier but aren't required):
- Write down the rollback stance for the column. Leaving it in place on rollback is fine because it's nullable and unused.
- When enabling in production, decide how to handle requests in the up-to-30-second window where pods disagree. For example, make sure a split payment started on one pod can be finished or read on a pod that still sees the flag off.
- Make sure monitoring and alerts for the split-payment path exist before the enablement ticket.

Nothing in the plan will fail or violate its stated rule, and none of the suggestions above is a needed change.

VERDICT: GO