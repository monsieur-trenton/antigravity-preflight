# Review: Inventory Service Locking Plan

## Blocking issue: lock-order inversion causes deadlock

The two write paths take the same two mutexes in opposite orders:

| Path | First lock | Second lock (while holding first) |
|---|---|---|
| Checkout | `stock_mu` | `reserve_mu` |
| Restock | `reserve_mu` | `stock_mu` |

This is a textbook AB/BA deadlock. One bad interleaving is enough:

1. The checkout thread acquires `stock_mu`.
2. The restock thread acquires `reserve_mu`.
3. Checkout blocks waiting for `reserve_mu`, which restock holds.
4. Restock blocks waiting for `stock_mu`, which checkout holds.

Both threads wait forever. The plan's own facts guarantee this will eventually happen in production:

- **No timeouts.** Neither acquire can give up and back off, so a deadlock is permanent.
- **Constant overlap.** Checkouts arrive continuously, restock fires every 30 seconds, and the plan says the two often run simultaneously on separate threads. The window is small but is hit over and over, so it is a matter of when, not if.
- **The failure is the one the plan forbids.** The requirement says a deadlock is never acceptable. Once deadlocked, every later checkout also queues behind `stock_mu`. The pod passes its liveness probe while selling nothing, until someone restarts it by hand.

So the plan as written breaks its own stated rule.

## What is fine

- **The nightly audit** takes only `stock_mu`, holds it for at most 2 seconds, and never requests another lock. A thread that holds one lock and waits for none cannot be part of a wait cycle. It only adds a short delay for checkout and restock.
- **No other acquisition sites** exist, so the checkout/restock pair is the only cycle to fix.

## Required change

Use one global lock order for both multi-lock paths. The smallest fix is to change restock to match checkout:

- **Restock:** acquire `stock_mu`, then `reserve_mu`. Add delivered units, prune expired reservations, then release both.

With every path that needs both locks taking `stock_mu` before `reserve_mu`, no wait cycle can form. That removes the deadlock and meets the requirement.

Document the order next to the mutex declarations, for example "always `stock_mu` before `reserve_mu`", so future code follows it.

## Optional hardening (not required for correctness)

- **Merge the locks.** If nothing ever needs only one of them, a single mutex guarding both counts removes the ordering hazard entirely.
- **Enforce the order in code.** A helper that acquires both locks in the correct order, or debug-build lock-order assertions, would prevent regressions.
- **Improve the liveness probe.** The probe currently cannot detect a hang. Having it check that the lock can be acquired, or that checkouts are making progress, would catch any future hang instead of reporting the pod healthy.

VERDICT: NO_GO