# Review: Checkout 4.12 Split-Payment Rollout

The plan works and follows its own rule. I found nothing that would cause it to fail.

## Checks against the stated rule ("new code ships disabled to production; activation only via its own approved flag change")

- **Production default.** flags.yaml sets `false` for production. The new path ships dark, as the rule requires.
- **Activation.** Turning the flag on is a separate change ticket, gated on two weeks of staging traffic. This matches "solely via its own approved flag change."
- **Existing behaviour.** The single-payment code is unchanged, and production traffic stays on it while the flag is off. The release changes nothing for customers until the flag is flipped.

## Technical points

- **Schema change.** Adding a nullable column is backward compatible. Old and new pods can run side by side during the rollout, and a rollback to 4.11 is safe with the column still present. The lock time (under 1 second) was measured on a full-size staging copy, so it should hold in production. No writes reach the column while the flag is off.
- **Flag propagation.** A 30-second per-pod cache means a flip takes effect, or can be reversed, within 30 seconds without a redeploy. That gives a quick kill switch after activation. Some pods will briefly disagree during the window. That is acceptable as long as each request is handled by one pod.
- **Test coverage.** CI runs the checkout suite twice, once with the flag on and once forced off. The off pass mirrors production as configured, and the on pass covers the future state. Both paths are exercised before release.

## Optional suggestions (not required)

- Write down in the activation ticket how to roll back after activation. For example: what happens to orders that already have `split_payment_ref` set if the flag is turned off partway through a split checkout.
- Add a monitor or alert that confirms there are zero split-payment writes in production while the flag is off. This would catch a misconfigured default.
- Confirm that the migration runs with a lock timeout. Then if production lock contention turns out worse than in staging, the migration fails fast instead of queueing behind long transactions.

These suggestions would make a working plan more robust. None of them is needed for the plan to work.

VERDICT: GO