## Review

**The plan can deadlock.** The checkout handler and the restock worker take the same two locks in opposite orders:

| Path | First lock | Second lock (while holding first) |
|---|---|---|
| Checkout | `stock_mu` | `reserve_mu` |
| Restock | `reserve_mu` | `stock_mu` |

The bad interleaving looks like this:
1. A checkout thread acquires `stock_mu`.
2. The restock worker acquires `reserve_mu`.
3. Checkout blocks waiting for `reserve_mu`, which restock holds.
4. Restock blocks waiting for `stock_mu`, which checkout holds.

Several facts in the plan make this outcome possible and permanent:
- **No timeouts.** Both locks block forever, so neither thread backs off.
- **The paths overlap.** The plan says they regularly run at the same moment on different threads, so this will happen in production.
- **Nothing detects it.** A stuck pod still passes its liveness probe, so it stays wedged until someone restarts it by hand.
- **It spreads.** Every later checkout queues on `stock_mu` behind the stuck thread, so the whole service stops selling.

This breaks the plan's own requirement that the service "must never deadlock."

**Audit job:** This path is fine. It takes only `stock_mu` and acquires nothing else while holding it, so it cannot join a cycle. Its 2-second hold only adds latency. If the ordering bug is fixed, it is harmless.

## Required change

Use one global lock order everywhere. Have the restock worker acquire `stock_mu` first, then `reserve_mu`, matching checkout. Release order doesn't matter for deadlock, but releasing in reverse order is conventional. Two alternatives would also work:
- Merge the two mutexes into a single lock, since every path that needs both always takes both together.
- Use a scoped multi-lock primitive, such as C++ `std::scoped_lock(stock_mu, reserve_mu)`, which avoids deadlock internally.

## Optional hardening (not required once the ordering is fixed)
- Write the lock order down in a comment next to the mutex declarations, and add a debug-mode lock-order checker or a lint rule so a future code path can't reintroduce the inversion.
- Make the liveness probe exercise a path that takes the locks, or add a watchdog on lock wait time, so any future hang gets restarted automatically.

VERDICT: NO_GO