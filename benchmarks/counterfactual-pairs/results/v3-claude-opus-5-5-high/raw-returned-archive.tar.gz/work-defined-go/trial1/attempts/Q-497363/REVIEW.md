# Review: 4.12 unique constraint on customers (tenant_id, email)

The plan holds up. The main risk is that duplicates would make the index build fail and abort the release, and the stated facts rule that out.

## Duplicate coverage
- **Rows created before 4.9:** The `GROUP BY tenant_id, email HAVING COUNT(*) > 1` check on the production primary returned zero rows.
- **Rows created from 4.9 on:** One code path writes all emails. It locks the tenant row and rejects any email the tenant already holds, including emails on pre-4.9 rows. So no new duplicate can form among post-4.9 rows or between a pre-4.9 row and a post-4.9 row.
- **Writes during the build:** The same code path covers rows written while `CREATE UNIQUE INDEX CONCURRENTLY` runs, so the build should not hit a uniqueness violation.
- **Matching rules:** The check groups on the raw column values, which is the same comparison the unique index uses. Case or collation differences cannot cause a mismatch. NULLs never conflict under a unique index.

## Migration mechanics
- **`DROP INDEX IF EXISTS`:** This does nothing on the first run. On a retry, it removes the INVALID index that a failed concurrent build leaves behind, so the step makes reruns safe.
- **Index build:** `CREATE UNIQUE INDEX CONCURRENTLY` on 38M rows avoids a long write lock. Attaching the index with `ALTER TABLE ... ADD CONSTRAINT ... UNIQUE USING INDEX customers_tenant_email_uq` needs only a brief lock and no second scan.
- **Sign-up behavior:** 4.12 sign-up depends on the constraint existing. Because the release aborts if the constraint fails, 4.12 code never runs without it.

## Optional hardening (not required)
- Run the concurrent index statement outside a transaction block. Many migration frameworks wrap migrations in a transaction by default.
- Set a `lock_timeout` on the `ADD CONSTRAINT` step so it cannot queue behind a long-running transaction.
- Re-run the duplicate query across all rows just before the release. It is cheap insurance against an unknown writer, such as a manual fix or an import script.

VERDICT: GO