# Review: Nightly Compaction Job Plan

The plan holds together: every stated constraint is met with margin.

**Runtime vs. window**
- The worst observed volume is 1.3 TB. At the measured 1.0 TB/hour, that takes about 1.3 hours, against a 3-hour hard window.
- That is roughly 2.3× headroom. Volume could grow to about 3 TB before the window is at risk, far above the 90-day range of 1.0–1.3 TB.
- The throughput figure is credible. It came from a full-size rehearsal on a production-class host with the same disks and the same job settings, not from a small sample or a vendor spec.

**Priority and contention**
- Nice 19 with the idle I/O class can slow the job if competing I/O appears. However, nothing else is scheduled on the host between 01:00 and 04:00.
- The backup agent finishes by 00:45, before the job starts.
- The rehearsal used the same settings, so the low priority is already reflected in the 1.0 TB/hour figure.

**Kill and data safety**
- A killed run discards its partial output.
- The old segments are removed only after the new set is fully written and its checksums match the source.
- So a failed or killed run never loses the source data. Deletion happens only after verification succeeds.

**Optional hardening (not required)**
- Alert on runtime, for example above 2 hours, and on the daily input size, so growth or an unexpected I/O neighbour shows up before it threatens the 04:00 kill.
- Alert if the backup agent hasn't finished by 01:00, since the plan relies on it being done.
- Log and alert on any killed run or checksum mismatch, so a missed night doesn't go unnoticed.

None of these are needed for the plan to work as written.

VERDICT: GO