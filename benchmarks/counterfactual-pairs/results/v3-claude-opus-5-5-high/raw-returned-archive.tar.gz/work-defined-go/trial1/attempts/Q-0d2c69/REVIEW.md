# Review: Shared Redis Cache for Dashboard Responses

## The blocking problem: the cache key has no tenant in it

The plan's own facts produce a cross-tenant leak:

1. **One Redis cluster serves every tenant**, so all tenants share one keyspace.
2. **Dashboard IDs repeat across tenants.** Dashboard `42` exists in many tenants, each with different data.
3. **The key is `dash:{dashboard_id}:{range}`.** It has no `tenant_id`, so tenant A's dashboard 42 and tenant B's dashboard 42 map to the same key, for example `dash:42:7d`.

Here is how a leak happens:

- A user in tenant A loads dashboard 42 for range `7d`. The handler misses, renders tenant A's data, and writes it to `dash:42:7d`.
- Within the next 300 seconds, a user in tenant B loads their own dashboard 42 for `7d`. The handler builds `dash:42:7d`, gets a hit, and returns **tenant A's data to tenant B**.

That breaks the stated isolation rule. None of the other safeguards prevent it:

- **Gateway authentication** correctly identifies the caller's tenant, but the key never uses that `tenant_id`.
- **"Only reads or writes the key built from the current request"** doesn't help, because the key built for tenant B's request is the same as tenant A's.
- **The 300 s TTL** only limits how long a leaked entry survives. It doesn't stop the leak.
- **Omitting user ID** is fine on its own, since dashboards are tenant-wide. The problem is that the tenant was omitted too.

## A second problem: invalidation affects the wrong tenants

"Any edit to a dashboard deletes its cached entries at once" will delete by `dash:42:*`. With unscoped keys, that has two effects:

- An edit in tenant A evicts entries for dashboard 42 in every other tenant. That is wasted work and invites cache stampedes.
- Worse, if tenant B's stale or foreign entry sits under that key, the behavior depends on which tenant happens to repopulate it next. This is the same collision showing up again.

## Required changes

1. **Put the tenant in the key**, taken from the gateway-attached `tenant_id` and never from client input:
   `dash:{tenant_id}:{dashboard_id}:{range}`
   With Redis Cluster, consider a hash tag such as `dash:{t123}:42:7d` if you want one tenant's keys on one slot. Watch for hot-tenant skew if you do.
2. **Scope invalidation to the tenant**: delete `dash:{tenant_id}:{dashboard_id}:*`. Prefer tracking the exact keys, for example in a per-dashboard set, over using `SCAN`/`KEYS` patterns.
3. **Fail closed.** If `tenant_id` is missing or empty when the handler builds a key, skip the cache entirely rather than writing to a key like `dash::42:7d`.
4. **Add a test** in which two tenants request the same dashboard ID and range, and assert that each gets only its own data.

## Optional hardening (not required)

- Normalize and validate `range` before it goes into the key, so arbitrary strings can't be used for key injection or to bloat the cache.
- Version the key prefix (`dash:v1:...`) so a format change doesn't read old entries.
- Optionally store `tenant_id` inside the cached value and check it on read, as a defense-in-depth assertion.

## Summary

As written, the plan will serve one tenant's dashboard to another whenever their dashboard IDs and ranges match, which is common because IDs start at 1 in every tenant. That directly violates the plan's isolation rule. The fix is small: add `tenant_id` to the key and to invalidation. But the plan is not safe to ship until that change is made.

VERDICT: NO_GO