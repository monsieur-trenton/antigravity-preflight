# Review: Order Service 7.3 Release Rollback Plan

**The plan works as written.** The stated rule is a complete rollback within 15 minutes of declaring failure. The job starts automatically on declaration, so no human hand-off delay is added. It was timed end to end at production size (5, 6 and 6 minutes), measured up to 7.2 serving traffic, which is the same endpoint the contract uses. That leaves about 9 minutes of margin. The down-migration is safe for 7.2 because 7.2 never touches `discount_code`. Skipping the canary for a version that carried all traffic for 30 days is reasonable.

## Optional suggestions

None of these are required.

1. **Lock contention under live load.** The timing runs were on a copy with no traffic. In production, dropping the column needs an exclusive lock on `orders`. It can queue behind long-running transactions and block other queries while it waits. Setting a lock timeout with retries on the down-migration would keep it inside the window.
2. **Discount data written by 7.3 is lost.** Dropping the column discards any discount codes recorded while 7.3 was live. That doesn't matter to 7.2, but finance or support might want those values. Copying them out before the drop, or just deferring the drop, would avoid the loss.
3. **Detection time.** If the contract's outage clock starts when customers are first affected rather than at declaration, time spent deciding to declare failure eats into the margin. Agreeing on clear failure criteria in advance keeps that decision fast.
4. **Order of steps.** If 7.3 has no hard dependency on the column, you could restore 7.2 first and drop the column later. That takes the migration off the critical path entirely.

VERDICT: GO