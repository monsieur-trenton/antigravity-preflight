# Review: Release 4.12 unique constraint on customers (tenant_id, email)

## What's sound

- **Index build method.** `CREATE UNIQUE INDEX CONCURRENTLY` followed by attaching the index as the constraint is the right pattern for a 38M-row table. It avoids a long write-blocking lock.
- **Leading `DROP INDEX IF EXISTS`.** It does nothing on the first run in production. It is still useful: if a concurrent build fails, Postgres leaves behind an INVALID index with the same name, and this step clears it so the migration can be re-run.
- **No new duplicates since 4.9.** The tenant-row lock plus the duplicate refusal means the build shouldn't fail because of new writes while it runs.

## The gap: pre-4.9 data has never been checked

The plan's success depends on one unverified assumption: that rows created before 4.9 contain no duplicate (tenant_id, email) pairs. Nothing in the plan establishes this. Until 4.9 there was apparently no guard against duplicates, and no duplicate query has been run.

If even one duplicate pair exists:
- the concurrent build fails, possibly after a long scan of 38M rows;
- it leaves an INVALID index behind;
- under the runbook's rule, the whole 4.12 release aborts.

That is a costly way to find out something one query can answer. The plan doesn't *necessarily* fail, so it isn't NO_GO. But it shouldn't proceed while its outcome is a coin flip on unknown data.

## Required changes

1. **Run a duplicate check against production (or a fresh replica) before release day:**
   ```sql
   SELECT tenant_id, email, count(*)
   FROM customers
   GROUP BY tenant_id, email
   HAVING count(*) > 1;
   ```
2. **If duplicates exist, add a remediation step before the index build**, such as merging or renaming the duplicate accounts, with product sign-off on which record survives. Once the check is clean, the plan works as written.

## Worth confirming (not blocking on their own)

- **Email normalization.** The 4.9 code path may compare emails case-insensitively or trimmed while the index compares raw values. In that case the constraint will be weaker than what sign-up expects. `Foo@x.com` and `foo@x.com` would both be allowed, and the 4.12 "clear error" wouldn't fire for them. Decide whether the index should be on `lower(email)`, and if so run the duplicate check on that expression too.
- **Transaction wrapping.** `CREATE INDEX CONCURRENTLY` cannot run inside a transaction block. Make sure the migration tool runs this migration without wrapping it in a transaction.
- **Lock and statement timeouts.** Set `lock_timeout` for the drop and attach steps, and make sure `statement_timeout` won't kill the long build.

VERDICT: GO_WITH_CHANGES