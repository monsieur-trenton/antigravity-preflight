# Review: Address Backfill Geocoding Plan

The plan stays within the provider's stated limits at all times, so it needs no changes.

## Checking the numbers

| Claim | Check | Result |
|---|---|---|
| Job throughput ≤ 5 req/s | 4 workers × 1.25 req/s = 5 req/s | ✅ |
| Runtime ≈ 13.3 h | 240,000 ÷ 5 = 48,000 s ≈ 13.33 h | ✅ |
| Combined peak 8 req/s | 5 (job) + 3 (signup's 6-month max) = 8 | ✅ |
| Per-second limit | 8 vs. 20 req/s, which leaves 12 req/s (60%) of headroom | ✅ |
| Worst single day ≤ 290,000 | Even if the whole run falls in one day: 240,000 + 50,000 = 290,000 | ✅ |
| Daily limit | 290,000 vs. 1,000,000, about 29% of quota | ✅ |
| Job total capped at 240,000 | No retries, so no extra requests | ✅ |

The arithmetic holds. Both limits have a wide margin, and the daily figure assumes the worst case, where the whole run lands in one calendar day. If the run spans two days, each day's total is lower.

## The stated rule

The rule is to stay within rate limits at all times so signup lookups are never cut off. The plan meets it:

- The per-second ceiling is enforced by limiters on each worker, not just assumed from average throughput.
- Signup traffic is accounted for using observed historical peaks, not averages.
- Not retrying failures removes the most common way backfill jobs exceed their planned volume.
- The limits come from the provider in writing.

## Optional hardening (not required)

These would add robustness but are not changes the plan needs:

- **Limiter burst behavior:** If the client-side limiter is a token bucket with a burst allowance, check that the burst size is small. With 12 req/s of headroom this is very unlikely to matter.
- **Kill switch:** Make it easy to pause the job if signup traffic spikes well above its historical peak or the provider starts returning 429s.
- **Failure log:** Record failed lookups so a later, separately planned run can handle them.

VERDICT: GO