# Plan Review: Month-End Invoice Batch Posting

The plan works as written: every request stays far under the size limit, and the timeout covers the partner's stated response time.

## Request size
- **Limit:** the partner refuses any request whose body exceeds 5,000,000 bytes.
- **Worst case per batch:** 500 records × 4,100 bytes = 2,050,000 bytes, plus under 1,000 bytes of envelope and separators. That gives about 2,051,000 bytes at most, roughly 41% of the limit.
- **Uncapped notes field:** this would normally be the main risk. Here it is handled because:
  - the input is the closed snapshot, which cannot change after close;
  - every record was scanned, so 4,100 bytes is the true maximum for this input, not an estimate;
  - the size was measured as serialized bytes, not characters, so multi-byte text is already counted;
  - batches are sent uncompressed, so measured size equals sent size.

## Single submission and reconciliation
- No batch is ever refused for size, so the no-resend rule never forces a missing invoice.
- The ceiling of about 2.05 MB is well below the limit, so reconciliation is not put at risk by batch size.

## Timeout
- The timeout is raised to 120 seconds, against the partner's stated maximum of 60 seconds.
- That margin means a slow but successful answer will not be cut off. This matters because a cut-off answer could not be retried without risking a duplicate filing.

## Optional suggestions (not required)
- Keep a pre-send size check on each serialized batch as a guard in case the scan and the send ever use different code paths.
- Have a manual process for confirming status if a request ever goes past 120 seconds with no answer.

VERDICT: GO