**Review: orders-api TLS certificate and CA rotation**

The plan works as written. Each step depends on the one before it, and none of them leaves a client unable to validate the certificate being presented.

**Step by step**

1. **Days 1–7: both roots trusted, old certificate presented.** Clients reload the bundle in place every 15 minutes without dropping connections. The old root stays in the bundle, so the certificate still being presented keeps validating. Adding a root cannot break validation.

2. **Day 3: inventory check.** This confirms every client has the dual-root bundle before the switch is scheduled. That closes the main risk of this kind of rotation: a client that missed the update and would reject the new certificate. Day 3 also leaves a long margin over the 15-minute reload cycle.

3. **Day 7: switch to the new certificate.** Every client already trusts 'Internal Root 2026', so new handshakes succeed. Connections opened before the switch stay up, because reloads don't drop them. Sending the full chain means clients don't need to fetch or cache any intermediates.

4. **Same subject name, different key identifier.** This is the usual trap: some TLS stacks pick a trust anchor by name and fail on the wrong one. Here, staging clients with both roots accepted certificates from either root. That is direct evidence the client software matches on key identifier or tries every candidate.

5. **Day 30: old root removed, its key destroyed.** The server stopped presenting the old certificate on day 7. Removing 'Internal Root 2023' therefore affects nothing currently in use. Destroying a root key that has been offline and unused is safe. The old certificate's day-60 expiry doesn't matter, because nothing presents it after day 7.

**Optional suggestions (not required)**

- Between day 7 and day 30, confirm through handshake logs or metrics that no client is still connecting under the old chain, for example through a lagging load balancer or a second listener.
- Note that after day 30 you can no longer roll back to the 2023 certificate. Any rollback plan should cover only days 7–30.

VERDICT: GO