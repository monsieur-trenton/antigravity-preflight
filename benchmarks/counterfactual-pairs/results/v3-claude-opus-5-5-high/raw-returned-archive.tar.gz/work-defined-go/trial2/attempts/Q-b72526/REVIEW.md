## Review: Release 4.12, split-payment flow

**Release rule compliance.** The rule requires every new code path to ship switched off in production and to be turned on only through a separate, approved flag change. The plan meets both parts:
- `flags.yaml` sets `checkout.split_payment` to false in production.
- Production enablement is deferred to its own change ticket after two weeks of staging traffic.

**Production behaviour while the flag is off.** The single-payment code is untouched and remains the live path. Customers should see no change on deploy.

**Schema change.** The `split_payment_ref` column is nullable, which makes it additive and backward-compatible. The lock lasted under 1 second on a full-size staging copy, so measured risk is low. Nothing writes to the column while the flag is off. It is a schema addition rather than a new code path, so shipping it ahead of the flag does not break the rule. It also means the later flag flip needs no migration.

**Flag propagation.** A 30-second local cache means the eventual flip, or an emergency flip back to off, reaches every pod within 30 seconds without a redeploy. That is a reasonable rollout and kill-switch window.

**Testing.** Running the checkout suite in staging with the flag on and again with it forced off covers both the new flow and the production configuration. This closes the usual gap where staging only exercises the flag-on path.

**Optional suggestions** (not required):
- Write down the expected kill-switch latency (up to 30 seconds) in the enablement ticket's rollback section.
- Consider a deploy-time check that the production value in `flags.yaml` is false, so a later edit to the file can't silently enable the flow.

The plan works as written and is consistent with its stated rule.

VERDICT: GO