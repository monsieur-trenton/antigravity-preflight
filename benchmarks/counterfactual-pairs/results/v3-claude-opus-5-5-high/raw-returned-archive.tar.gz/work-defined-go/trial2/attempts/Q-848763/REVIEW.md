# Review: Inventory Service Locking Plan

## Critical issue: lock-order inversion causes deadlock

The two write paths take the same two mutexes in opposite orders:

| Path | First lock | Second lock (while holding first) |
|---|---|---|
| Checkout | `stock_mu` | `reserve_mu` |
| Restock | `reserve_mu` | `stock_mu` |

This is the textbook deadlock pattern. One interleaving is enough:

1. A checkout thread acquires `stock_mu`.
2. The restock worker acquires `reserve_mu`.
3. Checkout blocks waiting for `reserve_mu`, which restock holds.
4. Restock blocks waiting for `stock_mu`, which checkout holds.

All four Coffman conditions hold:
- **Mutual exclusion:** both locks are mutexes.
- **Hold-and-wait:** each path keeps its first lock while requesting the second.
- **No preemption:** acquisition "blocks indefinitely with no timeout."
- **Circular wait:** the opposite orders create the cycle.

The plan itself says the two paths "often run simultaneously on separate threads," so this is not a theoretical edge case. Restock runs every 30 seconds against continuous checkout traffic, so the window recurs about 2,880 times a day. The pod will eventually hang. It will keep passing its liveness probe while selling nothing, which is exactly the outcome the stated requirement forbids.

## Audit job: fine

The nightly audit holds only `stock_mu`, for at most 2 seconds, and never requests another lock. It cannot join a cycle. It only adds bounded latency to checkout and restock. No change needed there.

## Required change (pick one)

1. **Use one global lock order (simplest).** Have restock acquire `stock_mu` first, then `reserve_mu`, the same order as checkout. Pruning expired reservations and adding delivered units work in either order, so nothing is lost. Document the order ("`stock_mu` before `reserve_mu`, always") next to the mutex declarations.
2. **Merge into one mutex** guarding both counts. Both write paths always need both locks anyway, so the split buys almost no concurrency. A single lock removes the possibility of inversion entirely.
3. **Try-lock with backoff:** acquire the first lock, try-lock the second, and on failure release everything, back off, and retry. This works but is more complex and can livelock. It is inferior to options 1 or 2 here.

## Worth adding (optional, not required for correctness)

- A readiness or health check that detects stuck lock waits, such as a watchdog on lock-hold duration. That way a future regression gets a restart instead of a silent hang.
- Splitting restock so pruning happens in a separate, shorter critical section, which reduces how long checkout is blocked.

## Summary

As written, the plan contains a guaranteed-reachable deadlock between checkout and restock. That directly violates its own requirement that a deadlock is never acceptable. Making the lock order consistent fixes it.

VERDICT: NO_GO