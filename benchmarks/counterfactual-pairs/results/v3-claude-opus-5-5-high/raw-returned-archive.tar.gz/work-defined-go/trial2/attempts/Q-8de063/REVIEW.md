# Review: Checkout Payment Retry Plan

**The plan satisfies its rule. A customer cannot be charged twice for one order through this retry path.**

## Why it holds

- **The key never changes.** The order UUID is created once, stored with the order, and sent unchanged on every attempt. Every retry for an order is the same request to the processor.
- **Every retry is inside the dedup window.** All attempts finish within 10 minutes, and the processor deduplicates for 24 hours. A retry always finds the original result instead of creating a new charge.
- **The unknown-outcome timeout is handled.** If the first attempt was charged but the response was lost, the retry gets back the original result and no second charge happens. That is what makes the deliberate retry after a timeout safe.
- **Retries after failures are also safe.** A retry after a recorded failure either returns the original result or processes the request for the first time. Neither case produces a second charge.

## Optional suggestions (not required)

These only make the plan more robust. They don't fix a defect.

1. **Prevent concurrent submissions.** If two worker instances could ever process the same order at once, the shared key still prevents a double charge. A lock or claim on the order would still avoid wasted calls and confusing logs.
2. **Plan for a later retry with a new key.** If someone later adds "retry payment after a decline" (for example, with a new card), that flow would need a new key. Keep it explicitly separate so nobody starts generating new keys in this retry path.
3. **Alert on unresolved outcomes.** If all 4 attempts time out, the order's payment status is unknown. Flag it for reconciliation against the processor, querying by the order's key, rather than leaving it to a manual retry that might use a new key.
4. **Make the time bound enforceable.** The 10-minute bound is what keeps retries inside the 24-hour window. A simple guard that refuses to resubmit an order older than the window would make that guarantee explicit.

VERDICT: GO