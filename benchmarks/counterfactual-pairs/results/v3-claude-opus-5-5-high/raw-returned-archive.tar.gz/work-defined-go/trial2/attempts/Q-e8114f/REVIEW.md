# Review: Per-Request Logging for the Payments Gateway

## Blocking issue: bearer tokens get logged in plaintext

The plan's redaction list does not match its own credential rule.

- **The rule:** logs must never contain bearer tokens, API keys, passwords or session cookies.
- **Bearer tokens are always present:** every caller sends one in the `Authorization` header on every request.
- **All headers are logged at INFO**, with only `Cookie` and `X-Api-Key` redacted.
- **Production runs at INFO**, so this logging is active in production.

So every production request writes a live bearer token, `Authorization: Bearer <token>`, into the logs. That breaks the stated rule directly.

The exposure is serious:
- Logs go to a shared cluster that every engineer in the company can search.
- Tokens are kept there for 90 days.
- These are working credentials for a payments service.

**Required fix:** add `Authorization` to the redacted headers. Also redact `Proxy-Authorization`, which carries credentials the same way.

## Recommended hardening (not blocking once the above is fixed)

- **Use an allowlist instead of a denylist.** Log only the headers known to help with tracing, such as `User-Agent`, `Content-Type`, `Content-Length` and `X-Forwarded-For`. This plan shows how a denylist fails: one missed header leaks every token. An allowlist also covers custom or future auth headers like `X-Auth-Token` and `X-Session-Id`.
- **Match header names case-insensitively** when redacting. HTTP header names are case-insensitive, so `authorization` and `cookie` must be caught too.
- **Consider `Set-Cookie`** if response headers will ever be logged.
- **Clean up after any test deploy.** If this logging has already run in any environment, purge the affected logs and rotate the exposed tokens.

## Parts that are fine

- **Path without query string:** this avoids tokens or keys passed as query parameters.
- **No bodies at any level:** this rules out passwords or card data from payloads.
- **Request ID:** a random 128-bit value from the gateway is safe to log and is a good correlation key.
- **Method, status and latency:** these meet the tracing goal and carry no credentials.

## Conclusion

As written, the plan logs every caller's bearer token in plaintext to a company-wide searchable store. That breaks the plan's own credential rule, so it cannot ship until `Authorization` is redacted.

VERDICT: NO_GO