# Review: date-parsing library upgrade from 2.8 to 3.0

## What holds up

- **Runtime prerequisite:** Version 3.0 needs runtime 11 or newer, and every billing host already runs 12.
- **Archived reporting tool:** It keeps its own pinned 2.8 copy, sits outside the 14 callers and is not redeployed, so the upgrade can't affect it.
- **Timing:** The 14:00 deploy leaves about 12 hours before the 02:00 invoice run. That is enough time to notice problems and roll back before anything reaches customers.
- **Motivation:** The refunds module needs a fix from 3.0, and that module has been run on 3.0.

## The blocking problem: the plan's own rule is never checked

The plan's central rule is that none of the 14 existing callers may change behaviour. Nothing in the plan checks this.

- **The risk is real.** Going from 2.8 to 3.0 is a major-version jump. Major versions are where libraries are allowed to break things, and date parsing is especially prone to quiet changes: lenient versus strict parsing, time-zone and DST defaults, two-digit years, locale handling, and month or day ordering.
- **None of the 14 callers has run on 3.0.** The only code tested on 3.0 is the new refunds module, which says nothing about the code paths that calculate invoice due dates.
- **The failure would be silent and permanent.** A parsing change doesn't crash. It produces a plausible but wrong date, and those invoices go to customers at 06:00 with no way to recall them.

As written, the plan ships an unverified major-version change into an irreversible, customer-facing path while claiming no behaviour will change. It cannot meet its own stated rule.

## Changes needed before the 14:00 deploy

1. **Read the release notes.** Check the changelog and migration guide from 2.8 to 3.0 for behaviour changes, and match each one against how the 14 callers use the library.
2. **Run the existing callers on 3.0.** Run each caller's existing tests against 3.0. Better still, do a side-by-side comparison: feed the same real inputs (for example, last night's invoice data) through 2.8 and 3.0 and diff the outputs, especially the due dates. Any difference fails the rule.
3. **If gaps appear:** If differences show up, or some callers have no test coverage, either fix them or keep those callers on 2.8 while refunds uses 3.0. Don't deploy until the comparison comes back clean.
4. **Optional extra safeguard:** Do a dry run of the invoice job after the deploy, or hold the 06:00 email until due dates have been spot-checked. This is a nice addition, not a substitute for steps 1–3.

Once the comparison shows identical output for all 14 callers, the plan is sound.

VERDICT: NO_GO