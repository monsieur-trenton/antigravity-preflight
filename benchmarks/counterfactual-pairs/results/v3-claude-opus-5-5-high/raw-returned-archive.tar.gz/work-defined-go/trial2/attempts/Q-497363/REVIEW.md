## Review

**Duplicate data (the main risk to the release):** The plan covers this.
- **Rows created before 4.9:** The query on the production primary returned zero duplicate pairs.
- **Rows written since 4.9:** Every email write goes through one code path. That path locks the tenant row and rejects an email the tenant already holds. Because of the lock, two concurrent sign-ups cannot both pass the check. A new row also cannot duplicate an older pre-4.9 row, since the check covers all of the tenant's existing emails.
- **Overall:** Together these cover every row in the table, so the unique index build should not hit a duplicate-key failure. That failure is the one that would abort the release.

**Index build mechanics:** The design is sound.
- **Concurrent build:** `CREATE UNIQUE INDEX CONCURRENTLY` avoids blocking writes for long on a 38M-row table.
- **Leading drop:** `DROP INDEX IF EXISTS` does nothing on the first run. On a retry it is useful: a failed concurrent build leaves an INVALID index behind under the same name, and the drop clears it so the retry can proceed.
- **Attaching the constraint:** `ALTER TABLE ... ADD CONSTRAINT ... UNIQUE USING INDEX` only needs a brief lock, because the index already exists and has been validated.

**App dependency:** 4.12 sign-up relies on the constraint only after it exists. The constraint is applied as part of the release, so the code and the schema arrive together.

**Optional hardening (not required):**
- Make sure the migration tool runs this step outside a transaction block. Both `CREATE INDEX CONCURRENTLY` and `DROP INDEX CONCURRENTLY` refuse to run inside one. Many frameworks wrap migrations in a transaction by default, so it is worth confirming the step is marked non-transactional.
- After the build, confirm `pg_index.indisvalid` is true before attaching the constraint.
- Re-run the duplicate check over all rows just before the migration, as a cheap sanity check.
- Make sure statement and lock timeouts allow enough time for a long concurrent build.

None of these are needed for the plan to work as described.

VERDICT: GO