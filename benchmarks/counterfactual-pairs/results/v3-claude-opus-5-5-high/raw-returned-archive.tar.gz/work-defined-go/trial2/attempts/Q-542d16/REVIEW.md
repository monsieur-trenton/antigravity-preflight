# Review: moving the nightly customer export to exports-prod/nightly/

## Main gap: svc-export's write access is unverified

Tonight's run depends on something nobody has checked, and a failure costs a full day:

- **The dependency:** svc-export must be able to write to `exports-prod/nightly/`. No one has tried a write with its credentials, and no one has reviewed its permissions on the bucket.
- **The cost of failure:** The export runs once at 01:00 with no retry. The 09:00 release consumes it, so a failed export means nothing ships that day.
- **What the plan offers instead:** "No pending change to the bucket policy" only means access won't change. It doesn't tell us access exists. This is the old shared drive's first night on a new destination, so missing write access is a realistic risk.

I can't say the plan *will* fail, because svc-export may already have the access it needs. That is why this isn't NO_GO. But leaving the one unverified dependency on a single-shot, release-blocking path untested isn't optional. It's a change the plan needs before tonight.

## Required change (before 01:00 tonight)

1. **Test the write as svc-export:** Using svc-export's actual credentials (not an admin's), write a small test object to `exports-prod/nightly/`, then delete it. Also check the access the run needs beyond a simple put:
   - If the 30 GB upload uses multipart, confirm the multipart permissions (create, upload part, complete, abort).
   - Check any encryption key permissions if the bucket uses one.
   - Check any required headers or ACL conditions in the bucket policy.
2. **If the test fails:** Fix the policy in the infra repo before 01:00, or keep tonight's export going to the old shared drive and move tomorrow.

## Recommended, not strictly required

- **A fallback for tonight:** Have someone on call to rerun the export manually if it fails, or set a check well before 09:00 (e.g., 03:00) that confirms the object landed in `nightly/` and alerts if it didn't. Even a 01:00 failure leaves hours to recover if someone knows about it.
- **Point the pipeline at the new location:** Confirm the 09:00 release pipeline reads from `exports-prod/nightly/` and has read access there. Otherwise the export can succeed and the release still breaks.

## Points that check out

- **Lifecycle rule:** Objects expire after 7 days and the pipeline consumes each export within 8 hours. No conflict.
- **Object size:** About 30 GB against a 5 TB per-object limit. No issue.
- **Bucket policy stability:** No pending or scheduled changes, so whatever you verify today will still hold at 01:00.

VERDICT: GO_WITH_CHANGES