# Review: Nightly Compaction Plan

## Blocking issue: nothing shows the job fits in the window

The plan sets a hard rule: **every nightly run must finish inside the 3-hour window**, because a killed run throws away its output. It also says throughput on a production-class host **has not been measured**. So nothing supports the claim that the job can meet its own rule.

The required rate is not small:

- 1.3 TB in 3 h (10,800 s) needs about **120 MB/s sustained**, with no headroom.
- A merge reads and writes the full volume, so that is at least about 240 MB/s of combined disk traffic.
- Checksumming the new set against the source likely adds another full read of both, which could push total I/O to about 3–4× the data size.
- Volume is already near the top of its 90-day range, and any growth eats margin that was never measured.

On some hosts this is easy. On others, such as HDD-backed or busy shared storage, it fails every night. As written, the plan can't show it will meet its own rule. And if it misses, the cost repeats: each killed run produces nothing. The plan also doesn't say what happens to the next night's input. If two days of segments pile up, the next run is even less likely to fit.

**Required changes:**
1. Benchmark the full job on a production-class host with a 1.3 TB input, or larger to allow for growth. Include the merge and the checksum verification.
2. Set a minimum safety margin, for example a worst-case runtime of no more than about 2 h. Make go-live depend on meeting it.
3. Define what happens after a killed run: alerting, and how the missed day is handled.

## Points that hold up

- **Nice 19 and idle I/O class:** This only slows the job when other work competes. The plan says nothing else runs from 01:00 to 04:00, so this doesn't threaten the window.
- **Backup agent:** It finishes by 00:45, before the 01:00 start, so the two don't overlap.
- **Deletion safety:** `rm -rf` runs only after the new set is fully written and its checksums match the source. A kill before that point leaves the original segments in place, so a killed run loses no data.

## Optional (not required)

- Add a pre-flight check that skips or alerts if the input is far above the measured safe size.
- Log runtime every night so you can see the margin shrinking before it runs out.

## Conclusion

The data-safety design is sound. But the plan's central requirement, finishing within 3 hours every night, rests on a throughput figure nobody has measured, and a miss means the run is wasted. The plan can't be approved until that is measured and shown to fit with margin.

VERDICT: NO_GO