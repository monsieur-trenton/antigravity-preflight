# Review: Order Service 7.3 Release and Rollback Plan

## Does the plan meet its stated rule?

The rule is that 7.2 must serve traffic again within 15 minutes of the release being declared failed. The plan meets it.

- **Timing:** The rollback job starts automatically at declaration, so no human reaction time is added. Three full runs on a production-sized copy took 5, 6 and 6 minutes. That is consistent and leaves about 9 minutes of headroom.
- **What the timing covers:** It was measured end to end, from job start until 7.2 was serving traffic. It therefore includes both the down-migration and the redeploy.
- **Correctness of the down-migration:** Dropping `discount_code` removes nothing 7.2 depends on, since 7.2 never reads or writes it.
- **Skipping the canary:** This is justified. 7.2 has 30 days of full production traffic behind it, and a canary would only add time to the rollback.

I found nothing in the plan that would cause it to fail or break the 15-minute rule.

## Optional suggestions (these do not change the verdict)

1. **Redeploy 7.2 before dropping the column.** 7.2 ignores `discount_code`, so it can serve traffic with the column still present. If you redeploy first and drop the column later, the outage clock stops sooner. The column drop also stops being on the contractual critical path.
2. **Set a lock timeout on the drop.** The test copy had no live traffic. In production, `DROP COLUMN` needs an exclusive lock and could queue behind long-running transactions, blocking other queries while it waits. A `lock_timeout` with retry, or suggestion 1, removes this risk.
3. **Decide whether to keep the discount codes.** Any codes recorded on orders while 7.3 was live are lost when the column is dropped. This doesn't affect 7.2. If finance or support might need those codes, copy them out before the drop.

VERDICT: GO