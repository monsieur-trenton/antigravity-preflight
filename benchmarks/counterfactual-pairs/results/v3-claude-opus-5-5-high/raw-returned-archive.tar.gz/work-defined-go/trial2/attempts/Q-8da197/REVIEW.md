# Review: orders-api TLS certificate and CA rotation

The plan has an ordering error that will cause an outage. It breaks the plan's own rule that "no client may lose connectivity at any point."

## Blocking issue: the old root is removed before the server switches

Here is the timeline as written:

| Day | Event | Server presents | Client trust bundle |
|---|---|---|---|
| 1 | Bundle updated to both roots | cert from 2023 | 2023 + 2026 |
| 3 | Inventory confirms both roots fleet-wide | cert from 2023 | 2023 + 2026 |
| **5** | **2023 removed from bundle, key destroyed** | **cert from 2023** | **2026 only** |
| 7 | Server switches to 2026 cert | cert from 2026 | 2026 only |

From day 5 to day 7, the server presents a certificate that chains only to Internal Root 2023. Clients reload their bundle every 15 minutes, so within about 15 minutes of the day-5 change, no client trusts that certificate. Every new TLS handshake fails for about two days. Open connections survive the reload, but reconnects and new connections do not.

The plan also cannot recover from this. The 2023 private key is destroyed on the same day, so it cannot issue anything to bridge the gap. The only fix is to rush the day-7 cutover forward during the outage.

**Required change:** Remove Internal Root 2023 only after the server is presenting the 2026-issued certificate and that change is confirmed. For example:
- Day 7: switch the server to the 2026 cert. Verify that clients are successfully handshaking against it, using handshake error rates and the chain observed from several clients.
- Day N > 7: remove 2023 from the bundle. Use the day-3 inventory gate again to confirm every client reports the 2026-only bundle hash.
- Only after that, and after a soak period, destroy the 2023 private key. Until then it remains your only rollback option.

The same-day removal on day 5 needs to be fixed even beyond the ordering. Destroying the key in the same step as the bundle change leaves no recovery path if anything goes wrong.

## Points that are fine

- **Adding the new root first (day 1) with an inventory gate (day 3):** This is the correct pattern. The gate confirms the bundle actually landed rather than assuming the 15-minute reload worked.
- **Same subject name, different key identifier:** This can confuse chain building in some TLS stacks. The staging test, with clients holding both roots and accepting certs from either, directly covers it, so I don't consider it a blocker. To be more robust, check that the client TLS libraries in production match the ones tested in staging.
- **Full chain on day 7:** Good. This avoids failures on clients that can't build the chain from the root alone if an intermediate is involved.
- **Old cert valid until day 60:** There is plenty of margin; expiry is not a factor.

## Summary

The overall approach is sound: overlap the trust, verify, switch, then retire. However, the retire step on day 5 is scheduled before the switch on day 7. As written, this causes a fleet-wide outage of about two days for new connections, and destroying the key at the same time makes it unrecoverable. Move the root removal and key destruction to after a verified day-7 cutover.

VERDICT: NO_GO