# Review: Address Backfill Rate-Limiting Plan

## The core problem: the per-worker caps add up to more than the ceiling

- **Combined capacity:** 12 workers × 5 requests per second = **60 requests per second**.
- **Contracted ceiling:** **50 requests per second**.

The workers don't coordinate, so nothing stops all 12 from using their full allowance in the same second. With 3.2 million rows to process, the workers will be running flat out for hours. They will sit at or near 60 requests per second for long stretches, so going over the limit is close to certain, not just possible.

One second over 50 suspends the key for 24 hours. That halts live checkout address lookups, which the plan says must never happen. The plan breaks its own stated requirement.

## What the plan gets right

- **Retries are covered:** HTTP 500 retries count against each worker's limiter, so they don't add hidden traffic.
- **The key is exclusive:** no other service uses it during the run, so the backfill's own traffic is the only load to budget for.
- **The worker count is fixed at 12:** the sum can be calculated exactly. That sum is what shows the problem.

## Required changes (pick one)

1. **Lower each worker's cap to 4 per second.** 12 × 4 = 48, which leaves a little headroom.
2. **Reduce to 10 workers or fewer at 5 per second.** 10 × 5 = 50 sits exactly at the ceiling with no margin. That only works if the contract allows "≤ 50" rather than "< 50". Use 9 workers to be safe.
3. **Use one shared limiter** (for example, a Redis token bucket) set below 50, such as 45 per second, for all workers.

## Recommended safety margin

Aim for roughly 80–90% of the ceiling, not 100%. Two reasons:

- **Network jitter can bunch requests together.** Requests sent within one client-side one-second window can arrive closer together at the vendor.
- **The vendor's window may not line up with the workers' windows.** Its window boundaries can differ from what each worker measures.

Under option 1, 48 requests per second still finishes 3.2 million rows in about 18.5 hours. The extra time is a small cost compared with a full day of checkout outage.

VERDICT: NO_GO