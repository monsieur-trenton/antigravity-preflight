# Review: Order Service 7.3 Release and Rollback Plan

## Blocking issue: the plan cannot show it meets its own 15-minute rule

The release policy and the merchant contract set a hard limit: once a release is declared failed, 7.2 must be serving traffic again within 15 minutes. The plan admits that nobody has timed the rollback job against a production-sized (400 GB) copy. So the time of the one step that decides compliance is unknown.

The step most at risk is also on the critical path:

- **The job order puts the risky step first.** The job runs the down-migration *before* putting 7.2 back. Every second the `DROP COLUMN` takes counts against the outage clock.
- **The drop time depends heavily on the database engine and version:**
  - **PostgreSQL:** `DROP COLUMN` only changes metadata. But it needs an `ACCESS EXCLUSIVE` lock. That lock waits behind any long-running query or transaction on `orders`, and while it waits, it blocks all new reads and writes. During a failed release, traffic is often unusual, so a lock queue is quite possible.
  - **MySQL/MariaDB:** Depending on version and whether `ALGORITHM=INSTANT` applies, the drop can rebuild the whole table. On 400 GB, that takes hours.
  - **Other engines or managed services:** Behavior varies. Replication lag on replicas can add time too.

As written, the rollback may well take more than 15 minutes. If it does, that is a contract breach with a fixed penalty and a required disclosure. A plan whose ability to follow its stated rule is unknown, on a step that can plausibly take far longer, does not meet "works as written."

## Required changes

1. **Take the down-migration off the critical path.** The plan already says 7.2 neither reads nor writes `discount_code`. That means 7.2 can run against the schema with the column present. Change the rollback job to:
   - redeploy 7.2 first, which stops the outage clock;
   - drop the column later, in a separate step during a quiet period, or simply leave it in place.

   This removes the main risk of breaching the 15-minute limit.
2. **Confirm 7.2 really tolerates the extra column.** Check for `SELECT *` mapped into strict row structs, `INSERT` statements without column lists, and schema checks at startup. If the column has a default or allows NULL, inserts from 7.2 will work.
3. **Time the redeploy step.** Even with the migration removed, the time to redeploy 7.2 without a canary should be measured, or at least taken from past deploys, so you know it fits within 15 minutes.
4. **If you keep the drop in the rollback path anyway** (not recommended), you would need to:
   - time it on a production-sized copy;
   - set a `lock_timeout` (or equivalent) so a blocked lock fails fast instead of stalling traffic;
   - have a fallback ready if the drop doesn't finish quickly.

## Points that are fine

- Skipping the canary for 7.2 is reasonable, since it carried all production traffic for the past 30 days.
- Losing `discount_code` data on rollback is acceptable as stated, since 7.2 doesn't use it. Do confirm that nothing else, such as reporting or downstream consumers, starts depending on it while 7.3 is live.
- Starting the rollback automatically when the release is declared failed is good for meeting the time limit.

VERDICT: NO_GO