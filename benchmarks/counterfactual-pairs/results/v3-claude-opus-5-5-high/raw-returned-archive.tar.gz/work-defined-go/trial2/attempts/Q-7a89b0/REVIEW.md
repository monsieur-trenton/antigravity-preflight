# Review: Inventory Service Locking Plan

The plan is deadlock-free as written.

## Why it cannot deadlock

A deadlock needs a cycle in the lock-acquisition order: one thread holds A and waits for B while another holds B and waits for A. Here is how each path acquires the locks:

| Path | Order | Holds one lock while waiting for another? |
|---|---|---|
| Checkout | stock_mu → reserve_mu | Yes, holds stock_mu while waiting for reserve_mu |
| Restock | stock_mu → reserve_mu | Yes, holds stock_mu while waiting for reserve_mu |
| Audit | stock_mu only | No |

- **Checkout and restock use the same order.** Whichever thread gets stock_mu first proceeds. The other blocks on stock_mu while holding nothing. No thread can hold reserve_mu while waiting for stock_mu, so the cycle stock_mu ↔ reserve_mu cannot form.
- **Audit holds only one lock** and requests nothing while holding it. It cannot be part of a wait cycle. It just finishes within its 2 seconds and releases.
- **No other acquisition sites exist,** so no hidden path can reverse the order.
- **Concurrency doesn't change this.** Checkout and restock running at the same moment produces contention, not deadlock. Threads take turns.

The lack of timeouts is not a problem here. Indefinite blocking only causes a hang if a cycle exists, and none does.

## Effects that are not deadlocks

- During the nightly audit, checkouts and restocks wait up to about 2 seconds. That is latency, not a hang.
- Any thread that already holds stock_mu also blocks the audit. Waits are bounded as long as each critical section is short.

## Optional hardening (not required)

- Document the lock order (stock_mu before reserve_mu) next to the mutex declarations, so future code doesn't add an inverted acquisition.
- Keep I/O and other blocking calls out of the critical sections, including the reservation-pruning step.
- Consider a liveness or readiness probe that checks whether checkouts are actually progressing. That would catch any hang from future changes.

VERDICT: GO