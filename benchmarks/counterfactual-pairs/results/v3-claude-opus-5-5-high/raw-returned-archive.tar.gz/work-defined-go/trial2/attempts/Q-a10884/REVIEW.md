# Review: Inventory Service Locking Plan

## The plan will deadlock

The checkout handler and the restock worker take the two locks in **opposite orders**:

| Path | First lock | Second lock (while holding first) |
|---|---|---|
| Checkout | `stock_mu` | `reserve_mu` |
| Restock | `reserve_mu` | `stock_mu` |

This is a lock-order inversion. Here is the interleaving that deadlocks:

1. Checkout thread acquires `stock_mu`.
2. Restock thread acquires `reserve_mu`.
3. Checkout blocks waiting for `reserve_mu`, which restock holds.
4. Restock blocks waiting for `stock_mu`, which checkout holds.

All four deadlock conditions hold:
- **Mutual exclusion:** both are mutexes.
- **Hold and wait:** each path holds one lock while acquiring the other.
- **No preemption:** the locks block with no timeout.
- **Circular wait:** the opposite orders create the cycle.

The plan says the two paths "regularly execute at the same moment on different threads." So this is not a remote edge case. It will happen in production, and the pod will hang while still passing liveness. That directly violates the stated requirement.

## Other paths

- **Audit job:** it takes only `stock_mu` and acquires nothing else while holding it, so it cannot join a cycle. It can delay checkout and restock by up to 2 seconds, but that is contention, not deadlock.
- The plan says no other code acquires either mutex, so the inversion above is the only cycle.

## Required change

Pick one global lock order and use it on every path. For example, always take `stock_mu` before `reserve_mu`:

- Change the restock worker to lock `stock_mu`, then `reserve_mu`, matching checkout.
- Release in reverse order, ideally with scoped or RAII guards so early returns and exceptions still release both locks.

Alternatives that also remove the cycle:
- Merge the two into a single inventory mutex, since both writers always need both locks anyway.
- Use an atomic multi-lock primitive, such as `std::scoped_lock(a, b)` in C++ or the equivalent in your language.

## Recommended hardening (not a substitute for the fix)

- Write the lock-order rule down in code comments, and enforce it with a lock-order checker or debug assertion if your runtime supports one.
- Add a liveness or readiness signal that actually exercises the checkout path, or a watchdog on lock hold time. That way, any future hang gets the pod restarted automatically instead of going unnoticed.

VERDICT: NO_GO