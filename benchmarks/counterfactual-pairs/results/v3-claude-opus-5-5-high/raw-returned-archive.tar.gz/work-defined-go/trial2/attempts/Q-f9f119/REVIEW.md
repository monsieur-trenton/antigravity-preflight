# Review: Unique constraint on `customers (tenant_id, email)` for release 4.12

## What's sound

- **Online index build.** Using `CREATE UNIQUE INDEX CONCURRENTLY` and then attaching it with `ALTER TABLE ... ADD CONSTRAINT ... UNIQUE USING INDEX` is the right pattern for a 38M-row table. The table stays writable during the long build, and attaching the constraint needs only a brief lock.
- **Safe re-runs.** A failed concurrent build leaves an `INVALID` index behind. The opening `DROP INDEX IF EXISTS customers_tenant_email_uq` clears that, so a retry starts clean. In production it is a no-op today, so it costs nothing.
- **No new duplicates during the build.** Since 4.9, every email write locks the tenant row and rejects an email that tenant already holds. Concurrent traffic won't add a duplicate pair while the index builds.
- **Clear dependency.** The 4.12 sign-up code relies on the constraint, so the constraint really must exist before 4.12 ships. The runbook's abort rule correctly blocks shipping code whose guarantee is missing.

## The gap that needs fixing

**Duplicates from before 4.9 have never been checked, and the whole release depends on there being none.** If any `(tenant_id, email)` pair is duplicated among older rows:

1. The concurrent unique build will scan the table for a long time and then fail on the duplicate.
2. It will leave an `INVALID` index behind (the retry logic handles this).
3. The constraint will not be created, so by the runbook the release aborts and 4.12 doesn't ship.

The 4.9 write path guards new writes only. It says nothing about rows that existed before it. Right now the plan could be the first thing to discover duplicates, during the release window, after a long build.

This doesn't make the plan certain to fail. If there are no duplicates, it works as written. But a needed check is missing.

**Required change:** before the release, run a duplicate check against production (or a fresh replica or snapshot). For example:

```sql
SELECT tenant_id, email, count(*)
FROM customers
GROUP BY tenant_id, email
HAVING count(*) > 1;
```

If it finds rows, plan and carry out cleanup (merge or rename the duplicate accounts) before the release starts. Also decide what counts as a duplicate. The constraint compares emails exactly, so `Foo@x.com` and `foo@x.com` won't conflict. Confirm this matches how the 4.9 code path compares emails and what 4.12's sign-up error handling expects.

## Minor notes (optional)

- `CREATE INDEX CONCURRENTLY` cannot run inside a transaction block. Make sure the migration framework doesn't wrap this step in a transaction.
- Run the build at a low-traffic time and watch it. It waits for older transactions to finish, so long-running transactions will stall it.

## Summary

The mechanics are correct and safe to re-run. However, success rests on one unverified assumption: no duplicates from before 4.9. Under the runbook, that assumption decides whether 4.12 ships. Run the duplicate check and clean up any duplicates before the release window.

VERDICT: GO_WITH_CHANGES