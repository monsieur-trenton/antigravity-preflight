# Review: orders-api TLS certificate and CA rotation

The plan has the right overall shape: distribute the dual-root trust bundle, confirm fleet coverage, switch the server certificate, then retire the old root. But the retirement step is scheduled before the switch, and that causes an outage.

## Blocking issue: 'Internal Root 2023' is removed before the server stops using it

| Day | Server presents | Client trust bundle |
|---|---|---|
| 1 | 2023-chained cert | 2023 + 2026 |
| 3 | 2023-chained cert | 2023 + 2026 (inventory confirms) |
| **5** | **2023-chained cert** | **2026 only** |
| 7 | 2026-chained cert | 2026 only |

From day 5 to day 7, the server still serves its 2023-chained certificate, but clients no longer trust that root. Clients re-read their bundle every 15 minutes, so within about 15 minutes of the day-5 change every client will fail any new TLS handshake. Open connections stay up because the reload doesn't close them, but every reconnect, new pooled connection, or newly started client fails for about two days. This breaks the plan's own rule that connectivity must never drop for any client.

**Fix:** Remove 'Internal Root 2023' from the bundle only after the day-7 switch, and only after confirming that all server instances present the 2026 chain. Plan a second fleet inventory to confirm that every client has the 2026-only bundle before you call the rotation done. A reasonable order:

1. Day 1: distribute the dual-root bundle.
2. Day 3: inventory confirms dual-root coverage, then schedule the switch.
3. Day 7: switch the server to the 2026 certificate with the full chain, and verify every endpoint.
4. Day 7 + soak period: remove 2023 from bundles and run an inventory to confirm.
5. After that: destroy the 2023 private key.

## Secondary note: key destruction timing

Destroying the 2023 CA private key on day 5 doesn't break the leaf certificate that has already been issued. However, it removes your ability to issue a replacement 2023-chained certificate if you need to roll back from the day-7 switch. Tie key destruction to the post-switch retirement step, not to day 5.

## Points that are sound

- **Distribute trust first, then switch.** Gating the switch on an inventory of bundle hashes is correct.
- **Serving the full chain from day 7** is correct.
- **Same subject name, different key identifiers.** This is a known risk for path building, and the staging test that accepted certificates from each root with the dual-root bundle addresses it. Make sure staging covers every client TLS library and version in the fleet.
- **Validity margin.** The 2023 certificate is good until day 60, which leaves plenty of room to delay the switch.

VERDICT: NO_GO