# Review: Address Backfill Geocoding Rate Plan

**Rate math:** 8 workers × 5 requests per one-second window = **40 requests/second at most**, under the 50 req/s contract.

**Why the bound holds:**
- **Per-window cap:** Each worker's limiter caps it at 5 requests in *any* one-second window, not just aligned windows. So the sum across workers in any window is at most 40, even without coordination between workers.
- **Fixed worker count:** It cannot creep above 8 during the run.
- **Retries:** HTTP 500 retries draw from the same limiter, so they can't push a worker past 5/s.
- **No other traffic:** No other service uses the key during the backfill, so the backfill's 40/s is the key's total load.

**Headroom:** The 10 req/s margin (20%) absorbs uneven arrival at the vendor. Network jitter can bunch requests sent at a steady pace, but bunching cannot raise the count above the 40 requests sent.

**Runtime:** 3.2M rows ÷ 40 req/s ≈ 80,000 s, about 22 hours at full rate. That's acceptable for a backfill, but schedule it with this in mind.

**Optional suggestions (not required):**
- On HTTP 429 or any rate-limit warning, stop or back off sharply rather than retrying, to protect checkout.
- Make the limiter settings and worker count config values that are checked at startup (e.g., assert `workers × per_worker_rate ≤ 45`), so nobody bumps them mid-project without noticing.
- Watch the vendor's usage dashboard, if one exists, during the first few minutes.
- Make the job resumable (checkpoint processed row IDs), so a crash in a ~22-hour run doesn't force a restart.

The plan as written stays within the contracted rate and meets its requirement.

VERDICT: GO