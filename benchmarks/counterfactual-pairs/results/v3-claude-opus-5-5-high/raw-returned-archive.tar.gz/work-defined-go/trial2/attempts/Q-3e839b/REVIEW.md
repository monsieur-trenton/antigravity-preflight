# Review: orders-api TLS certificate and CA rotation (Internal Root 2023 → 2026)

The plan works as written. Each step depends only on conditions already confirmed by an earlier step, and no client is ever without a trust path to the certificate the server is presenting.

## Phase-by-phase check

**Days 1–7: overlap window**
- The server keeps presenting the 2023 certificate, which is valid until day 60.
- On day 1, every client receives a bundle with both roots. Because bundles are re-read every 15 minutes, each client picks it up within that interval.
- Throughout this window, every client trusts the certificate being served.

**Day 3: switch gate**
- The switch is dated only after the inventory shows every client's bundle hash covering both roots.
- This is the correct precondition for the cutover. It is based on verified state rather than assumed delivery.

**Day 7: switch**
- The server presents the 2026 certificate with its full chain.
- Every client already trusts Internal Root 2026, as confirmed on day 3.
- Connections opened earlier under the 2023 certificate stay open, because the reload doesn't close them. Any reconnect validates against 2026.
- If something goes wrong, rollback is still possible until day 30, since the 2023 certificate is valid and still trusted.

**Shared subject name**
- The two roots differ only by key identifier, so a client could build the chain against the wrong root.
- Staging already showed that clients holding both roots accepted certificates from each, which covers this concern.

**Day 30: retirement**
- The server has presented only 2026 certificates for 23 days.
- Removing 2023 from the bundle therefore affects no current handshake.
- Destroying the 2023 private key is safe. Nothing still needs to be signed by it, and it has been offline since day 1.

## Optional hardening (not required)

- Rerun the inventory just before day 30. This confirms no client is still pinned to a bundle containing only 2023, and that nothing has reverted to the 2023 certificate.
- Confirm that the 2026 leaf and any intermediates carry an Authority Key Identifier, so production chain building matches what staging showed.
- Watch handshake-failure metrics around day 7 and day 30.

VERDICT: GO