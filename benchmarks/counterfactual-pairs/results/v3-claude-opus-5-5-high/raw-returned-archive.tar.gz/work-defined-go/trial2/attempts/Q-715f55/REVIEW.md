# Review: Month-End Invoice Batch Plan

**The plan works as written. It needs no changes.**

## Request size

- **Limit:** the partner rejects any body over 5,000,000 bytes.
- **Worst case:** 500 records × 4,100 bytes = 2,050,000 bytes, plus under 1,000 bytes of envelope and separators. That is under 2,051,000 bytes, about 41% of the limit.
- **Unbounded notes field:** the source system doesn't limit notes, but that doesn't matter here. The job reads a closed snapshot that no longer changes, and every record in it was scanned. The 4,100-byte maximum is a measured fact about the data being sent, not an estimate.
- **Final batch:** it may have fewer than 500 records, so it can only be smaller.

## Timeout

The partner documents responses of up to 60 seconds for large batches. The new 120-second timeout is double that. The default 30 seconds would have been too short, and the plan fixes that.

## Single submission

The plan sends exactly one request per batch and never resends. This follows the partner's duplicate-filing rule. Nothing in the plan causes a second submission.

## Optional suggestions (not required)

These would make the plan more robust but don't fix any flaw:

1. **Check the snapshot's maximum size at run time.** Do this right before sending, using the same serializer and encoding (for example UTF-8) that the job uses. Abort before any request if a batch would exceed the limit. This guards against differences between the scan and the job's actual serialization.
2. **Plan for an unclear outcome.** A connection drop or a timeout past 120 seconds would leave the batch's status unknown. Resending isn't allowed, so the job can't retry blindly. Consider:
   - logging each batch's invoice IDs and the request outcome;
   - an escalation path, such as asking the partner to confirm whether the batch arrived, so a lost batch doesn't silently fail reconciliation.

VERDICT: GO