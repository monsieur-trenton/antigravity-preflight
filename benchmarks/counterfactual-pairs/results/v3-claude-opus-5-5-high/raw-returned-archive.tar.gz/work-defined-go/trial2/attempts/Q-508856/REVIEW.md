# Review: Checkout capture retry plan

## The core problem

The plan's safety depends on one thing that hasn't been checked.

The plan states that:
- No capture may be applied twice.
- A timeout can happen after the server has already applied the capture.
- The client retries on timeouts, up to 5 times.

So the plan itself admits that a retry can reach the server for a capture that already went through. The only thing that would stop that retry from charging the customer again is the idempotency key. That only works if the capture endpoint recognizes a repeated key and returns the original result instead of capturing again. **Nobody has verified this, and the payments team hasn't confirmed it.**

If the endpoint ignores the key, or only checks it some of the time, the failure is direct. A timeout after a successful capture leads to a retry, which leads to a second charge. That breaks the plan's own rule, and up to 5 retries means up to 5 extra charges per order.

## What's sound

- **Stable key:** Using one UUID per order, created once and never regenerated, is the right design.
- **No hidden retries:** Turning off the HTTP library's built-in retries means only the 5 known retries can occur.
- **Backoff:** 200, 400, 800, 1600 and 3200 ms add up to about 6.2 seconds, which is reasonable.

None of this helps, though, unless the server actually deduplicates.

## Required before this can ship

1. **Get the payments team to confirm** that the capture endpoint deduplicates by idempotency key. Ask specifically:
   - What scope the key applies to (per merchant, per endpoint, global).
   - How long a key is retained, which must be longer than the retry window plus any manual replays.
   - What happens if a retry arrives while the first request is still being processed (it should return 409 or wait, not capture again).
   - Whether a repeated request returns the original response.
2. **Test it:** force a timeout after the server commits the capture, let the retry run, and check that the customer is charged once.
3. **Have a fallback if the endpoint does not deduplicate.** For example, don't retry on timeouts. Instead, look up the capture status by order or key and decide from that result.

## Smaller points

- Treat 5xx responses with the same caution as timeouts, since some 5xx errors happen after the capture is committed.
- Consider adding jitter to the backoff.
- Make sure exhausting all retries leads to a reconciliation step, not an assumed failure.

## Conclusion

As written, the plan relies on deduplication that hasn't been confirmed, in exactly the scenario it says will happen. That means it can break its own no-double-capture rule.

VERDICT: NO_GO