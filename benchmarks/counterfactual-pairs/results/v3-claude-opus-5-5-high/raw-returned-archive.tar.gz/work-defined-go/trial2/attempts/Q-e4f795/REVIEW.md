# Review: month-end invoice batch posting plan

The plan works as written. Every risk it raises is either bounded by the facts it states or already handled.

## Will a batch stay under the 5,000,000-byte limit?

Yes, with a wide margin.

- **Measured size:** The plan scanned every record in the job's own input. The largest serialized record is 4,100 bytes, so a full batch of 500 is at most 2,050,000 bytes.
- **Envelope:** The envelope and separators add under 1,000 bytes, so the worst-case request is under 2,051,000 bytes. That is about 41% of the limit.
- **Encoding:** The figure is a count of serialized bytes, not characters, so multi-byte characters are already included. Batches are sent uncompressed, so the body sent is the body measured.
- **Uncapped notes field:** The source system doesn't limit notes, but that doesn't matter here. The input is a closed snapshot that can't change after closing, and the scan covered all of it. The measured maximum is therefore a true bound for this run.

## No-resend rule and reconciliation

- **Duplicate filings:** Each batch goes out in exactly one request and is never resubmitted. This follows the partner's duplicate-filing rule.
- **Missing invoices:** A missing invoice would fail reconciliation, so a refusal must not happen. The only refusal cause given is oversize, and the size bound rules that out. Batching therefore can't leave an invoice missing.

## Timeout

- The partner says large batches can take up to 60 seconds to answer. The 120-second timeout covers that with twice the headroom.
- Our batches are under half the size limit, so they should fall toward the faster end of that range.

## Optional suggestions (not required)

- **Repeat the scan each month:** Run the max-record-size check against each month's snapshot before sending, and abort if any batch would exceed a safety threshold. The bound depends on scanning that month's own snapshot, and notes are uncapped.
- **Plan for ambiguous outcomes:** Since resending isn't allowed, write down what to do if a request fails at the transport level or its result is unclear. One option is to check the partner's ledger before deciding anything. Retrying is not an option.

VERDICT: GO