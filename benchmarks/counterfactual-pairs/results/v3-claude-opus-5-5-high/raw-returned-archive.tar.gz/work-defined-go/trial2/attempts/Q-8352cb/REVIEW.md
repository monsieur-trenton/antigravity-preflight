## Review: Release 4.12 (split-payment flow)

### Blocking issue

**The production flag default contradicts the release rule.** The plan's rule is that every new code path ships switched off in production and is turned on later only through a separate, approved flag change. But `flags.yaml` sets `checkout.split_payment` to **true in production**. As written, deploying 4.12 turns split payment on for production customers right away. That causes several problems:

- It breaks the stated release rule directly.
- It invalidates the claim that "the existing single-payment code … stays the path production customers use while the flag is off." The flag will not be off.
- Production will start writing `split_payment_ref`, which the plan says only happens with the flag off. Rolling back then means dealing with orders that already hold split-payment data.
- The CI run with the flag "forced off to mirror production" mirrors a configuration production won't actually have. It tests the wrong production state, and the flag-on run only covers staging.
- The later change ticket after two weeks of staging traffic would have nothing to enable, because the feature would already be live.

**Required change:** set the production default in `flags.yaml` to `false`. Dev and staging can stay `true`. Once that's fixed, the CI "forced off" run matches production.

### Other points (fine as written)

- **Schema change:** adding a nullable column with a lock under 1 second, measured on a full-size staging copy, is low risk. Because the column isn't written while the flag is off, rollback stays simple.
- **Flag propagation:** a 30-second local cache with no redeploy is fine for both enabling and disabling. A flip reaches every pod within 30 seconds, so there's a short window where pods disagree. Make sure the split-payment flow handles a request that starts on one pod and continues on another during that window. This is an optional robustness check, not a blocker.
- **Rollout gating:** keeping production enablement in a separate ticket after two weeks of staging traffic is the right process. It only works once the production default is `false`.

### Summary

Apart from the flag default, the plan is sound. With production set to `true`, though, the release ships the new path live and breaks its own rule.

VERDICT: NO_GO