# Review: Address Backfill Geocoding Plan

## The plan exceeds the contracted rate

The numbers in the plan don't fit the limit:

- **12 workers × 5 requests/second = 60 requests/second** in the worst case.
- The contract allows **50 requests/second** in total.

The workers don't coordinate, so nothing stops all 12 from sending their full 5 requests in the same one-second window. That gives 60 requests in that window, which is 10 over the cap. The contract says going over in **any** one-second window suspends the key. The plan doesn't need to sustain 60 req/s to fail. It only needs one window where the workers line up.

Over a 3.2M-row run this is close to certain. If each worker runs at its limit, the combined rate sits above 50 most of the time, not only in rare bursts. A suspension would also stop live checkout address lookups for 24 hours, which is the exact outcome the requirement says to avoid.

## What the plan gets right

- **Retries share the limiter.** Because retries after a 500 draw from the same budget, they can't push a worker above its cap. Without this, a burst of errors could cause a retry storm.
- **The worker count is fixed.** This makes a static per-worker budget workable. It just has to be set correctly.
- **No other users of the key.** The backfill can use the whole contract without reserving room for other traffic.

## Required change

Make the worst-case total stay under 50, with some margin. Any of these works:

1. **Lower the per-worker limit to 4 req/s.** 12 × 4 = 48 ≤ 50. This is the smallest change.
2. **Use 10 workers at 5 req/s.** 10 × 5 = 50. This is exactly at the cap with no margin, so it's less safe if the client's and vendor's window boundaries or clocks differ.
3. **Use a shared/global limiter**, such as a token bucket in Redis, set somewhat below 50 (e.g. 45 req/s). This enforces the real constraint directly.

I'd also leave headroom rather than targeting exactly 50. The client's one-second windows won't line up with the vendor's, and network jitter can bunch requests together on arrival. Something like 12 × 3.5 ≈ 42 req/s, or a global limit around 45, is safer. At 42 req/s, 3.2M rows takes about 21 hours, versus about 18.5 hours at 48 req/s, so the extra safety costs little time.

## Summary

The retry handling, fixed worker count, and exclusive use of the key are all sound. The problem is the arithmetic: 12 uncoordinated workers at 5 req/s can reach 60 req/s against a 50 req/s limit. That breaks the plan's own requirement and risks a 24-hour suspension that would also take down checkout.

VERDICT: NO_GO