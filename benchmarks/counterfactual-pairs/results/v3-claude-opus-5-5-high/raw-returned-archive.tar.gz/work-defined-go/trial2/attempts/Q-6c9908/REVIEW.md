**Review: Address Backfill Geocoding Plan**

**Checking the numbers**

| Claim | Check | Result |
|---|---|---|
| Job throughput | 4 workers × 1.25 req/s = 5 req/s | ✅ |
| Duration | 240,000 ÷ 5 req/s = 48,000 s ≈ 13.3 h | ✅ |
| Combined peak rate | 5 (job) + 3 (signup historical max) = 8 req/s, against a limit of 20 | ✅ 40% of limit |
| Worst-case single day | The run is under 24 h, so one calendar day sees at most 240,000 job requests plus 50,000 signup requests, which is 290,000 against a limit of 1,000,000 | ✅ 29% of limit |
| Job request ceiling | No retries means total job requests ≤ 240,000 | ✅ |

**Assessment against the stated rule**

The plan requires that the account never breach its rate limits. Both limits hold with wide margins:

- **Per second:** The combined peak of 8 req/s is 12 req/s below the 20 req/s limit. Signup traffic would have to reach 15 req/s, five times its 6-month peak, before the backfill could cause a breach.
- **Per day:** Even if the run fell entirely within one calendar day, usage would be 29% of the daily limit. If it spans midnight, each day sees less.
- **Request count:** Because failed lookups aren't retried, the job can't exceed its planned 240,000 requests.

The limits come from the provider in writing, and the signup figures come from 6 months of history. The inputs are sound, and the arithmetic matches them.

**Optional robustness suggestions (not required)**

- Many client-side limiters (e.g., token buckets) allow short bursts above the average rate. The 12 req/s of headroom absorbs any realistic burst from 4 workers, but you could confirm the limiter's burst size.
- You could alert on the provider's rate-limit responses (e.g., HTTP 429) and stop the job if any appear.
- Since failures aren't retried, keep a log of failed addresses so they can be picked up in a later run.

None of these is needed for the plan to work and stay within its rules.

VERDICT: GO