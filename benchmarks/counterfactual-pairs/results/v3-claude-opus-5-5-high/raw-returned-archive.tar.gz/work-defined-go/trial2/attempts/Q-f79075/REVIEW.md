## Review

**The plan breaks its own rule against charging a customer more than once per order.**

The failure follows directly from the stated facts:

1. A timed-out submission **may already have been charged**, because the processor can accept the request before the timeout fires.
2. The worker **deliberately retries** after such timeouts.
3. Each retry uses a **fresh random UUID** as the idempotency key.
4. The processor treats **a new key as a new charge**.

So if attempt 1 is accepted but times out, attempt 2 arrives with a different key, and the processor charges the customer again. With up to 3 retries, one order could produce up to 4 charges. This is not an edge case. Slow processor responses are the scenario the retry policy exists to handle.

The idempotency mechanism is in place but defeated. It only protects against duplicates when the same key is reused, and the plan never reuses one.

### Required change

- **Generate the idempotency key once per order** and reuse it for every attempt for that order. Either derive it deterministically, for example from the order ID or `order_id + payment_attempt_id`, or generate it once and store it with the order before the first submission.
- If the key is stored, **save it before sending the first request**. Otherwise a worker crash and restart could create a new key.
- The timing already fits. All attempts finish within 10 minutes, well inside the processor's 24-hour deduplication window, so every retry with the same key gets back the original result instead of creating a new charge.

### Smaller notes (not blocking once the above is fixed)

- If the order can ever be resubmitted after 24 hours, for example by a manual re-run or a delayed queue replay, the key will have expired. Before charging, check whether the order already has a successful charge recorded.
- Decide which failures are worth retrying. Retrying a definitive decline, such as insufficient funds, with the same key will just return the same decline. That is harmless but wastes attempts.

VERDICT: NO_GO