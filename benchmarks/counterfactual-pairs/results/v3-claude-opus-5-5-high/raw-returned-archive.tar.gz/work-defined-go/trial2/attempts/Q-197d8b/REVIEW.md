# Review: Inventory Service Locking Plan

## Deadlock analysis

A deadlock needs a cycle in the wait-for graph. That requires at least two threads to acquire the same locks in conflicting orders. Here is how each lock holder behaves:

| Path | Acquisition order | Holds while waiting? |
|---|---|---|
| Checkout handler | stock_mu → reserve_mu | Yes (stock_mu while acquiring reserve_mu) |
| Restock worker | stock_mu → reserve_mu | Yes (stock_mu while acquiring reserve_mu) |
| Nightly audit | stock_mu only | No nested acquisition |

- **Checkout vs. restock:** Both take stock_mu first. Whichever thread loses the race for stock_mu blocks before it holds anything. It cannot be holding reserve_mu while waiting for stock_mu, so no cycle can form. Running concurrently every 30 seconds causes contention, not deadlock.
- **Audit vs. either path:** The audit holds only stock_mu and never waits on another lock while holding it. A thread blocked behind the audit waits at most about 2 seconds and then proceeds. A thread holding stock_mu that is waiting for reserve_mu is waiting on a holder of reserve_mu. That holder must also hold stock_mu, so it is the same thread, which is impossible. In practice, no thread can be waiting for reserve_mu while another holds it, because reserve_mu is only acquired under stock_mu.
- **Completeness:** The plan states that no other code path acquires either mutex. Under that premise, the lock graph has a single consistent order (stock_mu before reserve_mu). In this design, reserve_mu is effectively always nested inside stock_mu.

Because every acquirer follows a single global lock order, deadlock cannot occur. The lack of acquisition timeouts doesn't break the requirement. Timeouts would only matter if a cycle were possible.

## Non-blocking observations (optional, not required changes)

- **Document the lock order** (for example, a comment or a lock-ordering assertion in debug builds) so that a future code path doesn't acquire reserve_mu first and introduce a cycle.
- **Audit stalls:** Checkout latency can spike by up to about 2 seconds while the audit holds stock_mu. This affects throughput and latency, not deadlock-freedom. It's worth confirming that's acceptable for nightly traffic.
- **Liveness probe:** The probe doesn't detect a stuck pod. That isn't a flaw in this locking plan, but a probe that exercises the lock path would guard against other kinds of hangs.

These would make a sound plan more robust. None of them is needed to meet the stated requirement.

VERDICT: GO