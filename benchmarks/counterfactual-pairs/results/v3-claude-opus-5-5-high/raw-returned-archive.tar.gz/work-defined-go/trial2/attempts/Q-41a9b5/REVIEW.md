# Review: Release 4.12 unique constraint on customers (tenant_id, email)

## The blocking issue: pre-4.9 data has never been checked

The plan assumes no duplicate `(tenant_id, email)` pairs exist. The facts only support that for rows written since 4.9:

- **Since 4.9:** the only email write path locks the tenant row and rejects existing emails. New duplicates cannot have been created.
- **Before 4.9:** that protection did not exist. Those rows have never been checked, and no duplicate query has run on production.
- **Effect on the build:** `CREATE UNIQUE INDEX CONCURRENTLY` fails if even one duplicate pair exists among the 38 million rows. The constraint then cannot be attached.
- **Effect on the release:** the runbook says that failure aborts 4.12 entirely. One leftover duplicate from before 4.9 would stop the release.

Nothing in the plan detects or resolves duplicates before the build. Whether it succeeds depends on a fact nobody has checked, and the stated abort rule makes that fact the release gate. I can't confirm duplicates exist. But the plan has no step that gives it a reasonable chance of succeeding on purpose, so it isn't ready as written.

**Required change:** before the migration, run a duplicate check on production (or a fresh replica):

```sql
SELECT tenant_id, email, count(*)
FROM customers
GROUP BY tenant_id, email
HAVING count(*) > 1;
```

- **If it returns nothing:** the build should succeed, and with the points below the plan becomes a GO.
- **If it returns rows:** add a cleanup step (merge or rename duplicates, agreed with the product owners) before the index build. Decide this ahead of time, not during the release window.

## Points that are fine

- **`DROP INDEX IF EXISTS`:** it does nothing on the first run, as you note. It is useful on a retry, because a failed `CONCURRENTLY` build leaves an INVALID index with that name. The drop clears it so a rerun can start fresh.
- **Write path since 4.9:** the tenant-row lock means no new duplicates should appear during the long concurrent build.
- **Order of steps:** building the index concurrently and then attaching it as the constraint is the right way to avoid a long lock on a 38-million-row table.

## Things to confirm

- **Transactions:** `CREATE INDEX CONCURRENTLY` cannot run inside a transaction block. Check that the migration tool runs this step outside one, or it fails immediately.
- **Email normalization:** a plain unique index on `email` treats `Foo@x.com` and `foo@x.com` as different. If sign-up should treat them as the same, the 4.12 sign-up code's reliance on the constraint will let case-variant duplicate accounts through. Check that the stored values are normalized, or use an index on `lower(email)`. Include this in the duplicate query too.
- **Error handling:** the 4.12 sign-up code should handle the unique-violation error (SQLSTATE 23505) for this specific constraint name.

## Summary

The migration itself is sound. The failure it guards against, duplicate rows from before 4.9, is exactly the one nobody has checked for, and under the runbook that failure aborts the release. Run the duplicate query first and add a cleanup step if it finds anything.

VERDICT: NO_GO