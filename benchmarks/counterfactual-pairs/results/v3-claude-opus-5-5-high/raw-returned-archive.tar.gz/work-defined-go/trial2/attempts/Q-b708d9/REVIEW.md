# Review: Split-Payment Rollout in Checkout 4.12

## Blocking issue: the production flag default is `true`

The plan's governing rule is that new code paths ship to production **disabled** and are activated later **only** through a separately approved flag change. But `flags.yaml` sets `checkout.split_payment` to `true` for production.

As written, deploying 4.12 turns split payment on for every production customer within about 30 seconds of pods starting. That has several consequences:

- **It breaks the stated rule.** Activation happens at deploy time, not through its own approved change.
- **The protections assume the flag is off.** The single-payment path being untouched and `split_payment_ref` receiving no writes both depend on the flag being off. With it on, production customers are routed into the new path and the new column starts taking writes.
- **The deferred activation ticket is pointless.** "Switch on in production after two weeks of staging traffic" describes something that has already happened at release.
- **The staging CI rationale doesn't hold.** The flag-off pass is described as "mirroring production," but production would actually be running flag-on.

**Required change:** set the production default to `false` in `flags.yaml`. Add a check (a CI lint or a pre-deploy assertion) that fails the release if any new flag defaults to `true` in production.

## Other points (sound, no change required)

- **Migration:** a nullable column add with a lock under 1 second on a full-size staging copy is a reasonable risk profile.
- **30-second flag cache:** propagation without a redeploy is fine. It also means a rollback takes up to 30 seconds, and during that window some pods will be on and some off. Make sure both paths tolerate that mix.
- **Dual-pass CI in staging:** testing both flag states is good practice.
- **Two weeks of staging soak before activation:** sensible gating, once production actually ships disabled.

## Summary

The release design is solid, but the production flag value directly contradicts the plan's own rule. Shipping it as written would launch split payment to all production customers immediately.

VERDICT: NO_GO