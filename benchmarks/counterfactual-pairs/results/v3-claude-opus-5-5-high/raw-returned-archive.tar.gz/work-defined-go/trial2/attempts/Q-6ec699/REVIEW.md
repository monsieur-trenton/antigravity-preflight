# Review: Checkout Capture Retry Plan

## What works

- **One idempotency key per order.** A single UUID, generated once and never replaced, is the right design. Every resend for an order carries the same key.
- **The plan names the duplicate risk.** It says outright that a resend can reach the server after a capture has already succeeded.
- **Library retries are off.** The 5 explicit resends are the only repeats, so the total number of attempts is known.
- **The backoff is reasonable.** Resends wait 200, 400, 800, 1600 and 3200 ms, about 6.2 s in total.

## The blocking problem

The plan's main rule is that a capture must never take effect more than once. Only the server can enforce that, by collapsing requests that share an idempotency key into one capture. The plan admits that nobody has checked this and the payments team has not confirmed it.

The client's key does nothing unless the server acts on it. So the plan, as written, resends a charge request after timeouts and 5xx errors, even though some of those failures happen after the charge succeeded. If the endpoint ignores the key, each such resend bills the customer again, which breaks the plan's own rule. The plan should not run on an unverified assumption.

## Changes needed before this can go ahead

1. **Get the payments team to confirm, in writing, how the capture endpoint handles idempotency.** They should cover:
   - **Concurrent requests.** A resend can arrive while the original request with the same key is still running. The endpoint must not process both. It should either reject or hold the second one, or return the first one's result.
   - **Key lifetime.** The endpoint must keep the key for longer than the full retry window, about 6.2 s plus the timeouts. Preferably it should keep it much longer.
   - **Replies to repeats.** A repeat should get back the original success response, so the client does not treat it as a failure.
   - **Partial failures.** If the server returns a 5xx after the charge has gone through, a resend should still map to that existing capture.
2. **Test it.** Write a test against the endpoint, or a faithful staging copy, that sends duplicate and overlapping requests with the same key and checks that only one charge results.
3. **If the endpoint does not deduplicate, do not resend after a timeout or ambiguous 5xx.** Instead, query the capture or order status and decide what to do from that, or send the case to reconciliation.

## Optional improvements

- Add jitter to the backoff.
- Do not retry 5xx responses that clearly mean the request was never processed, if the API can tell you that.
- Log the idempotency key with every attempt so duplicates can be audited.

VERDICT: NO_GO