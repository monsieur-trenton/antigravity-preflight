Review: Capture Retry Plan

**The rule:** no capture may be applied twice.

**The risk:** a timeout can fire after the server has already applied the capture. A blind retry would then charge the customer again.

**How the plan handles it:**

1. **Stable idempotency key.** Every attempt for an order uses the same UUID. It is created once with the order and never regenerated, so all retries look like the same logical capture to the server.
2. **Server-side dedupe is established.** Per-key idempotency is the endpoint's documented contract, confirmed by the payments team. The staging run backs this up: 6,000 requests across 1,000 keys produced exactly 1,000 charges. That test includes the hard case of a resend after the first attempt already succeeded.
3. **Retries are bounded and the only repeats.** The client makes at most 5 retries, with backoff of 200, 400, 800, 1,600 and 3,200 ms. The HTTP library's own retries are turned off, so there are no hidden repeats with a different key.
4. **Short retry window.** The whole sequence finishes in about 6.2 seconds plus request time. This is far inside any realistic retention period for idempotency keys, so a late retry won't arrive after the server has forgotten the key.

Together these close the double-charge path. A retry of a capture that already went through is deduplicated by key and does not create a second charge. The plan meets its stated rule as written.

**Optional hardening (not required):**
- Add jitter to the backoff, so a payments-service outage doesn't cause synchronized retry storms.
- Make sure the order and its key are saved before the first attempt. Then a client crash and restart reuses the key instead of creating a new order or key.
- Ask the payments team to confirm how a retry is handled while the original attempt is still in flight. It may return the same result, or a "processing" or 409 response. The client should treat that answer as "not failed."
- Log the idempotency key with each attempt so double-charge reports can be audited.

None of these are needed for the plan to work.

VERDICT: GO