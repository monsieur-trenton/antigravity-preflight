# Review: Address Backfill Geocoding Plan

## What checks out

- **Throughput:** 4 workers × 1.25 req/s = 5 req/s. 240,000 ÷ 5 = 48,000 s ≈ 13.3 h. Correct.
- **Combined peak:** 5 req/s from the job plus a 3 req/s signup peak gives 8 req/s. Correct.
- **Daily volume:** The job sends at most 240,000 requests in total, so even if the run falls entirely within one day, that day sees at most 240,000 + 50,000 = 290,000. This holds wherever the provider's day boundary falls, because the figure already assumes the worst case.
- **No retries:** Failed lookups are not resent, so total requests cannot exceed 240,000. That makes the 290,000 ceiling a real upper bound.

## The gap: the plan's main requirement is never checked

The plan's central requirement is that the account stays within its rate limits at all times. A breach suspends the account and also cuts off signup lookups. But the plan states no limit, and nobody has confirmed with the provider which limits apply to our account.

All the numbers above are correct, but there is nothing to compare them to. Whether 8 req/s and 290,000 req/day are safe depends entirely on a value we don't have.

- If the limits are at least 8 req/s and 290,000/day, the plan works as written.
- If either limit is lower, the run will breach it and take signup lookups down too.

This isn't optional hardening. Without it, the plan cannot show that it meets the requirement it sets for itself.

**Required change:** Before the run starts, get the account's actual limits from the provider, in writing or from the account dashboard. Check all that apply:
- per-second limit
- per-minute limit
- daily limit
- monthly limit
- concurrency limit

Record the figures in the plan, and only run once 8 req/s and 290,000/day are confirmed to fit within them, ideally with some headroom.

## Smaller points to check while confirming limits

- **Limiter burst behaviour:** If the client-side limiter is a token bucket with a burst allowance, each worker can briefly exceed 1.25 req/s. The combined rate could then spike above 5 req/s. Confirm burst is set to 1, or include the burst in the peak calculation.
- **Signup figures are past peaks, not caps:** 3 req/s and 50,000/day are the highest values seen in the last 6 months. Nothing prevents signups from going higher during the run. Leave headroom below the confirmed limits, or schedule the run for a low-signup window.
- **Window granularity:** If the provider enforces limits per minute or per rolling window, check that the steady 8 req/s (480/min) fits.
- **Failed lookups:** Since failures aren't retried, log them so the affected addresses can be handled in a later, rate-limited pass.

## Summary

The calculations are correct and the job's request volume is properly bounded. However, the plan's own rule (stay within the provider's limits) can't be confirmed, because the limits are unknown. Confirming them and recording them in the plan is a required change and must happen before the run.

VERDICT: GO_WITH_CHANGES