# Review: Shared Redis Cache for Rendered Dashboards

## Blocking issue: the cache key has no tenant

The key is `dash:{dashboard_id}:{range}`, but dashboard IDs restart at 1 in every tenant. Combined with one Redis cluster shared by all tenants, this leaks data across tenants:

1. Tenant A requests dashboard 42 for range `7d`. The handler renders it and stores it under `dash:42:7d`.
2. Within 300 seconds, Tenant B requests its own dashboard 42 for range `7d`. The handler derives the same key, `dash:42:7d`, finds a hit, and returns Tenant A's rendered dashboard.

This breaks the plan's own isolation rule. It happens in normal traffic, not only in rare edge cases. Gateway authentication doesn't help, because the authenticated `tenant_id` never reaches the key. "Touches no key other than the one derived from the request" doesn't help either, because the derived key is the same for both tenants.

**Required change:** include the gateway-stamped tenant in the key, for example `dash:{tenant_id}:{dashboard_id}:{range}`.
- Take `tenant_id` only from the gateway stamp, never from client-supplied input.
- Make sure no code path builds a key without it.

## Related issue: invalidation is also cross-tenant

With the current key, editing dashboard 42 in Tenant A deletes `dash:42:*`. That also evicts dashboard 42 for every other tenant. It doesn't leak data, but it causes needless cache misses and couples tenants' workloads. The tenant-scoped key fixes this as well: invalidate `dash:{tenant_id}:42:*`.

## Smaller notes (not blocking)

- **Invalidating all ranges.** The plan says an edit removes "its cached entries", which covers every `range` variant. Avoid using `KEYS` for this, because it blocks Redis. On a cluster, `SCAN` must also visit every node. Better options:
  - keep a per-dashboard set of range keys, or
  - use a version or generation number in the key, e.g. `dash:{tenant}:{id}:v{n}:{range}`, so an edit just bumps the version.
- **Race between edit and render.** A render that started before an edit can write stale data after the invalidation. The 300-second TTL limits the damage. The versioned-key approach also closes this gap.
- **User ID left out of the key.** This is fine as long as the rendered output really doesn't vary by user (no per-user permissions, locale, timezone, or "last viewed by" fields). It's worth confirming.

## Summary

The plan won't meet its isolation rule as written. Tenants with the same dashboard ID and range will receive each other's cached responses. Adding `tenant_id` to the key, and to the invalidation pattern, fixes it.

VERDICT: NO_GO