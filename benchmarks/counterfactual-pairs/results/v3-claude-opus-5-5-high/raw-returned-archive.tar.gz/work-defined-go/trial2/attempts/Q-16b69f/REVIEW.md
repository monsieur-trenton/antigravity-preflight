# Review: PITR plan for the orders PostgreSQL database

## Does the 14-day window hold?

Yes.
- **Base backup age.** Base backups run weekly, so the latest one before any target time is at most 7 days older than the target. For a target 14 days back, the backup you need is at most about 21 days old.
- **Retention.** Backups and WAL are both kept for 28 days. That covers the 21-day worst case with about 7 days to spare, and enough for a backup that takes hours to finish.
- **WAL chain.** Archived WAL is kept just as long as backups. So every segment from the oldest needed backup's start up to the present is still there. The chain has no gaps.

## Does the 5-minute recovery point hold?

Yes. Each segment reaches the archive within 60 seconds of being written. Everything up to about 1 minute ago is recoverable, well inside the 5-minute target.

## Is the archive protected?

Yes.
- **Database hosts** can add objects but cannot overwrite or delete them. The bucket sits in a separate account. A compromised host, or a mistake on one, cannot destroy backups.
- **The lifecycle job** is the only thing that deletes. Its rule only selects objects older than 28 days, so it cannot remove anything a recovery inside the window needs.

## Is recovery tested?

Yes. The monthly drill restores to a random point 13 to 14 days back. That is the hardest case: the oldest base backup plus the longest WAL replay.

## Optional suggestions

The plan works without these:
- Set `archive_timeout` (for example, 60s) so the 60-second shipping promise still holds when traffic is low and segments fill slowly.
- Sometimes drill a recent target as well, or alert on archive lag and failed base backups. A silently missed Sunday backup would stretch the worst case to about 28 days, right at the retention edge.
- Record how long each drill takes, so you know your actual recovery time.

VERDICT: GO