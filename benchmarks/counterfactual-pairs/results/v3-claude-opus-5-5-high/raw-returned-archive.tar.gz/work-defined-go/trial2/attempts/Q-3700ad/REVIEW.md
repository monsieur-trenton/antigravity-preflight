# Review: Order Service 7.3 Release and Rollback Plan

The plan is sound. I found no defects that would cause it to fail or break its own rules.

## Checks against the stated rules

- **15-minute rollback requirement:** The rollback job starts automatically when the release is declared failed. It was timed three times on a production-size copy at 5, 6 and 6 minutes, measured to the point where 7.2 is serving traffic. That is the same endpoint the contract's outage clock uses. The worst run still leaves about 9 minutes of margin, and the runs were consistent.
- **Data safety of the down-migration:** Dropping `discount_code` removes nothing 7.2 reads or writes, so 7.2 runs correctly afterward.
- **Skipping the canary:** 7.2 carried all production traffic for 30 days, so restoring it is a return to a proven state. Skipping the canary is reasonable, and it helps the time budget.

## Optional robustness suggestions (not required)

1. **Lock contention in production.** On a production-size copy with no live traffic, `DROP COLUMN` gets its exclusive lock immediately. In production it could queue behind long-running transactions, and everything behind it would then block too. Setting a `lock_timeout` with retry on the down-migration, or using the online DDL options for your engine, would guard against this.
2. **Take the drop off the critical path.** 7.2 ignores the column, so the job could restore 7.2 first and drop the column afterward, or in a later cleanup. Then the outage clock depends only on the app deploy, not on DDL against a 400 GB table.
3. **Keep the discount data.** Orders placed while 7.3 was live will lose their recorded discount codes when the column is dropped. 7.2 doesn't need them, but finance or support might. You could copy the non-null values to a side table before the drop.
4. **When the outage clock starts.** The 15 minutes run from the declaration of failure. If customers are affected before the release is declared failed, keep detection-to-declaration time short so the overall outage stays well inside the contractual window.

VERDICT: GO