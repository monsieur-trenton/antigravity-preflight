# Review: Nightly Segment Compaction Plan

## Will it finish inside the window?
Yes, with a wide margin.

- **Throughput:** The rate of 1.0 TB/h was measured with the full-size workload on production-class hardware, using identical disks and identical job settings. The low CPU and I/O priorities are part of those settings, so this is a real measurement and not an extrapolation.
- **Worst case:** The largest night in the last 90 days was 1.3 TB, which takes about 1.3 hours. That leaves roughly 1.7 hours of slack, so the window is about 2.3 times the worst observed runtime.
- **Growth:** Input would have to reach about 3 TB per night before the window became a problem. That is more than double the current maximum.

## Do the low priorities put completion at risk?
No. nice 19 and the idle I/O class only slow the job when other work is competing for the host.

- Nothing else is booked on the storage host between 01:00 and 04:00.
- The backup agent, the one known co-tenant, finishes by 00:45, which is 15 minutes before the job starts.

The low priorities therefore protect other work without costing the job any throughput during its window.

## Is the cleanup step safe?
Yes. The previous segment files are removed with `rm -rf` only after two conditions are met:

1. The new segment set is completely written.
2. Its checksums match the source.

A run killed at 04:00 never reaches the delete. Its partial output is discarded and the old segments remain intact, so a failed night cannot lose data.

## Optional hardening (not required)
- **Runtime alert:** Alert if a run passes about 2.5 hours, or if nightly input passes about 2.5 TB, so growth is noticed well before the window is at risk.
- **Backup overrun alert:** Alert if the backup agent is ever still running at 01:00. The idle I/O class would then starve the compaction job behind it.
- **Delete guard:** Make sure the `rm -rf` path is built from validated, non-empty variables, for example using `set -u` and an explicit path check.

These would make a working plan more robust. None of them is needed for the plan to succeed or to follow its own rules.

VERDICT: GO