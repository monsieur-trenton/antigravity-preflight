The cache key `dash:{dashboard_id}:{range}` does not include `tenant_id`, so the plan breaks its own isolation rule.

**The core flaw**

The plan states three things that collide:
1. One Redis cluster is shared by every tenant.
2. Dashboard IDs are numbered per tenant from 1, so `42` exists in many tenants with different data.
3. The key is built only from `dashboard_id` and `range`.

So tenant A's dashboard 42 and tenant B's dashboard 42 map to the same key, for example `dash:42:7d`. If tenant A requests it first, the rendered response is cached. When tenant B requests its own dashboard 42 within 300 seconds, it gets tenant A's data. This directly violates the isolation rule. It isn't a rare edge case. Low IDs like 1, 2 and 3 will collide across almost every tenant all the time.

The other safeguards don't help:
- **Gateway authentication** attaches `tenant_id` correctly, but the handler never uses it in the key, so correct authentication still serves the wrong tenant's cached data.
- **"Only reads or writes the key built from the current request"** doesn't help, because the key built from tenant B's request is the same string as tenant A's.
- **The 300-second TTL** limits how long a given leaked entry lives, but the cache is refilled constantly, so the leak never stops.
- **Invalidation on edit** makes things worse. An edit to tenant A's dashboard 42 deletes the shared key, which also evicts the entry for tenant B's unrelated dashboard 42. Invalidation is not scoped to the tenant that made the edit.

**Required change**

- Put the tenant in the key: `dash:{tenant_id}:{dashboard_id}:{range}`. Take `tenant_id` only from the value the gateway attaches, never from client input.
- Scope invalidation the same way, so an edit deletes `dash:{tenant_id}:{dashboard_id}:*` for that tenant only. If you delete by pattern, use a tracked set of keys per dashboard or `SCAN`, not `KEYS`.
- Flush the existing cache, or change the key prefix (for example `dash:v2:`) when you deploy. Otherwise entries already stored under the old keys could still be served.

**Worth considering (optional)**
- Make the key-building function require `tenant_id` as a parameter, so a future code path can't skip it.
- Add a test that renders dashboard 42 for two different tenants and checks that each gets its own response.
- Leaving out the user ID is fine, given the stated rule that every dashboard is visible to all users in its tenant. Revisit that if per-user permissions or row-level filtering are ever added.

VERDICT: NO_GO