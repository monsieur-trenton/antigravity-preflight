# Review: Release 4.12 unique constraint on customers (tenant_id, email)

The plan holds together. The main risk is that existing duplicates would make the unique index build fail and abort the release. The plan covers that risk from both directions.

## Why it works

**No duplicates exist today.**
- Rows created before 4.9 were checked with `GROUP BY tenant_id, email HAVING COUNT(*) > 1` and returned nothing.
- The check ran on the primary, so replica lag cannot hide recent rows.
- It used current column values, so it reflects any later email edits.

**No duplicates have been created since 4.9.**
- The only path that writes emails locks the tenant row and rejects an email the tenant already has.
- That check runs against all existing rows, old and new. So it also blocks a new row that would duplicate a pre-4.9 one.
- It covers updates as well as inserts.

**No duplicates can appear during the build.**
- The 4.9 guard still applies while the index is building.
- `CREATE UNIQUE INDEX CONCURRENTLY` also enforces uniqueness on writes made during the build.

**The NULL edge case is covered.**
- The GROUP BY query treats NULLs as one group, so it would have flagged repeated NULL emails.
- A unique index would accept repeated NULLs anyway. The check is stricter than the index, which is safe.

**The concurrent build is suitable for 38M rows.**
- `CONCURRENTLY` avoids blocking writes for the whole build.
- The final step that attaches the index as the constraint (`ADD CONSTRAINT … UNIQUE USING INDEX`) needs only a brief lock.

**The DROP INDEX IF EXISTS step is correct.**
- In production it does nothing today.
- If a concurrent build fails partway, it leaves an INVALID index behind. This step makes a re-run clean that up instead of failing on the existing name.

**The runbook rule is consistent with the code.**
- The 4.12 sign-up code depends on the constraint.
- The release aborts if the constraint cannot be applied.
- So that code never ships without the constraint it relies on.

## Optional hardening (not required)

- **Transaction wrapping:** Confirm the migration tool runs this migration outside a transaction block. `CREATE INDEX CONCURRENTLY` cannot run inside one. Most tools need an explicit opt-out (for example, `disable_ddl_transaction!` or `atomic = False`).
- **Lock timeout:** Set a short `lock_timeout` on the `ADD CONSTRAINT … USING INDEX` step. This keeps it from waiting behind a long-running transaction and stalling traffic while it waits.
- **Build monitoring:** Watch the build through `pg_stat_progress_create_index`. Afterward, confirm the index is valid (`pg_index.indisvalid`) before the attach step.

None of these changes the outcome of the plan as written.

VERDICT: GO