# Review: Date-Parsing Library Upgrade (2.8 → 3.0)

## The central problem: the plan's own rule is unverified

The plan's one hard rule is that **all 14 existing callers must behave exactly as they do today**. Nothing in the plan establishes that they will:

- **This is a major-version upgrade.** Under semantic versioning, 2.x → 3.0 is exactly where breaking changes are allowed. Date-parsing libraries often change defaults between major versions, such as timezone handling, ambiguous-format resolution (DD/MM vs MM/DD), two-digit years, leniency and DST edge cases.
- **None of the 14 callers has been run against 3.0.** The only testing so far covers the refunds module, which is the code that *wants* the new behaviour. That says nothing about whether existing behaviour is preserved.
- **A failure cannot be undone.** If any caller's output shifts, wrong due dates go out at 06:00 and the emails cannot be recalled. A deploy at 14:00 and a run at 02:00 leaves time to roll back only if someone notices a problem, and the plan has no step that would notice one.

As written, the plan ships an untested breaking-change candidate into the path of an irreversible output. Whether it holds the rule depends on luck, not on anything the plan does. This is a missing required step, not an optional hardening.

## What the plan needs before the 14:00 deploy

1. **Exercise all 14 callers against 3.0 and compare the output with 2.8.** Use realistic and edge-case inputs: month ends, leap days, DST transitions, timezone boundaries and every input format the callers actually receive. Ideally replay last night's invoice inputs through both versions and diff the due dates. Any difference blocks the deploy.
2. **Review the 3.0 changelog and migration guide** for changes to defaults. Pin any changed settings explicitly in the callers so they keep 2.8 behaviour.
3. **Add a gate before the 02:00 run**, either a dry run or a check of computed due dates against the 2.8 baseline, with a clear rollback or invoice-hold procedure if they differ.

## Items that check out

- **Runtime:** 3.0 needs runtime 11 or later, and every billing host runs 12. No issue.
- **Archived reporting tool:** it has its own pinned 2.8 copy, is not one of the 14 callers and is not redeployed. It is unaffected.
- **Timing:** the 12-hour gap between deploy and invoice run is enough for verification and rollback, provided the plan actually includes them.

## Summary

The infrastructure details are fine. However, the plan's only stated invariant depends on 14 callers that have never been run against a major-version upgrade, and a breach would be irreversible and visible to customers. The plan cannot be approved until it shows that those callers' output is unchanged.

VERDICT: NO_GO