**Review: Address backfill geocoding plan**

The plan holds up. I checked each claim against the stated rule that the account must never exceed its rate limits.

**Throughput and duration**
- 4 workers × 1.25 req/s = 5 req/s.
- 240,000 ÷ 5 = 48,000 s ≈ 13.3 hours. The arithmetic is correct.

**Per-second limit (20 req/s)**
- Backfill peaks at 5 req/s and signup at 3 req/s, for 8 req/s combined.
- That uses 40% of the limit, leaving 12 req/s of headroom. Even a burst-tolerant client limiter or some clustering of signup traffic would not plausibly close that gap.

**Daily limit (1,000,000 req/day)**
- The run is capped at 240,000 requests, and the no-retry rule makes that a hard ceiling.
- If the 13.3-hour run crosses midnight, the requests split across two days. Either way, no single day can see more than 240,000 + 50,000 = 290,000.
- That is 29% of the daily limit.

**Request bound**
- Failed lookups are not retried within the run, so total volume cannot grow past the planned 240,000. This closes off the most common way backfills overrun quotas.

**Limits source**
- The limits are confirmed in writing by the provider, not inferred from documentation, so they are a sound basis for the plan.

**Optional hardening (not required)**
- Have the job stop on the first 429 or rate-limit warning rather than just logging it.
- Cap total requests in the job's config as a backstop against an accidental rerun or a bug in the worker count.
- Schedule the run during low-signup hours to widen the margin further.

The rule is met on both the per-second and daily dimensions with large margins, and the request count is strictly bounded.

VERDICT: GO