# Review: Nightly Compaction Plan

The plan holds together. Each claim it depends on is backed by something stated.

**Timing fits the window with a wide margin.**
- The worst daily volume in 90 days is 1.3 TB.
- The measured rate is 1.0 TB/h, so the worst case takes about 1.3 h against a hard 3 h window.
- That is more than 2× headroom. Volume could grow to about 3 TB before the window becomes a problem.
- The rate comes from a full-size rehearsal on a production-class host with the same disks and the same job settings. Those settings include nice 19 and the idle I/O class, so any slowdown from low priority is already in the 1.0 TB/h figure.

**Low priority does not threaten completion.**
- The idle I/O class only yields to other I/O.
- Nothing else is scheduled on the host from 01:00 to 04:00.
- The backup agent, the one known neighbour, finishes at 00:45, 15 minutes before the job starts.
- So there is no scheduled contention that could stretch the run toward the kill time.

**Killed runs and deletion are handled safely.**
- A killed run discards its partial output.
- Old segments are deleted only after the new set is fully written and its checksums match the source.
- So a killed or failed run never destroys the only copy of the data, and the `rm -rf` is safely gated.

**Optional hardening (not required):**
- Alert if a run goes past about 2 h. That would catch an unscheduled I/O consumer or a degraded disk before the 04:00 kill.
- Track nightly volume against the roughly 3 TB ceiling so long-term growth is visible well before it matters.
- Alert on backup runs that overrun 00:45, since overlap would cut into the job's I/O share.
- Use an explicit path variable with a non-empty check in the `rm -rf` step, as general defensive practice.

None of these fix a flaw. The plan works as written.

VERDICT: GO