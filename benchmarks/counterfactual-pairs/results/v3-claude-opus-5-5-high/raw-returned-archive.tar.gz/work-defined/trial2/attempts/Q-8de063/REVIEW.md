# Review: Checkout payment retry plan

**The plan meets its rule. A customer cannot be charged twice for one order.** I'd suggest some changes, but the core design is correct.

## Why the no-double-charge rule holds

- **Stable key.** The idempotency key is the order's UUID. It is created once, stored with the order, and sent unchanged on every attempt. All attempts for an order therefore carry the same key.
- **Within the dedup window.** All attempts finish within 10 minutes, well inside the processor's 24-hour window. A retry after an ambiguous timeout either replays the original charge's result or creates the first charge. It never creates a second one.
- **Retrying after timeouts is safe.** The plan treats a timeout as "may have been charged," and the stable key handles exactly that case. Retrying here is the right choice, and the stated reason (don't leave the order unpaid because the processor was slow) is sound.

## Suggested changes

1. **Retrying definite failures does nothing.** The processor returns the original result for a repeated key. So if the processor actually received and declined the request (a card decline or validation error, for example), retrying with the same key just returns that same failure up to 3 more times.
   - Limit automatic retries to timeouts and transport errors, where the outcome is unknown.
   - Surface definite failures immediately so the customer can fix their payment details.
   - Check how the processor handles its own 5xx errors. If it caches them under the key, retries won't help those either.

2. **Define what happens when all retries run out.** After 4 attempts the order can still be in an unknown state, for example if every attempt timed out. The plan doesn't say what happens next.
   - Mark the order "payment pending/unknown," not "failed."
   - Reconcile by querying the processor by idempotency key, or by order, before telling the customer or allowing another payment.

3. **Make the 24-hour boundary explicit.** The 10-minute limit keeps the worker safe. Two other paths could reuse the key after 24 hours, when the processor would treat it as a new charge:
   - A re-enqueued job after a crash or redeploy.
   - A manual "retry payment" action.

   These paths should reconcile first or refuse to submit. Don't rely on the key alone.

4. **Keep the payload identical across attempts.** If the amount or other details can change between attempts, the processor may reject the request or behave inconsistently. Freeze the charge request when the order is placed.

5. **Record attempts.** Log each attempt and its outcome against the order. This helps with reconciliation and support.

VERDICT: GO_WITH_CHANGES