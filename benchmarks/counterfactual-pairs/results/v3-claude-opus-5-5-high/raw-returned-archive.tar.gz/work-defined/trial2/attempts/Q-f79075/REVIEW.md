## Review

**The plan breaks its own rule against charging a customer more than once per order.**

The problem comes from combining three things the plan says:

1. A timed-out submission may already have been charged.
2. Retries are sent even when a timeout's outcome is unknown.
3. Every retry uses a **fresh random UUID** as the idempotency key, and the processor treats a new key as a new charge.

Here is one way it fails:
- Attempt 1 (key A) reaches the processor and the charge succeeds, but the response times out.
- The worker retries with key B. The processor sees a new key and charges the customer again.
- Further timeouts can repeat this, up to **4 charges** for one order.

Generating a new key per attempt turns the idempotency key into a plain request ID. That throws away the protection the processor offers, at the exact moment it is needed.

### Required change
- **Create the key once per order, not per attempt.** You can derive it from the order ID, or generate a UUID once and save it with the order before the first attempt.
- **Reuse that key on every retry** for the order. All attempts finish within 10 minutes, well inside the processor's 24-hour window. So a retry after an ambiguous timeout either returns the original result or creates the charge for the first time, never a second charge.
- **Store the key before the first send.** If the worker crashes and the job is picked up again, the new worker must reuse the same key.

### Suggested improvements (secondary)
- Treat a definite failure (such as a decline) differently from a timeout. Retrying a decline with the same key just returns the same decline. If you want a real second try, such as with a corrected card, that should be a deliberate new payment intent with its own key.
- If an order could ever be resubmitted after 24 hours (manual replays, backfills), check the order's payment status with the processor first. The idempotency key won't protect you after the window ends.
- Log the idempotency key with each attempt so you can reconcile charges later.

Once the key is fixed per order, the retry design is sound. As written, though, it will double-charge customers whenever a timeout follows a successful charge.

VERDICT: NO_GO