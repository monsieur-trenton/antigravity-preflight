# Review: Release 4.12 unique constraint on customers (tenant_id, email)

## Blocking issue: duplicates before 4.9 have never been checked

The unique index and the release both depend on one assumption: that the table contains no duplicate (tenant_id, email) pairs. Nobody has verified this.

- **Post-4.9 rows are covered.** The tenant-row lock and duplicate check prevent new duplicate pairs, assuming it really is the only write path. That includes imports, admin tools, backfills and support scripts.
- **Pre-4.9 rows are unknown.** These rows were never checked, and no duplicate query has been run in production. The 4.9 guard was added for a reason. Before it, concurrent sign-ups or retries could have created duplicate pairs, and at 38M rows even a small rate would leave some.

If even one duplicate pair exists, here is what happens:

1. `CREATE UNIQUE INDEX CONCURRENTLY` scans the table, possibly for a long time at this size, and then fails.
2. It leaves an **INVALID** index named `customers_tenant_email_uq`. Postgres keeps maintaining it on every write, but it never enforces anything.
3. The constraint cannot be attached.
4. Under the runbook, **the whole 4.12 release is aborted.**

So whether 4.12 ships depends on a fact nobody has looked at, and you would find out only at the end of a long production index build. I can't say the plan will fail. I also can't say it will work, and the plan has no step that would tell you which in advance. That's why I'm not approving it as written.

## Required change

Before the release window, run a duplicate check against production or a recent production snapshot:

```sql
SELECT tenant_id, email, count(*)
FROM customers
GROUP BY tenant_id, email
HAVING count(*) > 1;
```

- **Zero rows:** the main risk is gone, and the plan works with the smaller changes below.
- **Any rows:** you need a cleanup step before the index build: merge, rename or soft-delete the duplicates, with a product decision on which account survives. That has to be a separate, reviewed data fix, not something improvised during the release.

Also check whether duplicates exist that differ only by letter case or whitespace, such as `Foo@x.com` and `foo@x.com`. These won't break the index build. But if 4.12 sign-up compares emails case-insensitively while the index is case-sensitive, the constraint won't give the guarantee the sign-up code relies on.

## Smaller improvements (non-blocking once duplicates are ruled out)

- **The DROP is a good idea, but make it concurrent.** `DROP INDEX IF EXISTS` does nothing on the first run. It matters on a retry, because it removes the INVALID index left by a failed build. Use `DROP INDEX CONCURRENTLY IF EXISTS` so the retry doesn't take an ACCESS EXCLUSIVE lock on a hot 38M-row table. Document that this is the reason the statement is there.
- **Transaction wrapping.** `CREATE INDEX CONCURRENTLY` cannot run inside a transaction block. Make sure the migration framework doesn't wrap this migration in one.
- **Attaching the constraint.** `ALTER TABLE customers ADD CONSTRAINT ... UNIQUE USING INDEX customers_tenant_email_uq` is quick but still takes a brief strong lock. Set a `lock_timeout` and plan to retry rather than queue behind long transactions.
- **Check validity explicitly.** After the build, confirm `pg_index.indisvalid` is true before attaching. Don't infer success from the migration simply finishing.
- **Ordering with the sign-up code.** 4.12 sign-up depends on the constraint existing. Deploy the migration before the code, or make sure the code isn't live until the constraint is attached.
- **Confirm "only write path."** Briefly audit for other writers of `customers.email`, such as bulk import, admin UI or data-fix scripts, that bypass the 4.9 lock.

## Summary

The mechanics are mostly sound. The concurrent build, attaching the index as the constraint, and the DROP as retry cleanup all work. The problem is that the release's go/abort outcome rests on an untested assumption about 38M rows, and the plan has no step to check it or fix it. Run the duplicate query first. If it comes back empty and the smaller fixes above are applied, this becomes GO_WITH_CHANGES.

VERDICT: NO_GO