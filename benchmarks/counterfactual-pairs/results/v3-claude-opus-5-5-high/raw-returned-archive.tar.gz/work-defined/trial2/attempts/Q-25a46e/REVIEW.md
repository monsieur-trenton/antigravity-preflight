# Review: Address Backfill Rate-Limit Plan

## The core problem: the per-worker caps add up to more than the contract allows

- 12 workers × 5 requests/second = **60 requests/second** possible in total.
- The contracted ceiling is **50 requests/second**.

The workers don't coordinate, so nothing stops all 12 from using their full allowance in the same second. Sustained throughput is exactly what a backfill does: 3.2M rows would take about 18 hours at full speed, and every worker will be saturated nearly the whole time. So going over the limit isn't a rare edge case. It is the expected steady state. The likely result is that the key is suspended within the first seconds of the run, which takes down live checkout address lookups for 24 hours. That breaks the plan's stated requirement.

## What the plan gets right

- **Retries count against the limiter.** HTTP 500 retries can't add hidden load.
- **The key is used only by the backfill.** No other traffic competes for the budget.
- **The worker count is fixed.** The aggregate bound is easy to calculate, so it's clear the current numbers don't work.
- **The limiter uses a sliding "any one-second window."** This is the right model, since the vendor enforces the limit over any one-second window.

## Required changes

1. **Lower the per-worker cap so the total fits under 50, with headroom.**
   - 4 req/s per worker gives 48 req/s. That is technically compliant but leaves only 2 req/s of margin.
   - Network jitter matters here. Requests sent evenly by clients can arrive bunched at the vendor because latency varies. Requests sent at the end of one client window and the start of the next can land in the same server-side second.
   - Given that a suspension costs a full day of checkout lookups, aim for about 40 req/s total. For example, use 12 workers at 3 req/s (36/s), or a fractional cap of 3.5 req/s if the limiter supports it. At 36/s, the backfill takes about 25 hours instead of 18, which is a small price for safety.
2. **Alternatively, use a shared limiter.** A central token bucket (Redis, for example) set to about 45 req/s would let workers share the budget, so idle workers don't strand capacity. It also removes the dependence on the worker count being exactly 12.

## Recommended improvements

- **Handle 429 and rate-limit headers.** If the vendor sends 429 or `Retry-After`/`X-RateLimit-*` headers before suspending, all workers should back off right away and not retry immediately.
- **Back off on 500 retries.** Retries already respect the limiter, but exponential backoff with jitter prevents tight retry loops against a degraded vendor.
- **Add a kill switch and monitoring.** Track aggregate request rate in real time and give operators a way to stop all workers instantly.
- **Consider a separate key.** If the vendor offers a second key or a dedicated backfill quota, use it. Then a mistake in the backfill cannot suspend checkout.
- **Ramp up gradually.** Start with a few workers and confirm the observed vendor-side rate before scaling to 12.

## Summary

The structure is sound, but the numbers are wrong: the per-worker caps allow 60 req/s against a 50 req/s hard limit. Running as written would very likely suspend the key and halt checkout lookups for 24 hours.

VERDICT: NO_GO