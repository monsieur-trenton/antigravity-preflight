# Review: Inventory Service Locking Plan

## Critical issue: lock-order inversion causes deadlock

The two paths take the same two mutexes in opposite orders:

| Path | First lock | Second lock (while holding first) |
|---|---|---|
| Checkout handler | `stock_mu` | `reserve_mu` |
| Restock worker | `reserve_mu` | `stock_mu` |

The plan itself says these paths regularly run at the same moment on different threads. This interleaving will happen:

1. A checkout thread acquires `stock_mu`.
2. The restock worker acquires `reserve_mu`.
3. Checkout blocks waiting for `reserve_mu`, which restock holds.
4. Restock blocks waiting for `stock_mu`, which checkout holds.

Both locks block with no timeout, so neither thread ever proceeds. Every later checkout also queues forever on `stock_mu`, and the nightly audit hangs too. The pod stops selling but keeps passing its liveness probe. That is exactly the failure the requirement rules out.

This is not a rare edge case. Restock runs every 30 seconds into continuous checkout traffic, so the window recurs many times a day, and the deadlock will eventually happen.

## What is fine

- **Nightly audit:** it takes only `stock_mu` and acquires nothing else while holding it, so it cannot join a wait cycle. Its 2-second hold only adds latency. Note that it widens the window in which checkout holds `stock_mu` and waits, but it does not cause deadlock by itself.
- **No other acquirers:** this means fixing the two paths above is enough to remove the cycle.

## Required changes

1. **Use one global lock order.** The simplest fix is to always take `stock_mu` before `reserve_mu`. Change the restock worker to lock `stock_mu` first, then `reserve_mu`. Write this order down in code comments next to both mutex declarations. Add a debug-build assertion or lock-order checker (for example, a lockdep-style rank check) so a future code path cannot reintroduce the inversion.
   - Alternatives: merge the two into a single mutex, since every path that needs both already takes both. Or use a scoped multi-lock primitive that acquires both deadlock-free, such as C++ `std::scoped_lock(stock_mu, reserve_mu)`.
2. **Optional defense in depth:** use timed or try-lock acquisition with backoff and an error or metric on timeout, so a future ordering bug fails loudly instead of hanging.
3. **Fix the liveness probe.** Have it exercise a path that takes the locks, or check a heartbeat updated by checkout and restock. Then a wedged pod gets restarted automatically instead of waiting for a human. This does not replace the ordering fix, but it limits the damage from any future hang.
4. **Consider shortening the audit's hold on `stock_mu`.** For example, snapshot under the lock and do the analysis after releasing it. This reduces checkout latency spikes.

## Conclusion

As written, the plan contains a textbook ABBA deadlock between two paths it says run concurrently. It directly violates its stated "must never deadlock" requirement.

VERDICT: NO_GO