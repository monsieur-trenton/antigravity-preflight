## Review

**Blocking issue: the production flag default contradicts the stated rule.**

The plan says new code paths ship to production *disabled* and are turned on later only through their own approved flag change. But `flags.yaml` sets `checkout.split_payment` to `true` for production. Deploying 4.12 as written would:

- Turn split-payment on in production the moment the release rolls out, with no separate approved change.
- Break the claim that "production customers keep going through [single-payment] as long as the flag is off." The flag won't be off.
- Make the "deferred to a subsequent change ticket after two weeks of staging traffic" step meaningless, because production would already be live.
- Start writes to `split_payment_ref` in production immediately, which undercuts the "no writes reach it with the flag off" safety argument.

**Required fix:** set the production default to `false` in `flags.yaml`. Dev and staging can stay `true`.

**Other points (non-blocking once the above is fixed):**

1. **CI "mirroring production" wording.** Running the suite with the flag both on and off is good. But production at release will run flag-off only, so only the forced-off pass mirrors production. Consider also running the flag-off pass against the production config file itself. That would have caught this exact error.
2. **Config guard.** Add a CI or lint check that fails if any new flag defaults to `true` in production. That enforces the "ship disabled" rule mechanically instead of relying on review.
3. **30-second cache window.** During a flip, pods will disagree for up to 30 seconds. Confirm that a checkout started on one path and finished on a pod running the other path (e.g., in retries or multi-request flows) is handled safely. Also confirm that the rollback (flipping back to off) handles orders already holding a `split_payment_ref`.
4. **Migration.** The sub-second lock on a full-size staging copy is reassuring. Still, schedule it for low traffic and set a lock timeout, since production contention may differ from staging.
5. **Activation ticket criteria.** "Two weeks of staging traffic" is a duration, not a success criterion. Define what must be true (error rates, reconciliation checks, payment-provider results) before the production flip is approved.

As written, the plan breaks its own core rule and would enable the feature in production at deploy time.

VERDICT: NO_GO