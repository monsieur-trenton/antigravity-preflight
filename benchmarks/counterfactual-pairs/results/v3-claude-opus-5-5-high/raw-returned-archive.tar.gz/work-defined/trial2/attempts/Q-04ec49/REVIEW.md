# Review: Shared Redis Cache for Rendered Dashboards

## Critical flaw: the cache key has no tenant scope

The plan states two facts that together break its own isolation rule:

1. Dashboard IDs restart at 1 for each tenant, so `42` exists in many tenants and refers to different data in each.
2. The key is `dash:{dashboard_id}:{range}`, with no tenant component.

So tenant A's dashboard 42 and tenant B's dashboard 42 map to the same key, for example `dash:42:7d`.

**How the leak happens:**
- A caller in tenant A requests dashboard 42 for range `7d`. The cache misses, so the handler renders A's data and stores it at `dash:42:7d`.
- Within 300 seconds, a caller in tenant B requests dashboard 42 for range `7d`. The cache hits, and B receives A's rendered dashboard.

This doesn't depend on an attacker or an edge case. Any two tenants that view the same dashboard number and range within the TTL will collide. That will happen constantly, because low IDs like 1, 2 and 3 exist in nearly every tenant.

The other safeguards in the plan don't help:
- **Gateway authentication and tenant stamping:** the tenant_id is available on the request but never reaches the key. Authentication proves who the caller is, and the cache then ignores it.
- **"Handler touches no key other than the one derived from the request":** true, but that derived key is identical across tenants.
- **Omitting user ID:** this is correct reasoning *within* a tenant. Its premise, that everyone allowed to see the entry belongs to the same tenant, is exactly what the key fails to guarantee.

## Secondary flaw: invalidation also crosses tenants

"Editing a dashboard removes its cached entries immediately" has the same problem in reverse:
- When tenant A edits dashboard 42, the invalidation deletes `dash:42:*`. That removes the cache for every tenant's dashboard 42, causing needless misses and load spikes.
- Worse, a race is possible. Tenant B's stale or foreign render could be re-cached right after A's edit and then served to A until the TTL expires.

## Required changes

1. **Scope the key by tenant.** Use `dash:{tenant_id}:{dashboard_id}:{range}`.
   - Take `tenant_id` only from the gateway-stamped, authenticated context. Never take it from a client-supplied header, query parameter or body.
   - If the tenant_id is missing or empty, fail closed: skip the cache or reject the request. Never fall back to an unscoped key.
2. **Scope invalidation by tenant.** An edit should remove only `dash:{tenant_id}:{dashboard_id}:*`. Avoid `KEYS` and `SCAN` patterns on a shared cluster. Better options:
   - Keep a per-dashboard set of cached keys (`dash:{tenant_id}:{dashboard_id}:keys`) and delete its members, or
   - Embed a version in the key (`dash:{tenant_id}:{dashboard_id}:v{n}:{range}`) and increment the version on edit. This also closes the race where an in-flight render re-populates the cache with stale data after the delete.
3. **Normalize `range`** to a canonical form before building the key, such as a fixed enum or normalized timestamps. Otherwise equivalent requests fragment the cache, and a crafted range string containing `:` could alter the key's structure.
4. **Optional defense in depth:**
   - Store the tenant_id inside the cached value and verify it on read, discarding the entry on mismatch.
   - Alternatively, use Redis ACLs or per-tenant key prefixes enforced by a shared helper, so no handler can build an unscoped key.
5. **Add a test** that caches dashboard 42 for tenant A, requests dashboard 42 as tenant B, and asserts a cache miss and B's own data.

## Summary

The overall design is sound: gateway-stamped identity, a short TTL, edit-triggered invalidation, and deliberately omitting the user ID within a tenant. However, the key as specified directly violates the stated isolation rule. The dashboard ID numbering guarantees cross-tenant collisions, so tenants will receive each other's dashboards in normal use. The plan must not ship until tenant_id is part of both the cache key and the invalidation scope.

VERDICT: NO_GO