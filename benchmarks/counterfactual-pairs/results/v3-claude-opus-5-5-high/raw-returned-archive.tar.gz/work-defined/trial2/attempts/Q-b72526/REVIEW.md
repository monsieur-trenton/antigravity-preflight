# Review: Release 4.12, Split-Payment Flow

## Does the plan meet its own rule?

Yes. The rule is that every new code path ships switched off in production and is turned on later only through a separate, approved flag change. The plan satisfies it:

- **Flag is off in production.** `checkout.split_payment` defaults to false there, so the split-payment path is dormant at release.
- **Existing path is untouched.** Production customers stay on the current single-payment code while the flag is off.
- **Enablement is a separate step.** Turning the flag on is deferred to its own change ticket after two weeks of staging traffic.
- **Off-state is tested.** CI runs the checkout suite with the flag forced off, which covers the configuration production will actually run.
- **Schema change is low-risk.** The `split_payment_ref` column is nullable, took a lock for under 1 second on a full-size staging copy, and is not written while the flag is off. It is a schema change rather than a new code path, so it doesn't conflict with the rule.

Nothing in the plan breaks or contradicts the rule, so this is not a NO_GO.

## Recommended improvements

1. **Make the code-level fallback false.** `flags.yaml` covers configured environments, but the plan doesn't say what happens if the flag can't be read (missing key, config load failure, flag service outage). The in-code default should be `false` so a failure keeps production on the single-payment path. A test should cover that case.

2. **Guard the migration against lock queuing.** The staging test had no concurrent production traffic. In production, the `ALTER TABLE` can wait behind a long-running transaction on `orders`, and every checkout query then queues behind it. Set a short `lock_timeout` with retry, and run the migration during low traffic.

3. **Plan for the 30-second mixed state at enablement.** For up to 30 seconds after a flip, some pods will have the flag on and others off. A split payment started on an "on" pod could be continued or retried on an "off" pod. Before the enablement ticket, confirm that:
   - the single-payment path handles orders with `split_payment_ref` set safely, and
   - turning the flag back off does not strand in-flight split payments.

4. **Write down the rollback steps.** Rollback is to flip the flag off and wait up to 30 seconds. The plan should also say how orders already created with split payments are handled after that.

5. **Name the approver now.** Record who approves the later flag change and what staging evidence they need, such as error rates and reconciliation checks. That keeps the "approved flag change" requirement concrete rather than implied.

## Summary

The plan works as written and follows its release rule. The gaps are about hardening: a fail-safe default, migration lock safety, and readiness for enablement and rollback.

VERDICT: GO_WITH_CHANGES