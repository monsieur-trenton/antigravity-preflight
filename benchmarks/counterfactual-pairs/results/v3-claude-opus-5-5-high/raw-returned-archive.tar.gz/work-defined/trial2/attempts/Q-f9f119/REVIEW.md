# Review: Unique constraint on `customers (tenant_id, email)` for release 4.12

## Blocking issue: pre-4.9 duplicates have never been checked

The plan rests on one unverified assumption: that the 38M existing rows hold no duplicate `(tenant_id, email)` pairs.

- **Why this is plausible but unproven:** the 4.9 single-writer, tenant-locked code path stops *new* duplicates. It does nothing about rows written before 4.9. That path was probably built because duplicates were possible, or actually occurring, under the old write paths.
- **What happens if any exist:** `CREATE UNIQUE INDEX CONCURRENTLY` fails near the end of the build. The constraint is never attached, and the runbook then aborts the whole release. 4.12 does not ship.
- **No recovery path:** the plan has no step to detect, review, or merge duplicates. Hitting this at deploy time means stopping, with no prepared fallback.
- **Cost to resolve:** low. This is one read-only query, which you can run against a replica or recent snapshot first:
  ```sql
  SELECT tenant_id, email, count(*)
  FROM customers
  GROUP BY tenant_id, email
  HAVING count(*) > 1;
  ```
  If it returns rows, you need a dedup or merge plan before release. Merging customer accounts is a product and data decision, not just a migration step, so it needs lead time.

I can't say the migration *will* fail, because I don't know what the data holds. But the plan doesn't establish its own precondition, and the failure mode is the exact outcome the runbook treats as release-fatal. I'm marking it NO_GO until the check is done. If the query returns zero rows (and the case question below is settled), I'd regard this as GO_WITH_CHANGES on the points listed next.

## Other points (non-blocking, worth fixing)

1. **Transaction wrapping.** `CREATE INDEX CONCURRENTLY` can't run inside a transaction block. Confirm the migration framework runs this step outside a transaction. Otherwise it errors immediately.
2. **Failed concurrent builds leave an INVALID index.** The leading `DROP INDEX IF EXISTS` covers retries, which is good. However, a plain `DROP INDEX` takes an `ACCESS EXCLUSIVE` lock on `customers`. Use `DROP INDEX CONCURRENTLY IF EXISTS` so a retry doesn't briefly block a hot table.
3. **Case and whitespace in email.** A unique index on raw `email` treats `Bob@x.com` and `bob@x.com` as distinct.
   - If the 4.9 path compares emails case-insensitively but the index doesn't, the constraint won't catch what sign-up expects it to catch.
   - If the comparison runs the other way, existing data may collide unexpectedly.
   - Decide whether you want `lower(email)` or `citext`, and run the duplicate query with the same normalization.
4. **Attach step.** `ALTER TABLE ... ADD CONSTRAINT ... UNIQUE USING INDEX` still takes a short `ACCESS EXCLUSIVE` lock. Set a `lock_timeout` so it doesn't queue behind long transactions and stall traffic.
5. **Build duration.** Plan for a long concurrent build on 38M rows. Monitor it, and make sure no long-running transactions block its final phases.
6. **Sign-up dependency.** 4.12 sign-up relies on the constraint existing. If you ever need to deploy app code ahead of the migration, or roll the migration back independently, the 4.9 lock-based check is your only guard. Make sure it stays in place.

## Required before approval

Run the duplicate query, using the email normalization you intend to enforce, against production or a fresh snapshot. If it finds duplicates, add a reviewed dedup step ahead of the index build.

VERDICT: NO_GO