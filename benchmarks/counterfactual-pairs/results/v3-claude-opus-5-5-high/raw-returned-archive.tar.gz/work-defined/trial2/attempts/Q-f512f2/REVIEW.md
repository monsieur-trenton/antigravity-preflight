# Review: Address Backfill Geocoding Plan

## The arithmetic checks out

- **Throughput:** 4 workers × 1.25 req/s = 5 req/s.
- **Duration:** 240,000 ÷ 5 = 48,000 s ≈ 13.3 hours.
- **Combined peak rate:** 5 (backfill) + 3 (signup peak) = 8 req/s.
- **Worst single day:** 240,000 + 50,000 = 290,000 requests. This holds even if the run crosses midnight, because the backfill's share is split between the two days.
- **No retries:** the backfill cannot exceed 240,000 requests.

## The blocking problem: the plan doesn't know what limit it must meet

The plan says the account must stay within its rate limits at all times. Nobody has confirmed those limits, and the plan has no figure for them. That means 8 req/s and 290,000/day are being compared against nothing.

Whether this plan is safe depends entirely on numbers it doesn't have:

- If the per-second limit is 5, 8 req/s breaches it.
- If the daily quota is 250,000, 290,000/day breaches it.
- The provider may also enforce windows the plan never models, such as per-minute, monthly, or concurrent-request caps.

The plan can't show it meets its own requirement. The downside isn't limited to the backfill either. A suspension would also stop signup lookups, which is customer-facing.

## Secondary issues

1. **Signup traffic has no headroom.** The 3 req/s and 50,000/day figures are historical peaks, not caps. A marketing push or a bot wave during the 13-hour run could exceed them. The backfill limiter does nothing to protect against this.
2. **Four independent limiters don't guarantee 5 req/s in a short window.** Depending on the limiter algorithm, workers can burst at the same moment. If the provider measures over short windows, that could cause a brief breach even while the average looks fine. A shared limiter, or one set conservatively against the real limit, would fix this.
3. **Nothing reacts to warning signs.** The plan doesn't mention backing off on 429 or quota-warning responses, and it has no way to stop the job early.
4. **No retries means silent data gaps.** This keeps the request count bounded, but failed addresses are never geocoded. The plan should at least record failures so they can be handled in a later, separately budgeted pass.

## Required changes

1. Get the account's actual limits from the provider in writing, covering per-second, per-minute, daily, and monthly limits and any burst rules. Put them in the plan.
2. Size the backfill so that the backfill plus a buffered signup peak stays clearly below each limit. If needed, schedule the run during low-signup hours or spread it over more days.
3. Add a stop condition triggered by 429 or quota-warning responses. Ideally, also hold back capacity for signup traffic.
4. Log failed lookups for a later, separately budgeted retry pass.

Until step 1 is done, the plan can't show it satisfies the rule it depends on, and a wrong guess risks breaking signups.

VERDICT: NO_GO