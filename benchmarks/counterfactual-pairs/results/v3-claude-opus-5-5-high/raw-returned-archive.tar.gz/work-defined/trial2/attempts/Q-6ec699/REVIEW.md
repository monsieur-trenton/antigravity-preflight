# Review: Checkout capture retry plan

The retry mechanics are reasonable. The problem is that the plan's safety depends on something nobody has verified.

## Blocking issue: the no-duplicate-capture rule rests on an unverified assumption

The plan sets an absolute rule: a capture must never take effect more than once. It also says:

- A resend can reach the server after the original capture already succeeded, for example when the client times out after the server has completed the charge.
- The only protection against a second charge is the shared idempotency key.
- No one has checked that the capture endpoint collapses repeats with the same key, and the payments team hasn't confirmed it.

If the endpoint ignores the key, or only partly honours it, every timeout after a successful capture can bill the customer again, up to 5 extra times. The plan therefore cannot guarantee its own core rule. This is a gap in correctness, not something to polish later. It has to be closed before the plan ships.

## What to confirm with the payments team, and test

1. **Basic deduplication.** A second request with the same key after a successful capture returns the original result and creates no new charge.
2. **Concurrent requests.** A resend can arrive while the original is still being processed, because the client timed out but the server hasn't finished. Confirm what happens then. Some implementations return 409 or a "request in progress" error, which the client must handle without treating it as a failure.
3. **Retention window.** Find out how long keys are remembered. With 200 + 400 + 800 + 1600 + 3200 ms of backoff plus the timeouts themselves, the retry window is short. But any later manual or batch retry must also fall within that window.
4. **Payload binding.** Find out what happens if the same key arrives with a different amount or body. Ideally the server rejects it rather than silently accepting it.
5. **Key scope.** Confirm whether keys are scoped per merchant or account, so that UUIDs cannot collide across tenants in practice.

## Other improvements (not blocking)

- **Outcome after all retries fail.** After the 5th resend fails, it's unknown whether the customer was charged. The plan should record the order as "capture unknown" and reconcile, for example by querying the capture's status by idempotency key or order ID. It should not report the capture as failed or let the customer start a fresh checkout with a new key.
- **Errors that shouldn't be retried.** State explicitly that 4xx responses, especially 409 and 422, are not retried. Also define how a 409 meaning "in progress" is treated, if the server uses one.
- **Jitter.** Add random jitter to the backoff so that many clients don't retry in lockstep during a payments outage.
- **Persisting the key.** Make sure the UUID is stored with the order before the first call. A client restart mid-retry must reuse the same key, not generate a new one.
- **Library retries.** Turning off automatic retries in the HTTP library is good. Also check that no other layer silently retries, such as a proxy, service mesh, or SDK wrapper.

## Summary

The retry design is fine, but the guarantee against duplicate captures has not been established. As written, the plan can break its own stated rule. Confirm and test the endpoint's idempotency behaviour, including concurrent requests, and add a way to resolve captures whose outcome is unknown.

VERDICT: NO_GO