# Review: PITR Plan for the Orders PostgreSQL Database

## Summary

The retention arithmetic is correct, and the bucket's security model is sound. The plan meets both of its stated targets as written. A few operational gaps should still be closed: they could quietly erode the 5-minute or 14-day guarantees.

## What checks out

**Retention covers the 14-day window, with margin.**
- The worst case is a target just before a Sunday 02:00 backup, 14 days ago. That needs the previous Sunday's base backup, about 21 days old, plus all WAL since then.
- 28-day retention for both base backups and WAL covers this with about 7 days of slack.

**Lifecycle deletion is scoped safely.** The job can only remove objects older than 28 days, so nothing within the 21-day dependency window is at risk.

**The bucket is well protected.** It sits in a separate account, and database hosts can only add objects. A compromised database host therefore cannot destroy or tamper with backups. This is a strong design choice.

## Recommended changes

1. **Set `archive_timeout` so quiet periods still meet the 5-minute target.**
   - PostgreSQL archives a WAL segment only when it is complete, which by default means 16 MB is full.
   - "Landing within 60 seconds of being written" doesn't help if a segment takes 30 minutes to fill overnight.
   - Set `archive_timeout` to about 180–240 s. Each segment then gets switched, and with the 60 s shipping time it lands within 5 minutes.
   - Alternatively, use streaming archival such as `pg_receivewal`.

2. **Make the archive command handle "object already exists" safely.**
   - Because overwrites are forbidden, a retry after a partly successful upload will fail. This happens when the upload succeeded but the command reported failure.
   - PostgreSQL then retries that segment forever. Archiving stalls, WAL piles up in `pg_wal`, and the recovery-point target is silently lost.
   - The command should return success when an identical object already exists, checked by checksum. It should fail loudly only when the existing object differs.

3. **Monitor and alert on backups and archiving.**
   - If one Sunday backup fails, a 14-day-old target needs the backup from about 28 days ago, which is right at the deletion edge. Two failures in a row break the guarantee.
   - Alert when a base backup is missing or late.
   - Alert on `pg_stat_archiver` failures and archive lag, for example when the newest archived segment is older than 5 minutes.

4. **Widen the monthly drill.**
   - The drill only tests targets 13–14 days old. It never checks the recent end of the window, the oldest edge at exactly 14 days, or the worst case of a 21-day-old base backup.
   - Rotate or add targets: about 14 days just before a Sunday backup, and about 5–10 minutes ago.
   - Record the achieved data loss and the time taken to recover.
   - Also check that the restore role can read objects across the account boundary.

5. **Minor points.**
   - Consider object lock or versioning on the bucket as defence in depth against a misconfigured lifecycle rule.
   - Confirm the lifecycle rule ages objects by creation time, so a base backup can't expire before WAL that depends on it.
   - Retain timeline `.history` files at least as long as the WAL they relate to.

VERDICT: GO_WITH_CHANGES