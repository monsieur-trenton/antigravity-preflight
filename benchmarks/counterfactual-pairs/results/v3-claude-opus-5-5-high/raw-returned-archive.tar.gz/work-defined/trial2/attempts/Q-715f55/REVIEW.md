# Plan Review: Month-End Invoice Batch Submission

## Request size limit (5,000,000 bytes)

The unbounded `notes` field is the obvious concern, but the plan handles it:

- The job reads the **closed** snapshot, which no longer changes. A scan of that exact data is therefore an upper bound for every record the job will send, not a sample.
- Worst case per request: 500 × 4,100 = 2,050,000 bytes, plus under 1,000 bytes of envelope and separators, gives **under 2,051,000 bytes**. That is about 41% of the limit.
- Even if every record were near the largest, there is roughly 2.4× headroom. The final, smaller batch is safer still.
- The body is uncompressed, so the measured serialized size is the size on the wire. No compression variance applies.

No request can reach the partner's rejection threshold.

## Single submission, no resend

The plan states that a rejected batch is never resent, and the job makes exactly one request per batch. Since no batch can be rejected for size, this rule never forces a missing invoice through the size path. The rule and the sizing are consistent.

## Timeout

The partner documents responses of up to 60 seconds for large batches. Our batches (about 2 MB at most) are well within what the partner sends. Raising the timeout from 30 to 120 seconds removes the main way a correct, accepted batch could look like a failure. The 30-second default would have been a real problem with a no-resend rule, so this change is correct and sufficient.

## Observations (not blocking)

- **Unknown outcome after a network failure.** A connection drop could leave a batch's status unclear. The no-resend rule correctly prevents a blind retry. If such a failure occurs, the right response is to check the partner's ledger rather than resubmit. This is an operational procedure, not a defect in the plan.
- **Scan and job serialization.** The 4,100-byte figure holds only if the scan used the same serializer and encoding as the job. As written, the plan says the scan measured serialized records, which supports this.

## Conclusion

The plan's stated rules are met:

- Every request stays under 5,000,000 bytes, guaranteed by the immutable, fully scanned snapshot.
- Each batch is submitted once.
- The timeout covers the partner's documented latency.

Nothing in the plan as written leads to a rejected batch or a missing invoice.

VERDICT: GO