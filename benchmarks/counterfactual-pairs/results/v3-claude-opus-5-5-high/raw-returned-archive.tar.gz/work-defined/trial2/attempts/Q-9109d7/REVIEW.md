# Review: Orders PostgreSQL Point-in-Time Recovery Plan

The plan meets its stated recovery window and retention rules. A few improvements would make it more robust.

## What holds up

**Retention covers the worst case.** The oldest restore target is 14 days back. The newest base backup before that point can be up to 7 days older, so a restore may need a base backup up to 21 days old plus all WAL after it. Both are kept for 28 days, which leaves 7 days of margin. Because the nightly deletion only removes objects older than 28 days, nothing a valid restore needs is ever deleted.

**The 5-minute recovery point is achievable.** If each WAL segment is archived within 60 seconds, archived WAL is never more than about a minute behind.

**Backups are protected from the database hosts.** The bucket is in a separate account and the hosts can only add new objects. A compromised or misbehaving host therefore cannot destroy backups. The lifecycle job is the only principal that can delete, and its rule only matches expired objects.

**Rehearsals cover long WAL replay.** Restoring to 13–14 days back regularly tests replay over long WAL chains from old base backups.

## Recommended changes

1. **Force WAL segment switches with `archive_timeout`.** A WAL segment is archived only when it is closed. On a quiet database a segment can stay open far longer than 5 minutes. Setting `archive_timeout` to 60 seconds or less guarantees the "within 60 seconds" promise regardless of write volume. Without it, the 5-minute recovery point silently depends on traffic.

2. **Add margin for a failed weekly backup.** If one Sunday backup fails, a restore near day 14 may need a base backup 28 days old. That sits exactly at the deletion limit and could be removed the same night. To fix this:
   - Alert when a base backup fails or does not finish.
   - Raise retention to about 35 days, or always keep the two newest base backups that fall outside the 14-day window, whatever their age.

3. **Monitor gaps in the WAL archive.** A single missing segment breaks every restore past that point. Alert on `archive_command` failures and on growing archive lag (`pg_stat_archiver`). Periodically check that the archived WAL sequence is continuous back to the oldest retained base backup.

4. **Clarify "taken before that time."** A base backup can only be used for targets after it reached consistency, which is at the end of the backup, not the 02:00 start. Targets during a long backup window need the previous week's backup. The retention margin already covers this, but the restore runbook should say so.

5. **Widen the rehearsals.**
   - Sometimes deliberately pick the worst case: a target just before a Sunday 02:00 boundary 14 days back, which needs the ~21-day-old backup.
   - Also rehearse a recent target, a few minutes old, to show the 5-minute recovery point actually holds.
   - Validate restored data with row counts or a checksum of a recent orders range, not just a successful startup.
   - Track restore duration against a recovery time objective. The plan doesn't currently state one.

6. **Constrain and audit the lifecycle job's delete permission.** Scope it with a bucket policy or object-lock retention rather than relying on the job's own logic. For example, use object lock with a 28-day retention in compliance mode, so even a buggy rule cannot delete early. Alert if objects younger than 28 days are ever deleted.

VERDICT: GO_WITH_CHANGES