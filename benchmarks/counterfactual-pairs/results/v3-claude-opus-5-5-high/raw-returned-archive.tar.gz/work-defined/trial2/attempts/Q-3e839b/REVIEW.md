# Review: orders-api TLS rotation from Internal Root 2023 to Internal Root 2026

The sequence is correct. Trust is widened first, the server switches only after verification, and trust is narrowed only after the old certificate is no longer served.

**Timeline check**

| Day | Event | Client trust state | Server presents | Result |
|---|---|---|---|---|
| 0–1 | Baseline | 2023 only | 2023 cert | OK |
| 1 | Dual-root bundle pushed. Clients re-read it within 15 min without dropping connections. | 2023 + 2026 | 2023 cert | OK |
| 3 | Inventory confirms every client's bundle hash covers both roots. The switch is dated only after this passes. | 2023 + 2026 (verified) | 2023 cert | OK |
| 7 | Server switches to the 2026-signed cert with full chain. | 2023 + 2026 | 2026 cert | OK. Every client already trusts 2026. |
| 30 | 2023 removed from bundle. 2023 key destroyed. | 2026 only | 2026 cert | OK. Nothing chains to 2023 any more. |
| 60 | Old 2023 cert expires. | n/a | n/a | Irrelevant. It was retired on day 7. |

**Why it holds**

- **No client drops at any point.** Each client's trust set always contains the root of the certificate being served. The 2023 cert is valid until day 60, so it covers the full pre-switch window (days 0–7).
- **The switch is gated on evidence.** It depends on the day 3 inventory check, not on the assumption that the day 1 push worked.
- **The shared subject name was tested.** Both roots have the same subject and differ only by key identifier, which can break issuer lookup in some TLS stacks. Staging tested exactly this case (dual-root bundle, certificates from each root) and both were accepted. After day 30 only one root with that subject remains, so the ambiguity disappears.
- **Removing 2023 on day 30 is safe.** The server stopped presenting the 2023 cert 23 days earlier. Days 7–30 also give a rollback window: the server could go back to the still-valid 2023 cert because every client still trusts 2023.
- **Destroying the key after removal is fine.** Nothing needs to be signed with the 2023 key after day 1. A rollback would reuse the existing 2023 cert and would not need a new signature. The key is held offline throughout and destroyed only once no client trusts it.
- **Open connections are unaffected.** Bundle reloads don't close connections. Sessions established before day 7 were already validated, and later handshakes are covered by the rows above.

**Non-blocking notes (no change required)**
- Watch handshake-failure metrics on day 7 so a rollback can happen quickly if needed. The rollback path already works as designed.
- The plan covers the existing clients it names. If any new client might be provisioned with an old bundle between day 3 and day 7, a quick re-check of the inventory just before the switch would cover that. This is outside the plan's stated scope.

The plan meets its own rule that connectivity never drops, and every risky step is verified or tested before it is relied on.

VERDICT: GO