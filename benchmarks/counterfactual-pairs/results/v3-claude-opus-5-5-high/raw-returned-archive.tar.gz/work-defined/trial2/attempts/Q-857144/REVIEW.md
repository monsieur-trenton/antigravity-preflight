# Review: Order Service 7.3 Release and Rollback Plan

The plan works as written. The rollback has rehearsed evidence that it fits the policy: three full runs on production-sized data took 5–6 minutes against a 15-minute limit. The design can still be made safer, and the rehearsal doesn't cover a few production conditions.

## What holds up

- **Rollback timing.** The worst rehearsed run was 6 minutes, which leaves about 9 minutes of margin. The runs covered the whole job, from start until 7.2 was serving traffic, so the number measures the right thing.
- **Automatic trigger.** The rollback starts when the release is declared failed, so no human delay sits inside the 15-minute window.
- **Data compatibility.** 7.2 never reads or writes `discount_code`, so dropping the column cannot break 7.2.
- **Skipping the canary on redeploy.** This is reasonable. 7.2 has served all production traffic for the past 30 days, and a canary would cost time you can't spare.

## Recommended changes

1. **Redeploy 7.2 first, and drop the column later or not at all.** This is the biggest improvement. 7.2 ignores `discount_code`, so the down-migration isn't needed to restore service. Running it first puts a schema change on a 400 GB table on the critical path of the outage clock. If you redeploy 7.2 first, the contract clock stops sooner and the rollback no longer depends on DDL behaving. You can then drop the column in a separate, unhurried job, or keep it so that re-releasing 7.3 doesn't need another migration. The current order also has a smaller problem: 7.3 pods still running during the drop may throw errors writing to a column that no longer exists.

2. **Test the rollback under production conditions.** The timed runs were on a copy with no live traffic. In production, the `DROP COLUMN` may have to wait for a table lock behind long-running transactions or queries on `orders`. Depending on the engine and version, that wait can be unbounded or can block every query queued behind it. If the drop stays on the critical path, set a lock timeout and add retry or fail-fast behaviour, and run a rehearsal under realistic load. Change 1 makes this mostly moot.

3. **Clarify when the contract clock starts.** The policy measures 15 minutes from when the release is declared failed. The merchant's outage clock probably starts when the outage begins, which may be earlier. Time spent detecting the failure and deciding to declare it may count against the contract even though the policy ignores it. Set explicit, fast criteria for declaring failure, such as error-rate or latency thresholds, possibly automated, so that detection time doesn't eat into the margin.

4. **Decide what happens to discount data written by 7.3.** The down-migration permanently deletes any discount codes recorded on orders placed while 7.3 was live. 7.2 doesn't need them, but finance, support, or reconciliation might. Either keep the column (change 1) or export its non-null values before dropping it.

5. **Plan for a failed forward migration.** The plan covers rolling back a deployed 7.3. It doesn't say what happens if adding the column to the 400 GB table hangs, takes a long lock, or fails partway through. Confirm the add-column operation is metadata-only or online on your engine and version, and define what "declared failed" means in that case.

## Summary

The plan meets its 15-minute rule according to the rehearsal evidence, and nothing in it will clearly fail or break a stated rule. Its weak point is that a schema change on a very large, heavily used table sits on the outage-critical path for no functional reason, and it was tested without production lock contention. Moving the redeploy ahead of the drop removes most of that risk.

VERDICT: GO_WITH_CHANGES