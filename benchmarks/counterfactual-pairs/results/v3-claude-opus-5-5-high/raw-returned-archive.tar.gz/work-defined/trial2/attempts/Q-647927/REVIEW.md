# Review: Release 4.12 unique constraint on `customers (tenant_id, email)`

## Summary

The core reasoning holds. Pre-4.9 rows were checked and have no duplicates. Since 4.9, the write path locks the tenant row and refuses an email the tenant already has. That refusal also covers new rows that would collide with old rows. If that claim is accurate, the index build will succeed and the release will ship. Nothing here is certain to fail, but there are some cheap fixes worth making, mostly because a late failure aborts the whole release.

## Recommended changes

**1. Re-run the duplicate check over all rows right before the migration.**
The plan treats "no duplicates since 4.9" as true by reasoning, not by checking. That reasoning has some gaps:
- **Rolling deploy window:** during the 4.9 rollout, 4.8 instances writing without the lock could have raced with 4.9 instances.
- **Other writers:** admin scripts, bulk imports, support tooling, backfills or manual SQL are not "the code path."
- **Boundary rows:** rows whose created-at time is near the 4.9 cutover may fall on either side of the original check.

A unique-index build on 38M rows only fails at the end, after the long build. It then leaves an INVALID index behind and, per the runbook, aborts 4.12. One `GROUP BY … HAVING COUNT(*) > 1` over the whole table, run on the primary just before the build, removes this risk cheaply.

**2. Make sure the migration runs outside a transaction.**
`CREATE UNIQUE INDEX CONCURRENTLY` errors out inside a transaction block. Many migration tools wrap each migration in a transaction by default. Confirm the migration is marked non-transactional, and that the `DROP` and `CREATE` aren't sent together as one multi-statement transaction.

**3. Use `DROP INDEX CONCURRENTLY IF EXISTS`.**
The `DROP` is a no-op on the first run. Its real job is cleanup on a retry, when an INVALID index from a failed build exists. A plain `DROP INDEX` takes an ACCESS EXCLUSIVE lock on `customers`. It can queue behind long-running transactions and block all traffic to the table. The concurrent form avoids that.

**4. Set a `lock_timeout` for the attach step.**
`ALTER TABLE … ADD CONSTRAINT … UNIQUE USING INDEX` needs a brief ACCESS EXCLUSIVE lock. Set a short `lock_timeout` and retry, so it can't stall the table behind a long transaction.

**5. Check that the index is valid before attaching it.**
Confirm `pg_index.indisvalid` is true after the build, and fail loudly if it isn't.

**6. Settle email case and normalization.**
The constraint compares emails byte-for-byte, so `Bob@x.com` and `bob@x.com` are treated as different. Two problems follow:
- The 4.12 sign-up code expects the constraint to stop second accounts for the same email. It won't do that for case variants unless emails are normalized before they are written.
- The 4.9 duplicate check must use the same comparison as the index. If they differ, the "no duplicates" reasoning doesn't match what the index enforces.

Decide on one rule, either normalized storage or a `lower(email)` index, and apply it to both.

**7. Minor: NULL emails.**
A unique index allows multiple NULLs. If `email` can be NULL, make sure that's the intended behavior.

## Verdict rationale

As written, the plan should work if its stated facts are true. The changes above reduce the chance of a late, release-aborting failure and close a gap in the sign-up guarantee. They don't fix a definite break.

VERDICT: GO_WITH_CHANGES