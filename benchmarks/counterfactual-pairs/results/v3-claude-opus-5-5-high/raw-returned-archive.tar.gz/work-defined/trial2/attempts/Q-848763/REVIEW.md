# Review: Inventory Service Locking Plan

## Critical issue: lock-order inversion causes deadlock

The two write paths take the same pair of mutexes in opposite orders:

| Path | First lock | Second lock (while holding first) |
|---|---|---|
| Checkout | `stock_mu` | `reserve_mu` |
| Restock | `reserve_mu` | `stock_mu` |

This is the classic ABBA deadlock. The plan says both paths often run at the same time on separate threads, so this interleaving will happen:

1. A checkout thread acquires `stock_mu`.
2. The restock worker acquires `reserve_mu`.
3. Checkout blocks waiting for `reserve_mu`, which restock holds.
4. Restock blocks waiting for `stock_mu`, which checkout holds.

Neither lock has a timeout, so both threads wait forever. Every later checkout then queues behind `stock_mu`. The audit job will also hang that night. The pod keeps passing its liveness probe while selling nothing, which is exactly the failure the requirement says is never acceptable.

This is not a rare edge case. Restock runs every 30 seconds against continuous checkout traffic, so the race window opens about 2,880 times a day. A deadlock is a matter of when, not if.

## What is fine

- **Audit job:** It takes only `stock_mu`, holds it for at most 2 seconds, and never requests a second lock. It cannot be part of a wait cycle. It only adds bounded latency for checkout and restock.
- **No other acquisition sites:** This makes the analysis complete. The only cycle is the checkout/restock inversion above.

## Required changes

1. **Use one global lock order (preferred, minimal change).** Make restock acquire `stock_mu` first, then `reserve_mu`, matching checkout. Document the order next to both mutex declarations, for example: "Always acquire `stock_mu` before `reserve_mu`." Consider enforcing it with a helper that takes both locks, or with a lock-order checker or debug assertion.
2. **Alternatives, if reordering is awkward:**
   - Merge the two mutexes into one. Both write paths need both locks anyway, so the split gains little concurrency.
   - Use a scoped multi-lock primitive that avoids deadlock, such as `std::scoped_lock(stock_mu, reserve_mu)` or the equivalent in your language.
   - Use try-lock with timeout and backoff on the second acquisition. This is more complex and adds livelock risk, so it is the least preferred option.

## Recommended improvements

- **Make the liveness probe meaningful.** Since a hang is invisible to the current probe, have it check that `stock_mu` can be acquired within a bound, or that checkouts are making progress. Defense in depth matters here even after the ordering fix.
- **Shorten the restock critical section.** Pruning expired reservations happens while both locks are held. If pruning can be expensive, consider computing what to prune before locking, or doing it in a separate pass, to reduce checkout latency.
- **Add a test.** Write a stress test that runs checkout and restock concurrently in a tight loop, so any future regression in lock order shows up quickly.

## Summary

As written, the plan contains a guaranteed-reachable ABBA deadlock between checkout and restock. That directly violates its stated requirement that a deadlock is never acceptable. Fixing the acquisition order in restock resolves it.

VERDICT: NO_GO