# Review: Nightly Compaction Job Plan

## What holds up

- **No overlap with the backup.** The backup agent finishes by 00:45, and the job starts at 01:00.
- **No contention during the window.** Nothing else is scheduled from 01:00 to 04:00, so nice 19 and the idle I/O class shouldn't starve the job.
- **Safe deletion order.** Old segments are removed only after the new set is fully written and checksum-verified. A killed or failed run leaves the source data intact, so the 04:00 kill can't cause data loss.

## The main gap: the 3-hour window is assumed, not shown

The plan's central rule is that every run must finish inside 3 hours. Nothing in the plan shows that it can:

- To finish 1.3 TB in 3 hours, the job needs at least **about 120 MB/s** of sustained throughput (1.3 × 10¹² B ÷ 10,800 s).
- Compaction reads the source and writes the output. Checksum verification then reads data again. So the real disk I/O is roughly **2–3× that figure, about 240–360 MB/s**, before counting any CPU cost of the merge.
- Throughput on a production-class host has never been measured. The plan could fit with plenty of room, or it could miss the window every night.

Nothing proves the plan will fail, so this isn't a NO_GO. But the stated rule is unverified, and the plan shouldn't go into production until it is.

## Changes I'd make

1. **Benchmark before go-live.** Run the job against a full 1.3 TB day on a production-class host. Time it end to end, including checksum verification. Set a target, for example finishing within about 70% of the window (around 2 h 6 min), to leave headroom.
2. **Plan for growth.** 1.3 TB is the 90-day maximum, not a ceiling. Track daily volume and alert when the projected runtime gets close to the window.
3. **Define what happens after a missed run.**
   - Does the next night pick up the uncompacted day as well, giving it double the volume and making a second miss more likely?
   - Or does that day stay uncompacted forever?
   - Specify the catch-up behavior, and alert on any kill.
4. **Add monitoring.** Record the runtime and bytes processed for every run, and alert on a kill or on a runtime above the threshold.
5. **Minor points:**
   - The idle I/O class only works with I/O schedulers that support it, such as BFQ or CFQ. It's harmless here, but if unscheduled work like monitoring, scrubs, or ad-hoc jobs ever runs during the window, idle class can stall the job entirely. Consider the best-effort class at low priority instead.
   - Make sure the rm -rf target path is built defensively (no empty or unset variables) and is scoped to the verified segment set.

VERDICT: GO_WITH_CHANGES