# Review: orders-api TLS certificate and CA rotation

The plan is sound. It follows the correct order for a root rotation: clients trust the new root first, the server switches only after that is verified, and the old root is removed only after nothing depends on it. I see no step that causes clients to lose connectivity as written. Some gaps are worth closing.

## What works

- **Trust before switch.** The dual-root bundle goes out on day 1, and the server keeps the 2023 certificate until day 7. Clients reload every 15 minutes, so six days is a large margin.
- **Verification before switch.** The day 3 inventory requires every client to report a hash that includes both roots before the switch is scheduled. This is the right check, and it measures what clients actually loaded, not what was sent.
- **Same subject name tested.** The two roots share a subject name and differ only in key identifier. This is the subtle risk here, because some chain builders match on subject and can pick the wrong root. Staging showed that clients holding both roots accept certificates from either.
- **Full chain on day 7.** Sending the full chain avoids failures from missing intermediates.
- **Removal is safe.** By day 30 the server has presented the 2026 certificate for 23 days, so removing the 2023 root affects nothing in use. Clients reload without dropping open connections, so removal doesn't disrupt them.
- **Key destruction.** Destroying the 2023 key on day 30 is fine. After day 7 nothing needs a new 2023-issued certificate. The existing 2023 certificate (valid to day 60) still allows a rollback from day 7 to day 30, the only window where rollback makes sense.

## Recommended changes

1. **Add a check before day 30, like the day 3 check.** Before the 2023 root is removed, confirm that every endpoint clients reach presents the 2026 chain. That includes every replica, load balancer, TLS-terminating proxy, and any failover or disaster-recovery instance. If any one still serves the 2023 certificate, removing the root breaks those clients. The plan says "the server" in the singular, so make explicit that this covers every endpoint.
2. **Test a 2026-only bundle in staging.** Staging covered the dual-root bundle but not the day 30 state, where only the 2026 root is present and clients may have cached chains. This is low risk, but cheap to check, given the same-subject-name issue.
3. **Write down the rollback plan and its limit.** From day 7 to day 30, rolling back means re-presenting the 2023 certificate. After day 30 that is no longer possible, because the root is gone from bundles and the key is destroyed. State this so no one assumes otherwise.
4. **Monitor handshake failures around days 7 and 30.** Watch client-side handshake errors, broken down by client version or platform. The inventory confirms which bundle loaded, not that chain building succeeds on every client stack.
5. **Confirm onboarding gets the new bundle.** Clients provisioned or restored from old images after day 1 must get the dual-root bundle, and after day 30 the 2026-only bundle. Otherwise a late-joining client could miss the inventory check.
6. **Check whether other services use the shared bundle.** If other services' certificates still chain to Internal Root 2023, removing it on day 30 would break those services even though orders-api is fine.

None of these changes the core sequence. They protect it against deployment details the plan doesn't cover.

VERDICT: GO_WITH_CHANGES