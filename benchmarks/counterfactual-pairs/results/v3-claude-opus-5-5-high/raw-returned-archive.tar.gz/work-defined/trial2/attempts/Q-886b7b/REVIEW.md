# Review: Shared Redis Cache for Rendered Dashboards

## Isolation rule: satisfied

The core design is sound. The tenant boundary is enforced by the key itself.

- **`tenant_id` comes from the authenticated gateway.** It does not come from the request body or query string, so a caller cannot choose another tenant's namespace.
- **Tenant-scoped dashboard IDs are handled.** Because `tenant_id` is in the key, tenant A's dashboard 42 and tenant B's dashboard 42 map to different keys.
- **The handler only touches the key built from the current request.** No code path reads a key derived from anything other than the caller's own tenant.
- **Leaving out the user ID is correct** because visibility is tenant-wide. Adding it would only lower the hit rate.
- **Delimiter injection can't cross tenants.** `tenant_id` is the first segment and is set by the server. A `:` inside `range` can only affect segments after the tenant. Validating `range` is still good practice.

I see no path by which a response cached for one tenant reaches another tenant's caller.

## Recommended changes

1. **Make the gateway overwrite `tenant_id`.** It must strip any client-supplied `tenant_id` header or field and replace it with the authenticated value. If a client-sent value can pass through or take precedence, isolation fails. The plan implies this is handled, but it should say so explicitly and include a test.

2. **Specify how "deletes its cached entries at once" works.** One dashboard has an entry per `range`, so an edit must find every `dash:{t}:{d}:*` key.
   - Don't use `KEYS`. It blocks Redis and scans only one node in a cluster.
   - Option A: keep a per-dashboard index set of the range keys and delete its members on edit.
   - Option B (simpler and atomic): use a version counter. Build the key as `dash:{t}:{d}:v{n}:{range}` and increment `n` on edit. Old entries then expire on their own.

3. **Use a cluster hash tag.** In Redis Cluster, the range variants of one dashboard currently hash to different slots. That makes multi-key deletes or Lua cleanup impossible. A key such as `dash:{t:d}:range` keeps them on one slot. The braces in the plan's template are placeholders, so state the real hash-tag format explicitly.

4. **Close the edit-vs-render race.** Here is the failure sequence:
   - A render starts and reads the old data.
   - An edit commits and deletes the cache entry.
   - The render finishes and writes the stale result back.

   Users then see stale data for up to 300 s, which contradicts "at once." The version-counter approach fixes this if the render captures the version before reading data. A write-guard on the version also works.

5. **Normalize `range`.** Canonicalize equivalent ranges to one key, for example `7d` vs `last_7_days`, or relative vs absolute timestamps. This protects the hit rate and prevents key-space blowup from arbitrary user-supplied values.

6. **Add operational safeguards.**
   - Per-tenant memory or eviction awareness, so one large tenant can't evict everyone else's entries.
   - Metrics on hit rate, key count and invalidations.
   - An automated test asserting that the same dashboard ID in two tenants never returns cross-tenant content.

## Summary

The plan meets its stated isolation rule as written. The changes above address unspecified invalidation mechanics, a staleness race, cluster slot placement and hardening of the gateway's trust boundary. They are improvements, not blockers.

VERDICT: GO_WITH_CHANGES