## Review

**The isolation rule is violated by the cache key design.**

The plan establishes three facts that combine into a cross-tenant leak:

1. A single Redis cluster is shared by all tenants.
2. Dashboard IDs are per-tenant, so `dashboard_id = 42` exists in many tenants with different data.
3. The cache key is `dash:{dashboard_id}:{range}` and does **not** include `tenant_id`.

So tenant A and tenant B requesting dashboard 42 with the same range build the identical key, e.g. `dash:42:7d`. Whichever tenant populates it first, the other tenant reads that response for up to 300 seconds. This directly breaks the rule that a response cached for one tenant must never be returned to a different tenant. It isn't an edge case. Because IDs start at 1 in every tenant, low-numbered dashboards will collide constantly.

The gateway attaching `tenant_id` doesn't help, because the handler never uses it when building the key. Reading and writing only the current request's key doesn't help either, since that key is the shared one.

**Secondary consequence: invalidation crosses tenants.**
When tenant A edits dashboard 42, deleting `dash:42:*` also evicts tenant B's entry. That is less severe than the leak, but it shows the keyspace isn't scoped. Worse, if tenant B's request repopulates the key just after the delete, tenant A may immediately read B's data.

**Parts that are fine:**
- Omitting the user ID is reasonable, given that every dashboard is visible to all users in its tenant.
- A 300s TTL plus delete-on-edit is a sensible freshness strategy.

## Required changes

- **Include the tenant in the key:** `dash:{tenant_id}:{dashboard_id}:{range}`. Take `tenant_id` only from the gateway-authenticated context, never from client-supplied parameters.
- **Scope invalidation to the tenant:** delete `dash:{tenant_id}:{dashboard_id}:*`. Track the keys in a per-dashboard set or use a version counter, rather than `KEYS`/`SCAN` over a wildcard.
- **Normalize `range`** to a canonical form before building the key, so you avoid cache fragmentation and injection of `:` into the key.
- **Fail closed:** if `tenant_id` is missing on a request, bypass the cache instead of building a key without it.
- **Add a test:** two tenants with the same dashboard ID and range must never receive each other's cached response.

VERDICT: NO_GO