# Review: Checkout Capture Retry Plan

## The core problem

The plan's safety rests entirely on one unverified assumption: that the capture endpoint deduplicates requests by idempotency key.

The plan itself shows why that matters:

1. **Duplicate requests are expected.** A timeout can occur after the server has applied the capture, and the client retries on timeout. So a second capture request for an already-charged order is a normal outcome, not an edge case.
2. **Only the server can block the duplicate.** The client can't tell "timed out before applying" from "timed out after applying." Sending the same idempotency key on every attempt only helps if the server honors it.
3. **The server behavior is unknown.** The plan says nobody has checked it and the payments team hasn't confirmed it.

If the endpoint ignores the key, or handles it incorrectly, a timeout-then-retry charges the customer twice. With up to 5 retries, it could charge them up to 6 times. That breaks the plan's own rule that no capture may be applied twice. The plan doesn't establish that the rule holds, so it can't proceed as written.

The 5xx path has the same exposure. A 5xx response doesn't prove the capture wasn't applied. For example, a gateway or proxy can return a 502 or 504 after the upstream service has committed the charge.

## What's done well

- The idempotency key is generated once per order and never regenerated. That is the right design.
- Disabling the HTTP library's built-in retries prevents hidden extra attempts that wouldn't be bounded or tracked.
- Retries are bounded, with exponential backoff (200, 400, 800, 1600, 3200 ms, about 6.2 s total).

## Required changes

1. **Get written confirmation from the payments team**, or check the API contract, that the capture endpoint deduplicates by idempotency key. The confirmation should cover:
   - The dedup window or TTL, which must be longer than the full retry span plus any later manual or recovery retries.
   - Behavior when a retry arrives while the first request is still in flight. Does the server return 409, block until the first finishes, or process both?
   - That a repeated key returns the original result rather than an error the client might treat as retryable.
   - Behavior if the same key is sent with a different body, such as a different amount.
2. **Test it** against staging. Send the same key twice, including concurrently, and verify that only one charge results.
3. **If the server does not dedupe, don't blind-retry.** After a timeout or 5xx, look up the capture or order status first, and retry only if no capture exists. The alternative is to fail to a reconciliation queue instead of retrying.

## Recommended improvements (non-blocking)

- Add jitter to the backoff to avoid synchronized retry storms during a payments outage.
- Distinguish retryable 5xx codes (502, 503, 504) from ones that suggest a deterministic failure.
- Log the idempotency key and attempt number on every attempt, and alert on orders with more than one successful capture as a safety net.
- Define what happens after the 5th failure. The charge state is unknown at that point, so the order should go to reconciliation, not be marked failed.

## Bottom line

The retry design is reasonable, but its correctness depends on unconfirmed server-side idempotency. As written, a timeout after a successful capture can lead to a second charge, which breaks the plan's own rule. Confirm and test the server's idempotency behavior, or add a status check before each retry, before shipping.

VERDICT: NO_GO