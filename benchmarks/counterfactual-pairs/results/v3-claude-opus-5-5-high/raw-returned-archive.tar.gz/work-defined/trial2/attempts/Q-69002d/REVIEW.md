# Review: Address Backfill Geocoding Plan

The plan stays within the provider's limits, and the margins are large.

## Checking the numbers

| Claim | Check | Result |
|---|---|---|
| Job rate | 4 workers × 1.25 req/s = 5 req/s | Correct |
| Duration | 240,000 ÷ 5 = 48,000 s ≈ 13.3 h | Correct |
| Combined peak rate | 5 (job) + 3 (signup peak) = 8 req/s, against a 20 req/s limit | 40% of limit |
| Worst single day | 240,000 (the whole job) + 50,000 (signup peak) = 290,000, against a 1,000,000/day limit | 29% of limit |
| Request ceiling | No retries within the run, so at most 240,000 job requests | Holds |

The daily figure holds even in the worst case. The run is 13.3 hours, so it may cross midnight, but the bound assumes the entire job lands in one day alongside a peak signup day, and that total is still under 30% of the cap.

## Edge cases

- **Limiter bursts or misalignment.** A token-bucket limiter can let each worker send 2 requests in the same second. In that worst case the job sends 8 req/s, plus 3 from signups, for 11 req/s. That is still well under 20.
- **Signup growth beyond the 6-month peak.** Signups would have to reach about 15 req/s, five times the observed peak, before the combined rate hit the limit.
- **Accidental re-run on the same day.** A full second run gives 480,000 + 50,000 = 530,000, still under 1,000,000. The no-retry rule also limits how many requests a single run can send.
- **Failed requests counting against quota.** This is already covered, because the 240,000 ceiling includes failures.

The rule "never exceed the rate limits" is met with plenty of headroom on both the per-second and per-day limits. The limits come from the provider in writing, so the plan isn't relying on assumed numbers.

## Optional notes (not required for correctness)

- Unretried failures will leave some addresses without coordinates. A small follow-up run can fill them in, and the budget allows for it easily.
- Stopping the job on any 429 or quota warning would be a cheap safeguard, though the math shows it shouldn't be needed.

These are operational niceties. The plan as written works and doesn't break its stated rule.

VERDICT: GO