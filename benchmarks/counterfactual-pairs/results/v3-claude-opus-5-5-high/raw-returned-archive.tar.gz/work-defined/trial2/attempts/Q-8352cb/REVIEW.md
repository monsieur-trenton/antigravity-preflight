# Review: Release 4.12 Split-Payment Plan

## Blocking issue

**The production flag default contradicts the release rule.** The rule says every new code path ships switched off in production. But `flags.yaml` sets `checkout.split_payment` to **true in production**. If 4.12 deploys as written, split-payment goes live for production customers right away, with no approved flag change.

This also undermines other parts of the plan that assume the flag is off in production:
- **"Single-payment stays the production path while the flag is off"**: the flag won't be off, so production traffic would run the new path.
- **"Column is not written while the flag is off"**: production would start writing `split_payment_ref` immediately.
- **"CI forces the flag off to mirror production"**: production isn't off, so this run doesn't mirror production. The flag-on run is actually the one that matches it.
- **"Enable in production in a later change ticket after two weeks of staging"**: production would already be enabled. That ticket and the two-week soak would have nothing left to gate.

**Required fix:** Set the production default in `flags.yaml` to `false`. Dev and staging can stay `true`.

## Parts that hold up once the default is fixed
- The single-payment code is left untouched, so it's a clean fallback.
- The nullable column is additive. The lock was under 1 second on a full-size staging copy, which is low risk.
- The 30-second local cache gives a predictable rollout and rollback without a redeploy.
- CI runs the suite with the flag both on and off, which covers both paths.
- Production enablement is gated behind a separate change ticket after staging traffic.

## Suggestions (non-blocking)
- Add a CI or pre-deploy check that fails if any new flag defaults to `true` in production. That enforces the release rule automatically.
- Write down the rollback step (flip the flag off, wait up to 30 seconds). Also decide how to handle in-flight split-payment orders and rows that already have `split_payment_ref` set.

VERDICT: NO_GO