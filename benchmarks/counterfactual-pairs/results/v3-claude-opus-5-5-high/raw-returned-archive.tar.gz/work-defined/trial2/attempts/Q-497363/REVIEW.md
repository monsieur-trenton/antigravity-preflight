# Review: 4.12 unique constraint on `customers (tenant_id, email)`

The plan is sound. The duplicate-data argument holds up, and the index build approach is correct. The changes below are about execution risk, which matters because a failure here aborts the whole release.

## What holds up

**No existing duplicates.** The pre-4.9 rows and the post-4.9 rows together cover the whole table:
- **Pre-4.9 rows:** the GROUP BY / HAVING query on the primary returned zero groups.
- **Post-4.9 writes:** the single code path locks the tenant row and rejects an email the tenant already holds. That covers both inserts and email updates. It rules out duplicates among new rows, and between a new row and an old one.

**Build approach.** `CREATE UNIQUE INDEX CONCURRENTLY` followed by `ALTER TABLE ... ADD CONSTRAINT ... UNIQUE USING INDEX` is the right pattern for a 38M-row table. It avoids a long write-blocking lock.

**Retry safety.** If a concurrent build fails, it leaves an INVALID index with the same name. The leading `DROP INDEX IF EXISTS` clears it, so a retry doesn't fail on a name collision.

## Recommended changes

1. **Confirm the migration runs outside a transaction.** `CREATE INDEX CONCURRENTLY` errors inside a transaction block. Many migration frameworks wrap migrations in one by default, so mark this migration non-transactional and verify that in staging. Otherwise the release is aborted by a tooling default.

2. **Use `DROP INDEX CONCURRENTLY IF EXISTS`.** The drop is a no-op on the first run, but on a retry it will drop the leftover invalid index. A plain `DROP INDEX` takes an ACCESS EXCLUSIVE lock on `customers`. That lock waits behind any long-running query and blocks all traffic queued behind it.

3. **Set `lock_timeout` on the `ADD CONSTRAINT ... USING INDEX` step, and allow a retry.** The attach is fast, but it needs a brief ACCESS EXCLUSIVE lock. Without a timeout, it can queue behind a long transaction and stall sign-ups.

4. **Plan for the concurrent build's wait phases.** CIC waits for every transaction that predates each build phase. Before running it:
   - Check for long-running or idle-in-transaction sessions, and for replication slot or backup activity.
   - Give the migration a generous `statement_timeout`, or disable it for this statement.
   - Monitor progress with `pg_stat_progress_create_index`.

   A timeout here counts as "failure to apply" and aborts 4.12.

5. **Re-run the full-table duplicate check immediately before the migration.** The pre-4.9 query plus the code-path argument is convincing. But a quick check of all rows also catches out-of-band writers, such as admin scripts, imports, or manual fixes. If such a writer created a duplicate during the build, the index would end up INVALID and the release would abort.

6. **Deployment ordering.** The 4.12 sign-up code relies on the constraint to reject duplicate accounts. It must not take traffic until the constraint is attached. Keep the 4.9 lock-and-check path in place until then, or confirm the deploy pipeline only rolls out code after the migration succeeds.

## Summary

None of these issues breaks the plan as written; the logic is correct. Each change reduces the chance that a timeout, lock queue, or framework default aborts the release.

VERDICT: GO_WITH_CHANGES