# Review: Order Service 7.3 Release and Rollback Plan

The plan should work as written, but it has avoidable risk on the rollback's critical path. The rollback has been rehearsed at production size, it is automated, and the measured 5–6 minutes leaves about 9 minutes of margin under the 15-minute policy. Skipping the canary for 7.2 is reasonable given its 30 days of full production traffic. The problems are in what the rehearsal didn't measure and in what the rollback does.

## 1. The rehearsal didn't include production load
The timings came from a database copy, presumably with no live traffic. In production, dropping the column needs an exclusive lock on `orders`. When the failure is declared, 7.3 will still be serving traffic against that table.
- In Postgres, `ALTER TABLE ... DROP COLUMN` must wait for every in-flight transaction on `orders` to finish. While it waits, it blocks every query queued behind it. One long-running report or stuck transaction can stretch the step without limit and stall all order traffic.
- In MySQL, whether the drop is instant or rebuilds the table depends on version and table format.

**Changes:**
- Set a `lock_timeout` with retries, or the MySQL equivalent, on the down-migration.
- Rehearse once with representative concurrent load and a long-open transaction.
- Confirm the drop is metadata-only on the exact production engine version.

## 2. The down-migration probably doesn't need to be on the critical path
7.2 neither reads nor writes `discount_code`, so 7.2 can likely run with the column still present. Dropping it before restoring 7.2 adds the riskiest step to the timed path for little benefit. It also guarantees that discount codes recorded by 7.3 during the release window are deleted. Those may matter for billing, reconciliation, or the merchant.

**Change:** Restore 7.2 first and stop the outage clock. Drop the column later, after backing it up, in a separate, unhurried step.

**Check first:** confirm the column is nullable or has a default. If it is `NOT NULL` without a default, 7.2's inserts would fail while the column exists. In that case, either fix the constraint in the 7.3 migration or keep the drop in the rollback, with the safeguards from point 1.

## 3. The clock-start point is undefined
The contract says when the outage clock stops but not when it starts. If it starts at the onset of impact rather than at the failure declaration, then detection and decision time must also fit in the 9-minute margin. The plan has no criteria or time limit for declaring failure.

**Change:**
- Confirm with the contract owner when the clock starts.
- Define objective failure criteria, such as error-rate and latency thresholds.
- Set a maximum time to reach a decision.

## 4. Minor items
- Define what happens if the rollback job itself fails partway, for example if the column is dropped but 7.2 isn't deployed. Have a manual runbook and a named owner on call.
- Confirm that 7.2 is actually serving traffic, using health checks and traffic metrics. The job finishing is not enough to stop the clock.

VERDICT: GO_WITH_CHANGES