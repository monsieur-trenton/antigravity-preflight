# Review: date-parsing library upgrade 2.8 → 3.0

## What holds up

- **Runtime compatibility is fine.** Version 3.0 needs runtime 11 or later, and every billing host runs 12.
- **The archived reporting tool is out of scope.** It has its own pinned copy of 2.8 in a separate directory, it isn't one of the 14 callers, and it isn't redeployed. The upgrade can't affect it.
- **The refunds module has been exercised with 3.0**, so the reason for the upgrade is covered.

## The blocking problem

The plan's rule is that the 14 existing callers must behave exactly as they do today. Nothing in the plan establishes that they will.

- **This is a major version bump.** By convention, moving from 2.x to 3.0 is where breaking changes land. Date parsing is especially prone to quiet behaviour changes, such as:
  - default time zone
  - whether ambiguous formats like 03/04 are read day-first or month-first
  - lenient versus strict parsing
  - handling of two-digit years
  - daylight-saving edge cases
  - whether a bad input raises an error or returns null
- **None of the 14 callers have been run against 3.0.** Testing only the refunds module says nothing about the code paths that produce invoice due dates.
- **A mistake can't be undone.** If any caller's output shifts, wrong due dates go to customers at 06:00, and those emails can't be recalled.
- **The 12-hour gap is not a safeguard.** The time between the 14:00 deploy and the 02:00 run only helps if something checks the output in that window. The plan includes no such check.

As written, the plan ships an unverified change into an irreversible path. It has no evidence for the one rule it sets itself, so it can't claim to meet that rule.

## Changes needed before this can go

1. **Run all 14 callers against 3.0 before the deploy.** Capture their outputs under 2.8 and 3.0 on the same inputs and confirm they match exactly. Use real historical invoice data plus edge cases such as month-end, leap days, DST transitions, ambiguous formats, malformed input and time-zone boundaries.
2. **Read the 3.0 changelog and migration guide.** Check every listed breaking change against how the 14 callers actually use the library.
3. **If outputs differ, choose a fix before shipping.** Either:
   - adapt the affected callers explicitly, for example by pinning old-behaviour options if 3.0 offers them, or
   - isolate the refunds module's need, for example by backporting the fix or vendoring 3.0 only for refunds, so the 14 callers stay on 2.8.
4. **Add a safety net for the first invoice run:**
   - a pre-02:00 dry run that compares that night's due dates against a 2.8 baseline, and
   - an agreed rollback, or a hold on the 06:00 email send, if the comparison shows any difference.

Once step 1 shows identical output across all 14 callers, the rest of the plan (runtime, archived tool, timing) is sound.

VERDICT: NO_GO