# Review: split-payment flow in checkout 4.12

## Does the plan follow its own rule?

Yes. The rule says new code ships to production disabled and is turned on later only through its own approved flag change. The plan meets it:

- **Production is off.** The production default in `flags.yaml` is `false`, and the single-payment path is unchanged. Production customers see no behavior change at deploy.
- **Activation is separate.** Turning the flag on is deferred to its own change ticket after two weeks of staging traffic.
- **The schema change is passive.** The new `split_payment_ref` column is nullable and receives no writes while the flag is off. That keeps it backward-compatible with old pods during a rolling deploy.
- **Staging tests both states.** Staging defaults to `true`, so the two weeks of soak traffic actually run the new path. The CI pass with the flag forced off covers what production will run at release.

I found nothing that would fail or break the stated rule.

## Recommended improvements

1. **Guard the production migration.** On Postgres and most MySQL setups, adding a column briefly needs an exclusive table lock. The staging result ("under 1 second") measures how long the lock is held. It doesn't measure lock *queuing*: if production has a long-running transaction on `orders`, the `ALTER` waits behind it, and every checkout write queues behind the `ALTER`. That can stall checkout even though the change itself is trivial. Set a short `lock_timeout` (e.g., 2–5s) with retry, and run it off-peak.

2. **Plan for mixed flag state during a flip.** After a flip, pods can disagree for up to 30 seconds. A customer mid-checkout could start a split payment on one pod and finish on a pod that sees the flag off. Before the activation ticket, document how in-flight split-payment orders are handled when:
   - pods disagree during the 30-second window, and
   - the flag is turned back off as a kill switch while orders with a non-null `split_payment_ref` are still open.

   The single-payment path should either finish or cleanly reject these orders, not corrupt them.

3. **Write down rollback.** State whether the column stays in place on a code rollback (it should, since it is nullable and unused) and who owns turning the flag back off.

4. **Add observability before activation.** Add metrics or dashboards for split-payment success and failure rates, and alerts on payment errors. Two weeks of staging traffic only gives a useful signal if someone is measuring it.

5. **Optional: test the flag-on state against production-like config.** The staging flag-on pass uses staging config. Consider a flag-on smoke test against production-like settings (payment provider sandbox, limits) before the activation ticket.

None of these block the 4.12 release as written. They make the release and the later activation safer.

VERDICT: GO_WITH_CHANGES