# Review: Checkout capture retry plan

**Verdict: GO.** Retries cannot cause a second charge, and the plan needs no changes.

## The risk the plan has to handle

A timeout does not mean the capture failed. The server may have charged the card and the response was lost. Retrying a capture blindly could charge the customer twice, which breaks the plan's rule.

## Why retries are safe here

- **One stable key per order.** Every attempt for an order uses the same idempotency key. The key is a UUID created once with the order and never regenerated. A retry after a "timed out but actually applied" capture therefore uses the same key as the capture that went through.
- **The server deduplicates by key.** The endpoint is idempotent per key, and this is backed two ways:
  - The payments team confirmed it is the endpoint's documented contract.
  - A staging run tested it: 1,000 captures sent 6 times each recorded exactly 1,000 charges.
- **The test matches the real retry count.** Six sends per capture equals the plan's worst case: one original attempt plus 5 retries.
- **No hidden repeats.** The HTTP library's built-in retries are turned off. Without that, the library could multiply attempts beyond what was tested, or possibly resend in ways the plan doesn't control. With it off, the 5 retries are the only repeats.
- **Retry triggers are sensible.** The client retries only on timeouts and 5xx responses, where the outcome is unknown or transient. It does not retry definitive 4xx rejections.
- **Retry timing is modest.** The backoff waits are 200, 400, 800, 1600 and 3200 ms, about 6.2 s in total. All retries finish well within any plausible key-retention window on the server.

Taken together, a capture is applied at most once per order, even when a retry follows a capture that already succeeded.

## Optional refinements (not required for correctness)

- **Jitter.** Adding randomness to the backoff would spread out retries if many clients hit the same outage at once.
- **Exhausted retries.** If all 5 retries fail, the client doesn't know whether the charge happened. It is worth defining what happens next, such as a status lookup or reconciliation by the same key. Any later retry with the same key stays safe from double charging.

Neither point affects the rule the plan states.

VERDICT: GO