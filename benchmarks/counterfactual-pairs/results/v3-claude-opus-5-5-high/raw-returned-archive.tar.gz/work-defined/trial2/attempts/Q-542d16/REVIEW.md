# Review: Nightly Export Cutover to exports-prod/nightly/

## Main risk: svc-export's write access is unverified

Nobody has written to `exports-prod/nightly/` with svc-export's credentials, and nobody has checked its permissions on the bucket. Other facts make this risk serious:

- **One attempt, no retry.** If the 01:00 run fails, nothing recovers it.
- **The release depends on it.** A failed export blocks the 09:00 release, so nothing ships that day.
- **Nothing will fix it in time.** No bucket policy change is pending or scheduled. If svc-export lacks write access now, it will still lack it at 01:00.
- **It is a new destination.** The account previously wrote to a shared drive. Write access to a new bucket usually requires an explicit grant, and the plan doesn't show one exists.

The plan doesn't show that this will fail, so I can't call it NO_GO. It also doesn't show that it will succeed. This is the plan's one real gap, and it should be closed before tonight.

## Required change before 01:00

1. **Test the write as svc-export.** Use svc-export's own credentials, not an admin's. Write, read back and delete a small test object under `exports-prod/nightly/`. Also check any encryption key permissions the bucket's default encryption requires.
2. **Test a large upload.** The export is a single ~30 GB object. Many object stores cap single-request uploads well below that (for example, S3 caps a single PUT at 5 GB). Confirm the export tool uses multipart upload and that svc-export has the related permissions (initiate, upload part, complete, and abort). A small test object won't catch this, so test with a multi-GB file or confirm the code path.
3. **If either test fails**, add the grant in the infrastructure repo and apply it before 01:00. If that isn't possible, defer the cutover and keep writing to the shared drive tonight.

## Recommended improvements

- **Add a fallback.** Add a retry, or have someone check at around 01:30 so a failure can be rerun manually well before 09:00.
- **Add alerting** if no object appears under `nightly/` by a set time.
- **Keep the shared-drive path available** for a few nights as a rollback option.

## Items that check out

- **Lifecycle rule:** the 7-day expiry is far longer than the 8 hours the pipeline needs. No issue.
- **Object size:** 30 GB is well under the 5 TB per-object limit. The only concern is the upload method in item 2 above.
- **Bucket policy stability:** no pending changes means no surprises from that side. It also means nothing will add a missing grant unless someone does it deliberately.

## Summary

The plan is sound except for one untested assumption: that svc-export can write a 30 GB object to the new location. Because the job runs once with no retry and the release depends on it, run a 10-minute credential test today. If that test fails, this becomes a NO_GO for tonight.

VERDICT: GO_WITH_CHANGES