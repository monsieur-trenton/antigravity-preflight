# Review: billing service date-parsing library upgrade (2.8 → 3.0)

## What holds up

- **Runtime prerequisite is met.** Version 3.0 needs runtime 11 or newer, and every billing host already runs 12.
- **The archived reporting tool is unaffected.** It uses its own pinned 2.8 copy, sits outside the 14 callers, and won't be redeployed.
- **The reason for the upgrade is sound.** The refunds module needs a fix that only 3.0 provides.
- **Timing leaves room.** The 14:00 deploy is 12 hours before the 02:00 invoice run.

## The blocking problem

The plan's central rule is that **none of the 14 existing callers may show any difference in behaviour**. Nothing in the plan checks that rule, and the evidence available argues against assuming it holds.

- **This is a major-version bump.** Under semantic versioning, a move from 2.x to 3.0 is where breaking changes are expected. Typical ones for a date library include changes to:
  - default time zone or UTC handling
  - lenient versus strict parsing
  - two-digit years
  - day/month ordering for ambiguous formats
  - DST and month-end arithmetic
  - format tokens
- **None of the 14 callers has run on 3.0.** The only code exercised so far is the refunds module, which tells us nothing about the existing callers.
- **The failure can't be undone.** If due dates shift, wrong invoices reach customers at 06:00 and can't be recalled. A rollback after the fact won't fix them.
- **The 12-hour window isn't put to use.** The plan includes no testing, comparison, or monitoring step before 02:00. The buffer only matters if something happens during it.

As written, the plan asserts that behaviour won't change rather than establishing it. It ships untested code into a path where mistakes are irreversible. That fails the plan's own stated rule.

## Required changes before this can go

1. **Verify the 14 callers on 3.0 before the deploy.**
   - Run each caller's tests against 3.0.
   - Run a differential check: feed the same representative inputs through 2.8 and 3.0 and diff the outputs. Include real invoice due-date inputs and edge cases such as month-end, leap days, DST transitions, time zones, and ambiguous formats.
   - The rule is met only if there are zero differences.
2. **Review the 2.8 → 3.0 changelog and migration notes** for breaking changes, and map each one to the callers it could affect.
3. **Dry-run the invoice generation on 3.0** in staging, using a copy of the next run's data. Diff the due dates against a 2.8 run.
4. **Protect the irreversible step.** Either hold the 06:00 email send until the 02:00 output has been checked against expected due dates, or have a tested rollback to 2.8 ready before 02:00.
5. **Fallback if any difference appears:** keep the existing callers on 2.8 and limit 3.0 to the refunds module, or delay the upgrade until the callers are fixed.

Once step 1 shows zero differences and steps 2 and 3 are done, this becomes a reasonable GO.

VERDICT: NO_GO