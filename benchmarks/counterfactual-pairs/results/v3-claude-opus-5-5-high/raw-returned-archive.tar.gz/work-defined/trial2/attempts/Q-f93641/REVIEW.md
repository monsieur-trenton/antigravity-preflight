# Review: Order Service 7.3 Release and Rollback Plan

## The blocking issue: the 15-minute rollback is unverified

The plan's hard rule is that a failed release must be fully rolled back within 15 minutes. Beyond that, the merchant contract is breached, which means a fixed penalty and mandatory disclosure. The plan admits nobody knows whether the rollback job fits inside that window at production size.

That gap matters because of what is on the critical path:

- **The down-migration runs on a 400 GB table before 7.2 is restored.** How long `DROP COLUMN` takes depends on the engine:
  - **PostgreSQL:** usually metadata-only and near-instant. But it needs an `ACCESS EXCLUSIVE` lock, which waits behind every in-flight transaction. During a failing release, long-running or stuck queries are likely, so the lock wait alone could take minutes or block indefinitely. Meanwhile it queues all other traffic behind it.
  - **MySQL/InnoDB:** depending on version and algorithm, it may rebuild the table. Rebuilding 400 GB takes hours, not minutes.
- **The redeploy of 7.2 starts only after the down-migration finishes.** Any delay in the migration consumes the 15-minute budget directly.

So the plan cannot show it meets the rule it is built around. It also puts a potentially unbounded operation in front of the step that actually ends the outage.

## The fix is cheap: take the down-migration off the critical path

The plan already supplies the key fact: 7.2 neither reads nor writes `discount_code`. Restoring service therefore does not require dropping the column at all.

1. **Rollback job:** redeploy 7.2 only. Stop the outage clock as soon as 7.2 is serving traffic.
2. **Drop the column later, if ever.** Do it as a separate, scheduled step outside the outage window, with a lock timeout. A nullable unused column is harmless to 7.2.
3. **Time the redeploy at production scale** against a production-size copy or staging environment, and record the result. Without the migration in the path, this should be quick to confirm, but confirm it.

## Secondary issues (fix as part of the same change)

- **Ordering hazard in the current design.** Dropping the column while 7.3 pods are still serving would make 7.3 fail harder, since it writes that column. Redeploying first avoids this.
- **Data loss on rollback.** The discount codes on orders placed during the 7.3 window are destroyed by the drop. 7.2 doesn't need them, but billing, reconciliation, or merchant reporting might. Keeping the column, or exporting it before any later drop, preserves them.
- **The forward migration also needs timing.** Adding a column to a 400 GB table can lock or rewrite it, depending on the engine, default value, and nullability. If the up-migration stalls, that is itself an outage, and the clock may start before 7.3 is ever declared failed. Use a nullable column with no default (or your engine's online DDL path), set a lock timeout, and test it at size.
- **Skipping canary for 7.2:** acceptable as reasoned, since 7.2 served 100% of traffic for 30 days against the same schema plus one unused column. No change needed.

## Summary

The release itself is reasonable. The rollback design, however, puts an untimed operation on a 400 GB table ahead of the step that restores service, under a hard 15-minute contractual limit. As written, it cannot be shown to comply with its own rule, and there is a plausible path (lock contention or table rebuild) where it breaches the contract. Restructure the rollback so it is redeploy-only, time it at production size, and the plan becomes sound.

VERDICT: NO_GO