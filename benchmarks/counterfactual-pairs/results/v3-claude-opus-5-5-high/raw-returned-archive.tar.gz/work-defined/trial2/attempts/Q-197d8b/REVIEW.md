## Review

**Deadlock analysis**

A deadlock needs a cycle in the lock-wait graph. Here is how each path acquires locks:

| Path | Acquisition order |
|---|---|
| Checkout | stock_mu → reserve_mu |
| Restock | stock_mu → reserve_mu |
| Audit | stock_mu only (no nested lock) |

- **Checkout vs. restock:** Both take stock_mu first. Whichever thread wins stock_mu also gets uncontested access to reserve_mu, because the only other thread that wants reserve_mu is blocked on stock_mu. Neither can hold reserve_mu while waiting on stock_mu, so no cycle can form.
- **Audit vs. either:** Audit holds only stock_mu and never waits on anything while holding it. It cannot be part of a cycle. At worst, checkout or restock waits up to about 2 seconds and then proceeds.
- **Concurrency and frequency:** Constant checkout traffic and the 30-second restock cadence make contention common. Contention with a consistent order causes waiting, not deadlock.
- **Completeness:** The plan states that no other code path acquires either mutex, so the lock graph above is complete.

The global ordering of stock_mu before reserve_mu is the standard deadlock-prevention technique, and every path that takes both locks follows it. The "never deadlock" requirement is met.

**Minor notes (not required for correctness)**

- **Write the ordering rule down.** Put it in a code comment or helper so a future path can't take reserve_mu first and silently break the guarantee.
- **Audit latency:** The nightly audit can stall checkouts for up to about 2 seconds. That is a latency blip, not a hang. Shorten it or use a snapshot only if it matters to you.
- **Liveness probe:** The probe can't detect a stuck pod. That is a gap worth fixing eventually, but this plan doesn't create a stuck state.

None of these change whether the plan works as written.

VERDICT: GO