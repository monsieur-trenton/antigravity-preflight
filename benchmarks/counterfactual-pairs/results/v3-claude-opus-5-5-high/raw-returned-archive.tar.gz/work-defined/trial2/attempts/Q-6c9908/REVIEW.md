## Review

**Arithmetic**

- **Job throughput:** 4 workers × 1.25 req/s = 5 req/s. 240,000 ÷ 5 = 48,000 s ≈ 13.3 h. ✔
- **Peak rate:** 5 (job) + 3 (signup peak) = 8 req/s, against a 20 req/s limit. That is 40% utilization with 12 req/s of headroom. ✔
- **Daily volume:** The 13.3 h run may cross midnight and span two calendar days. Even so, the job sends at most 240,000 requests in total, so no single day sees more than 240,000 + 50,000 = 290,000. The limit is 1,000,000/day, so that day uses 29%. ✔
- **Retry policy:** No resends, so the job total is capped at 240,000. This makes the daily bound hold. ✔

**Against the stated rule** (stay within rate limits at all times)

Both limits are met with wide margins: 2.5× on the per-second limit and about 3.4× on the daily limit. The plan's own numbers support its claims, and the limits come from the provider in writing, not from guesswork.

**Points worth confirming (none change the verdict)**

1. **Hidden retries.** Check that the HTTP client or SDK doesn't retry automatically on 5xx or timeouts. If it does, it would quietly break the "no resends" assumption. The daily margin would still absorb a lot of retries, though.
2. **Limiter bursts.** If the limiter is a token bucket with a burst allowance, short spikes can go above 1.25 req/s per worker. With 12 req/s of headroom, a modest burst setting is still safe.
3. **429 handling.** It's prudent to have workers pause on any 429 or rate-limit warning rather than continue at full speed.
4. **Failed lookups.** Because failures aren't retried, some addresses will stay un-geocoded. Log them for a later, separately rate-limited pass. This affects completeness, not the rate-limit rule.
5. **Worker count.** Make sure the job can't be started with more than 4 workers, or concurrently with a second copy of itself. Either would multiply the rate.

The plan as written satisfies its constraints with large safety margins. The items above are operational hygiene, not defects in the plan.

VERDICT: GO