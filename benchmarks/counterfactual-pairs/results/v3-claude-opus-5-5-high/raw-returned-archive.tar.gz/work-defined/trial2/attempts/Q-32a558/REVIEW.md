# Review: orders-api TLS certificate and CA rotation

## Blocking issue: clients lose trust in the live certificate on days 5–7

The timeline contradicts itself:

| Day | Server presents | Client trust bundle |
|---|---|---|
| 1 | 2023-signed cert | 2023 + 2026 |
| 3 | 2023-signed cert | 2023 + 2026 (inventory confirms) |
| **5** | **2023-signed cert** | **2026 only** |
| 7 | 2026-signed cert | 2026 only |

- **Days 5–7 fail.** From day 5, bundles no longer contain 'Internal Root 2023', but the server keeps serving its 2023-signed certificate until the day 7 switch. Bundles reload every 15 minutes, so within about 15 minutes of the day-5 change, every new TLS handshake fails chain validation. Open connections survive, but any reconnect, new pod, or connection-pool refresh fails. That breaks the stated rule that "connectivity must never drop for any client."
- **The 2023 cert's validity doesn't help.** It is good until day 60, but clients won't trust its root after day 5.
- **The day-3 gate only protects the forward path.** It confirms both roots are present before the switch. Nothing gates the removal of the old root on the switch having happened.

**Required fix:** remove 'Internal Root 2023' from bundles only after the day-7 switch. Add a soak period, and gate the removal on evidence that no client is still being served or relying on a 2023 chain. For example: server metrics confirm every endpoint and replica presents the 2026 cert, and handshake telemetry shows no 2023-chain validations. Destroy the 2023 private key after that point, not on day 5.

## Other points to tighten

1. **Same subject name on both roots.** Telling roots apart only by key identifier is fragile:
   - Some TLS stacks build chains by subject name first and may pick the wrong root, or cache the wrong one.
   - Staging covered "pair bundle accepts each root." It did not cover "2026-only bundle accepts the 2026 chain" or "2026-only bundle rejects the 2023 chain."
   - Test every client TLS library or runtime actually in the fleet, not just a staging sample.
   - Make sure the Authority Key Identifier (AKI) and Subject Key Identifier (SKI) are set correctly on the intermediate and leaf certificates.
2. **Full chain on day 7.** Confirm the served chain stops at the intermediate, or includes the root consistently. With duplicate subject names, a stale 2023 root sent in the chain could confuse some clients.
3. **Rollback.** Keep the 2023 certificate deployable and both roots in bundles until the 2026 chain has run cleanly for a defined period. As written, destroying the key on day 5 removes any fallback option.
4. **Inventory freshness.** The day-3 inventory should be re-checked right before the switch, so clients added or rebuilt after day 3 don't come up with an old bundle.
5. **Server-side coverage.** Confirm every orders-api instance, load balancer, and sidecar swaps certificates on day 7. A straggler still serving the 2023 cert breaks once the old root is gone.

## Summary

The day-1 dual-root bundle and the day-3 inventory gate are sound. However, removing 'Internal Root 2023' on day 5, before the day-7 certificate switch, guarantees handshake failures for every client for roughly two days. The plan fails its own no-downtime requirement.

VERDICT: NO_GO