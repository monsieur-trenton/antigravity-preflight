# Review: Nightly Compaction Plan

**Verdict: the plan holds up. Each stated constraint is backed by evidence.**

## Timing

- **Window:** 3 hours, enforced by the scheduler (01:00 to 04:00).
- **Workload:** 1.0 to 1.3 TB per night, based on 90 days of history.
- **Throughput:** 1.0 TB/h, from a full-size rehearsal on a production-class host with the same disks and job settings. Because it used the same settings, the nice 19 and idle I/O class are already reflected in that number.
- **Worst case:** about 1.3 hours. That leaves about 1.7 hours of slack, roughly 2.3 times the required time. The rule that every run must finish inside the window is met with a wide margin.

## Contention

- Idle I/O class only hurts when other I/O competes. The plan rules this out: nothing else is scheduled from 01:00 to 04:00.
- The one nearby job, the backup agent, finishes by 00:45. That is 15 minutes before compaction starts.
- Even a modest backup overrun would cost a small part of the 1.7-hour slack.

## Data safety

- Old segments are deleted only after the new set is fully written and its checksums match the source.
- A killed or failed run therefore cannot cause data loss. The worst result is a wasted night with the old segments still in place.
- `rm -rf` is fine here because it runs only after verification passes.

## Optional hardening (not required for the plan to work)

- Alert if a run passes about 2.5 hours, so slowdowns surface before a kill.
- Track nightly volume against throughput, so growth toward about 2.5 TB per night is noticed early.
- Alert if the backup agent is still running at 01:00.

None of these fixes a defect. The plan works and meets its own rules as written.

VERDICT: GO