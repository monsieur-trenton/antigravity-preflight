**Review: inventory service lock plan**

**Deadlock analysis**

A deadlock needs a cycle in the wait-for graph. Here, at least one thread holds one lock while waiting for another. I'll check every place a lock is acquired:

| Path | Acquisition sequence | Holds one lock while requesting another? |
|---|---|---|
| Checkout | stock_mu → reserve_mu | Yes, in the order stock → reserve |
| Restock | stock_mu → reserve_mu | Yes, in the order stock → reserve |
| Nightly audit | stock_mu only | No |

The plan states there are no other acquisition sites.

- **Checkout vs. restock:** Both take stock_mu before reserve_mu. Whichever thread gets stock_mu first proceeds. The other blocks on stock_mu while holding nothing, so it cannot be part of a cycle. No thread can ever hold reserve_mu while waiting for stock_mu, so the stock → reserve edge is never reversed.
- **Audit vs. either path:** The audit holds only stock_mu and requests nothing else. It can make others wait, but it never waits while holding a lock.
- **Checkout vs. checkout, restock vs. restock:** These use the same order, so the same reasoning applies.

There is a single global lock order with no reversal, so a wait-for cycle cannot form. The no-deadlock requirement is met. Waiting indefinitely with no timeout is safe here, because every wait ends once a holder finishes its bounded critical section.

**Things that are not problems**

- **Frequent concurrency between checkout and restock.** This causes contention, not deadlock. Consistent ordering makes overlap safe no matter how often it happens.
- **The audit holding stock_mu for up to 2 seconds.** Checkouts and restocks stall for up to about 2 s once a night. That is a latency blip, not a hang, and it is bounded.
- **Restock pruning expired reservations under both locks.** This is reasonable, since pruning touches reserved counts and needs reserve_mu. It only lengthens the critical section and does not affect correctness.

**Optional hardening (not required for the plan to work)**

- Write down the stock_mu → reserve_mu ordering rule in code comments or a lock-hierarchy helper. That way a future acquisition site doesn't quietly reverse it. Debug-build lock-order assertions or a tool like TSan would catch regressions.
- If audit stalls ever matter, the audit could copy the counts and release stock_mu before doing its slower work.

These are maintenance niceties for future changes. The plan as described has no defect and satisfies its stated requirement.

VERDICT: GO