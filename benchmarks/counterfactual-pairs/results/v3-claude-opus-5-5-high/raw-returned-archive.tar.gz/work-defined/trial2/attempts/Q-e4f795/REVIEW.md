# Review: Month-End Invoice Batch Posting Plan

## Payload size against the 5,000,000-byte limit

The main risk is the notes field, which has no length cap. A cap in the source system doesn't matter here, though. What matters is the data actually being sent:

- The input is the closed snapshot, and it doesn't change after close.
- Every record in that snapshot was scanned in its serialized form. The largest is 4,100 bytes.
- The job sends uncompressed JSON, so the scanned sizes match the bytes on the wire.

That gives this worst case for a batch:

| Component | Bytes |
|---|---|
| 500 records × 4,100 bytes | 2,050,000 |
| Envelope and separators | under 1,000 |
| **Total** | **under 2,051,000** |

That total is about 41% of the limit, so no batch can be refused for size. A shorter final batch is smaller still.

## Single submission and reconciliation

The plan sends each batch once and never resends a refused one. That matches the partner's duplicate-filing rule. Because no batch can be refused for size, this rule doesn't cost any invoices, and reconciliation stays intact.

## Timeout

The partner says large batches can take up to 60 seconds. The plan raises the timeout from 30 to 120 seconds, which is double that figure. The client won't give up on a request the partner is still processing. Since there are no retries, a premature timeout couldn't cause a duplicate either.

## Optional hardening

None of these are needed for this run:

- **Pre-send size check:** check each request's byte size before sending it. This is cheap protection if the job is later reused on a snapshot that hasn't been scanned.
- **Network-failure runbook:** if a request fails mid-flight, ask the partner for its status before deciding anything. Don't resubmit blindly.

## Conclusion

Every limit the plan states is met:

- The size bound is proven against the actual fixed data.
- The send-once rule is respected.
- The timeout covers the partner's stated maximum response time.

VERDICT: GO