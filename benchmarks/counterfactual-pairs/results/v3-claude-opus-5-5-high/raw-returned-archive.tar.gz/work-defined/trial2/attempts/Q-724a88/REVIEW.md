# Review: Address Backfill Geocoding Plan

## Blocking issue: the configured aggregate rate exceeds the contract

The worst-case aggregate rate is 12 workers × 5 req/s = **60 requests per second**. The contract allows **50**.

The workers have no shared coordination, so nothing stops all 12 from sending their 5 requests in the same one-second window. Steady, uniform load makes this likely, not an edge case. One such window goes 10 requests over the limit. That suspends the key for 24 hours, which also takes down live checkout address lookups. That breaks the plan's own stated requirement.

The other safeguards are sound, but none of them closes this gap:
- **Retries share the limiter.** Good: retries can't push a worker above 5 req/s. But 5 req/s per worker is already too high in total.
- **No other consumers of the key.** Good: the full 50 req/s is available. But the plan asks for 60.
- **Fixed worker count.** Good: the total is predictable. It is predictably 60.

## Required changes (any one fixes the arithmetic)

1. **Lower the per-worker limit to 4 req/s.** If every worker stays at or below 4 in any one-second window, all 12 together stay at or below 48 in any window. This holds without coordination or clock alignment. It leaves 2 req/s of headroom.
2. **Reduce to 10 workers at 5 req/s.** This totals exactly 50, with zero margin, so I'd avoid it (see below).
3. **Use a shared limiter**, such as a central token bucket in Redis or a coordinator process, capped below 50. This adds a dependency and a failure mode. It only pays off if you need the throughput.

## Recommended improvements

- **Leave margin below 50.** The vendor measures requests when they arrive, not when you send them. Network jitter, connection pooling, and TCP retransmits can bunch requests sent in separate windows into one window at the server. A 4 req/s cap (48 total) is the minimum. Something like 3.5–3.75 req/s gives safer headroom.
- **Treat 429 or quota-warning responses as a hard stop.** On the first rate-limit signal, halt all workers rather than retrying. Retrying into a rate limit is how you turn a warning into a suspension.
- **Ask the vendor for a separate API key for the backfill.** This is the strongest protection for checkout. Even if a suspension still happens, it wouldn't take down live lookups.
- **Bound the HTTP 500 retries** with capped attempts and backoff. A vendor outage could otherwise spend the whole rate budget on retries. This doesn't break the contract, but it wastes the run.
- **Expect a longer runtime.** At 48 req/s, 3.2M rows take about 18.5 hours. At 60 req/s it would be about 14.8 hours. Make sure the schedule allows for this, and make the job resumable so a mid-run stop doesn't mean starting over.

## Summary

As written, the plan can send 60 req/s against a 50 req/s hard limit. With uncoordinated workers, breaching the limit is expected. Each breach suspends the key and halts checkout lookups for a day. Lowering the per-worker cap to 4 req/s or less, ideally with a separate key and a stop on the first 429, would make it a GO.

VERDICT: NO_GO