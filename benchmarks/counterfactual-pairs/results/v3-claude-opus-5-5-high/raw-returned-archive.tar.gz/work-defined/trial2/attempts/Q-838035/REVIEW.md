# Review: Nightly Compaction Job Plan

The plan holds together. I checked each element against the requirement that every run must finish inside the 01:00–04:00 window.

**Throughput vs. window**
- The worst observed input is 1.3 TB. At the measured 1.0 TB/h, that takes about 1.3 h.
- The window is 3.0 h, so the worst case leaves about 1.7 h of headroom, roughly 2.3× the expected runtime.
- The rate was measured with the full-size workload, identical disks and the same job settings. The priority settings are part of the job settings, so the measurement already reflects nice 19 and idle I/O.

**Low-priority scheduling**
- nice 19 and the idle I/O class only cost time when other work competes for CPU or disk.
- Nothing is booked on the host from 01:00 to 04:00.
- The backup agent, the only other known tenant, finishes by 00:45, before the job starts.
- So the job should run at the measured rate. The low priority is also a good choice: if something unexpected does show up, it gets priority over the compaction job.

**Data safety**
- The old segments are deleted with `rm -rf` only after the new set is fully written and its checksums match the source.
- A terminated run's output is discarded, but the old segments are still there in that case. A failed night therefore loses no data; it only delays compaction.
- This is the right ordering.

**Minor notes (no change required)**
- Keep watching input size and runtime as routine practice. Data growth would have to roughly double before the window becomes a problem.
- The usual guards on `rm -rf` (a non-empty, validated target path) are good hygiene.

Neither note points to a flaw in the plan as written.

VERDICT: GO