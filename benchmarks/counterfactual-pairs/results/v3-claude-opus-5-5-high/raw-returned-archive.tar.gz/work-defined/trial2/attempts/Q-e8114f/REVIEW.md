# Review: Per-Request Logging for the Payments Gateway

## Blocking issue: bearer tokens will be written to the logs

The redaction list covers only `Cookie` and `X-Api-Key`, but the plan logs every request header name and value at INFO. Several facts in the plan combine to break its own rule:

1. Every caller sends a bearer token in the `Authorization` header.
2. That header is not on the redaction list, so its value is logged in full.
3. Production runs at INFO, so this happens on every production request.
4. Logs go to a shared cluster that every engineer can search for 90 days.

The result is that every live caller credential would sit in a company-wide searchable store for 90 days. The rule explicitly names bearer tokens as credentials, so the plan fails as written. If any of this has already reached a non-production environment that ships to the shared cluster, treat those tokens as exposed: rotate them and purge the logs.

## Required changes

- **Switch from a denylist to an allowlist.** Log only headers known to be safe and useful for tracing, for example `Content-Type`, `Content-Length`, `User-Agent`, `Accept` and `X-Forwarded-For` (subject to your PII policy). Drop or redact everything else. A denylist will keep missing things: `Authorization` here, and later `Proxy-Authorization`, custom `X-*-Token` headers, or whatever a new integration adds.
- **If you keep a denylist anyway**, it must at minimum cover `Authorization`, `Proxy-Authorization`, `Cookie` and `X-Api-Key`. Header names must be matched case-insensitively, and every occurrence of a repeated header must be redacted.
- **Consider moving full header logging to DEBUG** and keeping it off in production. The tracing goal (finding slow upstream calls) is already met by the one-line summary: method, path, status, latency and request ID. Header dumps add risk without helping with latency.

## Smaller improvements

- **Check the upstream side too.** If the gateway logs outbound calls to upstreams, the same scrubbing must apply to the credentials it sends upstream, not only to incoming request headers.
- **Add a test that fails the build** if a request carrying known credential headers produces a log line containing their values.
- **Keep what's already good.** Stripping the query string from the path, not logging bodies, and using a random request ID not derived from the token are all correct choices. Note that the query-string stripping also matters because some clients put tokens in query parameters.

VERDICT: NO_GO