# Review: orders-api TLS certificate and CA rotation

**The plan breaks its own no-connectivity-loss rule.** Root 2023 is removed from client trust bundles on day 5. The server keeps presenting its Root 2023 certificate until day 7. Because the plan lists steps out of date order, this is easy to miss.

## Blocking issue: days 5 to 7

- **Day 5:** Root 2023 is removed from the trust bundle. Within about 15 minutes, every client reloads a bundle that contains only Root 2026.
- **Days 5 to 7:** The server still presents its certificate issued by Root 2023. No client can validate it, so every new connection and reconnect fails for about two days. Already-open connections survive only because clients don't re-validate them, and any that close cannot be re-established.
- **Rollback is lost:** Destroying the Root 2023 key on day 5 also removes the ability to recover. If the day-7 certificate has a problem, falling back to the old certificate (valid until day 60) is no longer possible, because clients no longer trust its root.

## Required changes

1. **Move the Root 2023 removal to after the day-7 switch.** Do it only once you have confirmed:
   - the server is presenting the Root 2026 certificate everywhere, on every instance and load balancer;
   - no connections still depend on the old certificate;
   - a bake period has passed during which rollback remained possible.

   It must also happen before day 60.
2. **Gate the removal the way day 3 gates the switch.** Require a check, such as TLS handshake metrics or a scan, showing that only the new certificate is being served.
3. **Destroy the Root 2023 key only after removal is complete and the rollback window has closed.** Keeping it offline until then costs nothing.

## Non-blocking improvements

- **Shared subject name:** Both roots have the same subject name and differ only in key identifier. Make sure the new certificate's chain carries a correct Authority Key Identifier. The staging result is reassuring, but confirm that staging covered every client TLS library and version in production, since some libraries build chains by subject name.
- **Day-3 inventory check:** Define "every client" against an authoritative list of clients. Clients that are not reporting should block the switch rather than be silently left out.
- **Rollback plan:** Write down an explicit rollback for day 7, such as re-deploying the old certificate, while Root 2023 is still trusted.

VERDICT: NO_GO