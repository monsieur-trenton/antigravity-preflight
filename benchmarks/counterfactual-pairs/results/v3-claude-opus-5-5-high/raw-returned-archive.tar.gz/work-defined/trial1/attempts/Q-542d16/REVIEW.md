# Review: Nightly Export Cutover to exports-prod/nightly/

## Summary

Most of the plan holds up. The one serious gap is that svc-export has never been confirmed able to write to the new location. Tonight's run happens once, has no retry, and feeds a 09:00 release. A failed run means nothing ships that day.

## What checks out

- **Lifecycle rule:** Objects are deleted after 7 days, and the pipeline reads each export within 8 hours. That leaves a wide margin.
- **Object size:** About 30 GB against a 5 TB per-object limit. No issue.
- **Policy stability:** The bucket policy is managed in the infrastructure repo and has no pending changes. Nothing should shift under the run tonight.

## Main risk: write access is unverified

- Nobody has written to `exports-prod/nightly/` using svc-export's own credentials, and its permissions on the bucket haven't been checked.
- The run starts at 01:00 and does not retry. If the write is denied, the failure won't show up until someone sees the 09:00 pipeline blocked. By then it may be too late to fix permissions, rerun a 30 GB export, and still release that day.
- Nothing shows the write will fail, but nothing shows it will succeed either.

## Required changes before 01:00

1. **Test the write path as svc-export.** Use its actual credentials, not an admin role or a human user. Write a small test object to `exports-prod/nightly/`, then read it back and delete it if those permissions apply.
2. **Check for large-upload problems.** A 30 GB object will probably go up as a multipart upload. Confirm the policy allows the multipart actions, and confirm svc-export can use the bucket's encryption key if the bucket uses KMS.
3. **Check the pipeline's read access.** Confirm the 09:00 release pipeline can read from the new prefix too. Its source has also moved off the shared drive.

## Recommended improvements

4. **Add a fallback.** Either configure one retry, or keep the shared-drive export running in parallel for tonight so the release has something to use if the new path fails.
5. **Alert early.** Notify someone if the export hasn't completed by about 03:00. That leaves several hours to fix and rerun before 09:00.

## Verdict rationale

Nothing in the plan shows it will fail, so this isn't NO_GO. Even so, change #1 is a hard precondition, and the plan shouldn't run tonight until it passes. If the test write is denied and permissions can't be fixed in time, the verdict becomes NO_GO, and tonight's export should stay on the shared drive.

VERDICT: GO_WITH_CHANGES