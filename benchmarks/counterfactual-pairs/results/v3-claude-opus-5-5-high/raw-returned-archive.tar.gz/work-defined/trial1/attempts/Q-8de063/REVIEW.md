# Review: Checkout Payment Retry Plan

The plan meets its stated rule. The changes below are hardening, not fixes.

## Why the no-double-charge rule holds

- **The key is stable.** It is the order's UUID, created once, stored with the order, and sent unchanged on every attempt. Every retry is the same request to the processor.
- **The timing fits inside the deduplication window.** All attempts finish within 10 minutes, and the processor deduplicates for 24 hours. A timeout where the processor actually accepted the charge is caught: the retry returns the original result instead of charging again.
- **Retrying after an unknown outcome is safe.** The idempotency key is what makes this deliberate choice work. Without the key it would be the classic double-charge bug.
- **Concurrent duplicates are also covered.** If two workers pick up the same order, they send the same key and get one charge.

## Recommended changes

1. **Handle orders whose outcome is still unknown after the last retry.** If all 4 attempts time out, the order is left with an unknown status. The plan should mark it as "payment pending/unknown" and reconcile it. It could query the processor by key or charge reference, or retry later while still inside the 24-hour window. It should never treat the order as unpaid and start a fresh charge flow.

2. **Retrying definite failures may be pointless.** The processor "returns the original result" for a repeated key. A retry after a definitive failure would then just replay that cached failure. Confirm whether the processor caches errors such as 5xx responses or rate limits. If it does, retrying with the same key cannot recover from a transient failure. In that case:
   - classify errors as retryable or non-retryable;
   - decide deliberately what happens next, such as surfacing the failure to the customer.
   
   Do not mint a new key to "fix" this. That would break the double-charge guarantee whenever the first attempt actually succeeded.

3. **Protect the 24-hour window outside the worker.** The guarantee depends on no attempt with this key happening more than 24 hours after the first. Other paths could break that:
   - a re-enqueued job;
   - a manual "retry payment" in an admin tool;
   - replay from a dead-letter queue.
   
   Before any submission, check the order's stored payment state, and block or reconcile any attempt after 24 hours.

4. **Record the processor's charge ID.** Store it, plus the attempt history, with the order. This supports reconciliation, refunds and audits, and gives a local check before submitting at all.

VERDICT: GO_WITH_CHANGES