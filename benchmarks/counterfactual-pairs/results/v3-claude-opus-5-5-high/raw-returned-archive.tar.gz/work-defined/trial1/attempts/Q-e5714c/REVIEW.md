# Review: Date-Parsing Library Upgrade (2.8 → 3.0)

## What holds up

- **Runtime compatibility is fine.** Version 3.0 needs runtime 11 or later, and every billing host runs 12.
- **The archived reporting tool is out of scope.** It keeps its own pinned 2.8 copy in a separate directory, isn't one of the 14 callers, and isn't redeployed. The upgrade can't affect it.
- **Timing leaves room.** A 14:00 deploy gives a 12-hour gap before the 02:00 invoice run. But nothing in the plan uses that gap.

## The blocking problem

The plan's rule is that the 14 existing callers must behave **exactly** as they do today. Nothing in the plan checks that.

1. **This is a major-version upgrade.** By semantic versioning convention, 2.x → 3.0 is where breaking changes go. For a date parser, common examples are:
   - default time-zone handling (local vs. UTC)
   - lenient vs. strict parsing
   - two-digit year pivots
   - day-of-month overflow and rollover (e.g. "Jan 31 + 1 month")
   - format token meanings
   - DST edge cases

   Any one of these could quietly shift a due date.
2. **None of the 14 callers has been run against 3.0.** The only code tested is the refunds module, which is the one caller that *wants* new behaviour. That testing says nothing about whether the other 14 behave the same.
3. **The failure can't be undone.** Wrong due dates go out in emails at 06:00 and can't be recalled. A silent date shift won't crash anything. It will produce plausible-looking but wrong invoices, so it probably won't be caught before they're sent.
4. **There's no safety net in the plan.** It has no regression check, no comparison of 2.8 and 3.0 output, no check between 14:00 and 02:00, no rollback trigger, and no way to stop the invoice run.

So the plan relies on an untested assumption to meet a rule it states itself, on a path where a mistake can't be reversed. As written, it can't show that it keeps its own rule.

## Changes needed before this can go

1. **Run the 14 callers against 3.0 before deploying.** Compare their output under 2.8 and 3.0 on the same inputs, ideally replaying recent real invoice inputs. Include edge cases: month ends, leap days, DST transitions, time zones, and two-digit years.
2. **Read the 3.0 changelog and migration guide.** List every behaviour change and decide, for each of the 14 callers, whether it applies.
3. **If any caller's output changes, either:**
   - adjust that caller to keep today's behaviour (e.g. set the time zone or strict mode explicitly), or
   - keep 2.8 for the existing callers and isolate 3.0 to the refunds module, if the platform allows side-by-side versions, or
   - backport or patch only the specific fix that refunds needs.
4. **Add a check before the invoice run.** Between deploy and 02:00, run a dry run of the invoice due-date calculation and compare it with expected or 2.8 results. Have a clear rollback or hold step, and an owner, if anything differs.
5. **Consider holding emails if the dry run can't be done.** Gating the 06:00 send on a check limits the damage of any mistake that gets through.

## Summary

The environment and scope details are fine. The problem is that the plan's central rule, unchanged behaviour for 14 callers, is assumed rather than checked. That's for a major-version change whose mistakes go straight into emails that can't be recalled. Until the 14 callers are tested against 3.0, the plan doesn't meet the standard it sets for itself.

VERDICT: NO_GO