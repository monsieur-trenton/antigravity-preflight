# Review: Orders PostgreSQL Point-in-Time Recovery Plan

## Does the plan meet its stated goal?

Yes. The figures are consistent:

- **Oldest recovery point (14 days back):** The plan correctly sees that weekly base backups mean a 14-day-old target can need a base backup up to about 21 days old. Base backups and WAL are both kept for 28 days. That leaves about 7 days of margin, so every point in the 14-day window has a usable base backup and an unbroken WAL chain.
- **Newest recovery point (5 minutes ago):** WAL is archived within 60 seconds, well inside the 5-minute target.
- **Lifecycle deletion:** Deleting objects older than 28 days never touches anything a valid restore needs. A nightly job means objects live up to about 29 days, which only adds margin.
- **Protection against a compromised database host:** The bucket sits in a separate account, and the hosts can only write new objects. A compromised host cannot destroy existing backups.
- **Testing:** Restores are rehearsed monthly at the old end of the window, which is the hardest case.

Nothing in the plan fails or contradicts its own rules. The changes below would make it more robust.

## Recommended changes

1. **One failed Sunday backup breaks the 14-day guarantee.** If a weekly backup fails, a 14-day-old target can need a base backup up to about 28 days old. That is exactly when the lifecycle job deletes it, and the window can briefly break before anyone notices.
   - Raise retention to about 35 days, or
   - Alert on backup failure and re-run the backup on the same day.

2. **Make the 60-second WAL claim hold under light traffic.** PostgreSQL archives a WAL segment only when it is full or when `archive_timeout` forces a switch. During quiet periods a segment can stay open far longer than 5 minutes.
   - Set `archive_timeout` to 60 seconds or less.
   - Monitor archive lag (`pg_stat_archiver`: `last_archived_time`, `failed_count`). The 5-minute target fails silently if archiving stalls.

3. **Check the WAL chain, not just object age.** Deleting WAL purely by age is correct only while every weekly backup succeeds.
   - Have the lifecycle job keep all WAL newer than the oldest base backup it keeps, or
   - Run a nightly check that the chain from the oldest kept base backup to now has no gaps.

4. **Don't rely on the lifecycle job's rule as a safeguard.** The job has broad delete permission, and only its rule configuration keeps it from deleting too much. A wrong rule or a compromised job credential could wipe the bucket.
   - Use object lock or retention (compliance mode, at least 21 days) so nothing can delete objects inside the needed window.

5. **Widen what the rehearsal covers.**
   - Also test a restore to the recent end of the window (about 5 minutes ago) to confirm WAL is actually being archived.
   - Sometimes pick a target just before a Sunday backup, so the restore uses a base backup about 21 days old.
   - Measure restore time. The plan has no recovery-time objective, and replaying up to 21 days of WAL may be slow.

6. **Clarify which backup counts as "taken before that time".** A base backup is usable only after it has completed. Restores to points during the Sunday backup must use the previous week's backup. This is still within retention, but the restore tooling should handle it.

VERDICT: GO_WITH_CHANGES