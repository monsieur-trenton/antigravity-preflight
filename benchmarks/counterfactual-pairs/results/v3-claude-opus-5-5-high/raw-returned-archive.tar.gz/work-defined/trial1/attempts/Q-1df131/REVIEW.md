# Review: orders-api TLS certificate and CA rotation

The plan works as written. The ordering is correct: trust the new root, verify, switch, then remove the old root. A few gaps should be closed before running it.

## Why the sequence holds

- **Day 1 to day 7:** The server still presents the 2023-issued certificate. Every bundle, old or new, contains Root 2023, so no client can fail during the bundle rollout.
- **Day 3 gate:** Before the switch, the inventory must show every client holding the dual-root bundle. The 15-minute reload means day 1 to day 3 is far longer than needed for clients to pick it up.
- **Day 7 switch:** Every client trusts Root 2026, and the server sends the full chain, so new handshakes succeed. Connections opened before the switch stay up, because a bundle reload doesn't drop open connections.
- **Day 30 removal:** By now the server has presented only 2026 certificates for 23 days. Removing Root 2023 affects no live handshakes. The old leaf is valid until day 60, which never becomes a constraint. Destroying the old root key after its trust is withdrawn is sound.

## Recommended changes

1. **Prove staging covers every production TLS stack.** Both roots share a subject name and differ only by key identifier. Some path builders look up issuers by name alone, pick the wrong root, and fail the signature check. Examples are older OpenSSL versions, some Java and Go versions, and embedded clients. Staging passing only matters if it includes every client library and version in production. Better still, give Root 2026 a distinct subject name, such as one with a "2026" suffix, which removes the ambiguity entirely.
2. **Canary the day 7 switch.** Move one instance or a small slice of traffic to the new certificate first. Watch client-side handshake failures and alert on them before rolling out fully.
3. **Write down the rollback plan.** From day 7 to day 30, rolling back means re-presenting the 2023-issued certificate, which stays valid until day 60. Keep that certificate and its key deployable until day 30. After day 30, rollback is impossible, so make day 30 an explicit go/no-go step. Gate it on zero handshake failures since day 7 and on confirming no client still pins or requires Root 2023.
4. **Tighten the day 3 gate.** Define what happens to clients that are offline or not reporting. They should block the switch rather than be silently skipped. Also confirm the inventory checks the hash of the exact dual-root bundle, not just a non-stale one. Any client provisioned after day 3 must receive the same bundle.
5. **Handle the 2023 hierarchy's remaining duties.** If anything publishes CRLs or OCSP signed under Root 2023, or depends on them, plan for it before destroying the key on day 30.

VERDICT: GO_WITH_CHANGES