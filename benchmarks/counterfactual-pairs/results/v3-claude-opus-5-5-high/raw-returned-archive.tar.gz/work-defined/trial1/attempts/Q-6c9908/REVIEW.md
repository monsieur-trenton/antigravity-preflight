# Review: Address Backfill Geocoding Plan

## Arithmetic checks

| Claim | Check | Result |
|---|---|---|
| Job throughput ≤ 5 req/s | 4 workers × 1.25 req/s = 5 req/s | ✅ |
| Runtime ≈ 13.3 h | 240,000 ÷ 5 = 48,000 s ≈ 13.33 h | ✅ |
| Combined peak 8 req/s | 5 (job) + 3 (signup peak) = 8 | ✅ |
| Max requests in one day ≤ 290,000 | Whole job (240,000) + signup daily peak (50,000) | ✅ (conservative: even if the run fell entirely in one calendar day) |
| Job total ≤ 240,000 | No resends of failed lookups | ✅ |

## Against the provider's limits

- **Per-second:** 8 vs. 20 req/s. That uses 40% of the limit, with 12 req/s of headroom. Signup traffic would need to reach 15 req/s, five times its 6-month peak, before the limit was at risk.
- **Per-day:** 290,000 vs. 1,000,000. That uses 29% of the limit, and the worst case is already assumed.
- The limits are documented in writing by the provider, so they are not guesses.

All of the plan's figures are correct. It stays within both limits at all times with a wide margin, which meets its own stated requirement.

## Optional hardening (not required)

The headroom is large enough that none of these are needed. They are cheap insurance:

- **Limiter bursts:** Confirm the client-side limiter's burst or bucket size is small. A token bucket that builds up capacity while idle could briefly spike, though even a few extra requests per worker would stay far below 20 req/s.
- **Worker restarts:** If a worker crashes and restarts, make sure it resumes from a checkpoint rather than reprocessing completed addresses. That keeps the 240,000 total true in practice and not only in the design.
- **Kill switch / 429 monitoring:** Alert on any rate-limit responses and be able to pause the job quickly. This protects signup lookups against anything unexpected.

None of these change whether the plan as written works. It does.

VERDICT: GO