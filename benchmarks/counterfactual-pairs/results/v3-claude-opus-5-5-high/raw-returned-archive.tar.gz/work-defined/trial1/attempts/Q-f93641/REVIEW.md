# Review: Order Service 7.3 Release and Rollback Plan

## Blocking issue: the 15-minute rollback is unverified, and the job's ordering puts it at risk

The release policy sets a hard limit: a full rollback within 15 minutes. The contract makes going over that limit a penalized, disclosable breach. The plan's own text admits nobody has timed the rollback job at production size. So nothing in the plan shows it can meet the one constraint that matters most tonight.

The job's ordering also puts the riskiest step first. It runs the down-migration before redeploying 7.2. That means a schema change on a 400 GB table sits on the critical path while the outage clock is running:

- **Table rewrite risk.** On some engines and versions, `DROP COLUMN` rebuilds the whole table, as MySQL/InnoDB does without `ALGORITHM=INSTANT` on older 8.0 versions. At 400 GB, that takes hours, not minutes.
- **Lock risk even when the drop is metadata-only.** In PostgreSQL, `DROP COLUMN` is near-instant but needs an `ACCESS EXCLUSIVE` lock. During a failed release, long-running queries and transactions are likely. The `ALTER` can queue behind them, and every other query on `orders` then queues behind the `ALTER`. The result is a full stall of unknown length.
- **It breaks the running version.** If 7.3 is still serving while the column drops, every 7.3 write that touches `discount_code` fails. The outage gets worse before 7.2 is even deployed.

The plan states that 7.2 neither reads nor writes `discount_code`, so the drop isn't needed to restore service. Running it before the redeploy adds an unbounded, untested delay to a step that has a 15-minute limit.

## Required changes

1. **Take the down-migration off the critical path.** Make the rollback job redeploy 7.2 against the current schema, with the column still present. Then drop the column later as a separate, scheduled cleanup, using a lock timeout and an online or instant method.
   - First confirm with the policy owner that "completely rolled back" means the prior version is serving traffic, which is how the contract defines it. It should not require the schema to be reverted. If the policy really does require the schema revert inside 15 minutes, the timing test in item 2 becomes mandatory before release.
2. **Time the rollback job against a production-sized copy before tonight.** Include a realistic concurrent load. If that can't happen tonight, postpone the release.
3. **Verify 7.2 runs cleanly with the extra column present.** Check for ORM strict-schema validation, `SELECT *` mapped into fixed structs, `INSERT` statements without column lists, and replication or CDC consumers. If you adopt change 1, this becomes the configuration you depend on.
4. **Check the up-migration too.** Adding a column with a default or `NOT NULL` can also rewrite a 400 GB table on some engines. Confirm it's a metadata-only change, or tonight's release may cause the outage itself.

## Acceptable as written

- Skipping the canary stage when redeploying 7.2 is reasonable. It carried all production traffic for 30 days, and a canary would cost time you don't have.
- An automatic trigger on the failure declaration is good. It removes human delay from the clock.

## Summary

The plan can't show it meets its own 15-minute rollback rule. It also puts an untimed schema change on a 400 GB table into that 15-minute window, even though the change isn't needed to restore service. The fix is simple: redeploy first, drop the column later, and time the job. Until that's done, the release shouldn't proceed.

VERDICT: NO_GO