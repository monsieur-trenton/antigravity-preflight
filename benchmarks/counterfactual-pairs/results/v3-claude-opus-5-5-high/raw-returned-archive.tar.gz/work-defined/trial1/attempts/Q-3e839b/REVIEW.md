# Review: orders-api TLS certificate and CA rotation

The plan works as written. The core sequence is correct: clients trust both roots first, the server switches only after that is confirmed, and the old root is removed only after the switch. Some hardening is still worthwhile.

## What holds up

- **Trust comes before the switch.** On day 1, clients get a bundle containing both roots. Clients re-read the bundle every 15 minutes, so all of them pick it up well before day 7.
- **The switch depends on evidence, not a date.** The day 3 inventory must show every client with a bundle hash covering both roots before the switch is scheduled. That inventory is what makes the "never drop connectivity" promise checkable.
- **The old certificate is never at risk.** It stays valid until day 60 and is only served until day 7.
- **Existing connections survive.** Bundle reloads don't close open connections. Connections opened before day 7 were validated against the old certificate and are unaffected by the switch.
- **The server sends its full chain from day 7.** Clients don't need to fetch or guess at intermediates.
- **Removing the 2023 root on day 30 is safe.** By then the server has presented a 2026 certificate for 23 days, so no client needs the old root. Taking the old key offline on day 1 and destroying it on day 30 is good practice.
- **The riskiest detail was tested.** Both roots have the same subject name and differ only by key identifier, which can confuse some chain-building code. Staging confirmed that clients holding both roots accept certificates from either one.

## Recommended changes

1. **Check the inventory again just before day 7 and day 30.** The day 3 snapshot could go stale if a client is restored from an old image, rolled back, or redeployed with the original bundle between day 3 and day 7. Require a fresh 100% inventory immediately before the switch. Run another before day 30 to confirm every client holds the 2026 root, so removing the 2023 root strands no one.
2. **Define a rollback for days 7–30.** If the 2026 certificate causes problems, the old 2023 certificate is still valid and still trusted until day 30. Write that down as the explicit rollback path, and don't destroy the old key or remove the 2023 root until the rollback window is formally closed.
3. **Monitor handshake failures during the switch.** Watch TLS handshake errors on both server and client side, broken down by client, during the day 7 cutover. Switching gradually or by canary, if the deployment allows it, would limit the impact of anything the inventory missed.
4. **Cover the shared subject name more thoroughly.**
   - Make sure staging includes every client TLS stack and version used in production. Matching by key identifier is where implementations differ.
   - Check that the day 7 chain doesn't include a cross-signed or ambiguous certificate that could lead a client to the 2023 root.
   - For the next rotation, give each root a distinct subject name, such as one with the year in it, to remove this whole class of risk.
5. **Make the inventory confirm the bundle is loaded, not just present.** A matching hash shows the file on disk is correct. Where possible, also confirm each client has actually loaded the new bundle, for example through a reload timestamp or a test handshake against a 2026-signed endpoint.

VERDICT: GO_WITH_CHANGES