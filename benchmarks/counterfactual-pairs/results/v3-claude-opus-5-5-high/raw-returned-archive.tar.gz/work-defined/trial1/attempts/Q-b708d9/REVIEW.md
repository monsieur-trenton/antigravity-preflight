# Review: Split-Payment Rollout, Checkout Release 4.12

## Blocking issue

**The production flag default contradicts the plan's own rule.** The plan says new code paths must go to production disabled and be activated only through a separate approved flag change. But `flags.yaml` sets `checkout.split_payment` to **true** for production.

If 4.12 ships as written:
- Split payment goes live in production at deploy time, with no separate approved flag change.
- "Production customers keep going through [single-payment] as long as the flag is off" stops being true, because the flag is never off.
- The `split_payment_ref` column starts receiving production writes immediately, so the claim that "no writes reach it with the flag off" no longer protects anything.
- The deferred change ticket, gated on two weeks of staging traffic, is skipped entirely.

**Fix:** set the production default to `false`. Dev and staging can stay `true`.

## Other points (non-blocking once the default is fixed)

1. **"Mirroring production" is inaccurate as written.** With production at `true`, the flag-forced-off CI pass doesn't mirror production. After the fix it will, so the dual-pass approach is sound. It's worth confirming that the forced-off pass runs against the 4.12 build that includes the migration.
2. **Plan for the 30-second cache window.** When the flag is flipped, pods will disagree for up to 30 seconds. A checkout could start on one path and finish on the other, especially if requests are retried or spread across pods. Confirm that each order is pinned to one path, for example by evaluating the flag once per checkout session. Also confirm that an order with a `split_payment_ref` stays readable if the flag is turned back off, since rollback has the same mixed-state window.
3. **Migration lock.** A lock under 1 second on a full-size staging copy is reassuring. Still, run the migration during low traffic and set a lock timeout, because production may have long-running transactions on `orders` that staging doesn't.
4. **Define the staging soak criteria.** "Two weeks of traffic" should come with exit criteria for the activation ticket, such as error rates, reconciliation checks on split orders, and a minimum count of split-payment transactions.
5. **Rollback.** State that turning the flag off is the rollback, and that the nullable column can stay in place harmlessly.

## Summary

The structure is good: flag gating, an unchanged legacy path, a nullable additive column, dual-mode CI, and a separate activation ticket. But the production default of `true` breaks the release rule and would activate split payment at deploy. Change it to `false` before proceeding.

VERDICT: NO_GO