## Review

**The plan violates its own rule.** A customer can be charged more than once for a single order.

### The failure path

1. Attempt 1 is sent with key `K1`. The processor accepts it and charges the card, but the response times out before the worker receives it.
2. The worker treats this as a timeout with an unknown outcome and retries, as designed.
3. The retry generates a fresh UUID, `K2`. The processor sees a new key and, per its stated semantics, **creates a new charge**.
4. The customer has now been charged twice. With up to 3 retries, they could be charged up to 4 times.

The plan already accepts both ingredients of this failure. It states that a timeout may already have been charged, and it deliberately retries after timeouts. Using a new key on each attempt removes the one safeguard the processor offers. The idempotency key only helps if it stays the same across retries of the same logical charge.

### Required changes

- **Use one idempotency key per order, not per attempt.** Generate it once when the payment is first scheduled, or derive it deterministically, for example from the order ID plus a payment-intent ID. Persist it with the order *before* the first attempt, so a worker crash or restart reuses the same key.
- **Reuse that key on every retry.** All attempts finish within 10 minutes, well inside the processor's 24-hour deduplication window, so a retry after an ambiguous timeout returns the original result instead of charging again.
- **Only issue a new key for a genuinely new charge attempt.** One example is a customer resubmitting after a definitive decline with a different card. That should be a deliberate state transition, not something a retry loop does.

### Recommended improvements

- **Separate retryable from terminal failures.** Retry timeouts, 5xx errors, and network errors. Do not blindly retry definitive declines or validation errors.
- **Reconcile after exhausting retries.** If all 4 attempts time out, the outcome is still unknown. Mark the order "payment pending/unknown" and look up the charge by idempotency key or order reference. Do not mark it unpaid, and do not let a later process charge it with a new key.
- **Guard against concurrent workers.** Make sure two workers cannot pick up the same order at once, using a lock, a lease, or a status compare-and-set. Concurrent submissions with the same key are generally safe, but this avoids confusing state.
- **Record each attempt** with its key, timestamp, and response so ambiguous cases can be audited.

With one persisted key per order, the retry strategy becomes sound. As written, it directly produces duplicate charges in exactly the timeout scenario it is meant to handle.

VERDICT: NO_GO