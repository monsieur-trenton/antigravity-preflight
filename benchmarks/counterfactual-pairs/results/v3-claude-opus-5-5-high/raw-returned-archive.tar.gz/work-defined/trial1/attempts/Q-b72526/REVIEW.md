# Review: Release 4.12 Split-Payment Plan

The plan meets its own release rule. The flag is false in production, the existing single-payment path is unchanged and stays live, and enabling the flag is a separate, approved change ticket. CI also tests the flag-off state that production will run. Nothing here will fail or break a stated rule. A few gaps are worth closing first.

## What works

- **The release rule is met.** The new code path ships off in production, and turning it on is a separate ticket.
- **Production state is tested.** The CI run with the flag forced off checks the configuration production will actually use.
- **The migration is low risk.** The column is nullable and unwritten while the flag is off, and it locked for under 1 second on a full-size copy.
- **Flips need no redeploy.** A 30-second cache bound is reasonable for turning the flag on and for turning it off in an emergency.

## Recommended changes

1. **Set a lock timeout on the migration.** A short lock on a staging copy doesn't guarantee a short lock in production. The `ALTER TABLE` can queue behind a long-running transaction on `orders`, and while it waits it blocks all reads and writes queued behind it. Set a `lock_timeout` (or equivalent) with retry, and run it in a low-traffic window.

2. **Define what happens when flag lookup fails.** The plan gives defaults per environment but not the behaviour when the flag source is unreachable or the cache is cold. This should explicitly fail closed to `false` in production, so an outage in the flag service can't switch the path on.

3. **Plan for the 30-second mixed state.** During a flip, some pods will have the flag on and some off. A split-payment checkout could start on one pod and continue on another that doesn't recognise it. State whether that is handled, for example with flag evaluation pinned per checkout session, or a flag-off path that can still finish an in-flight split order.

4. **Cover turning the flag back off.** Once the flag has been on in production, some orders will have `split_payment_ref` set. Confirm that refunds, order views, reconciliation and the single-payment code still handle those orders after the flag is turned off. Add a CI case for "flag off, existing split-payment orders present."

5. **Confirm deploy ordering and migration rollback.** Make sure the migration runs before any code that references the column, including ORM models that select all columns. Note whether the column will be dropped if 4.12 is rolled back, or deliberately left in place.

6. **Small hardening for the later ticket.** Two weeks of staging traffic is a sensible gate. The enablement ticket could also use a gradual rollout (a percentage or cohort) rather than all-on, plus named metrics and alerts that would trigger turning it off.

None of these block the release as written. They make the migration safer and make the later flag flip, and any reversal, predictable.

VERDICT: GO_WITH_CHANGES