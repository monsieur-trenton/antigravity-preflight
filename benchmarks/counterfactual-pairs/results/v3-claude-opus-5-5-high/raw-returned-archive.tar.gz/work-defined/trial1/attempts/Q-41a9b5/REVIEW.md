# Review: Release 4.12 unique constraint on customers (tenant_id, email)

## Main issue: the success of the gating step is never checked

The runbook makes this constraint a release gate. If it can't be applied, 4.12 doesn't ship. The plan has no step that checks whether it can be applied.

- **Rows from 4.9 onward** are protected by the tenant-lock check in the write path, so they should have no duplicates.
- **Rows from before 4.9** have never been checked. Nothing in the plan shows that `(tenant_id, email)` is unique across them. Release 4.9 added a duplicate-refusing check, which suggests duplicates were possible before then.
- **If even one duplicate pair exists**, `CREATE UNIQUE INDEX CONCURRENTLY` will fail. This would happen after a long build on 38M rows, possibly hours into the release window. The constraint can't be attached, and the runbook aborts the release.

The plan as written depends on an assumption nobody has checked, and it fails if that assumption is wrong. I can't tell you whether duplicates exist; nobody can until someone looks. That uncertainty is the problem. You don't need to wait for the build to find out, because one query answers it.

## Secondary issues

1. **A failed concurrent build leaves an `INVALID` index behind.** It is still updated on every write to a hot 38M-row table. Depending on how far the build got, it can also reject inserts that collide with existing duplicates. So a failed attempt can affect production even though the release is aborted. The plan needs a cleanup step for this case.
2. **`DROP INDEX IF EXISTS` is not concurrent.** It does nothing on the first run. On a retry after a failed build, it drops the invalid index under an `ACCESS EXCLUSIVE` lock on `customers`, which blocks reads and writes while it waits for and holds the lock. Use `DROP INDEX CONCURRENTLY IF EXISTS`. Both statements must run outside a transaction block, so check that the migration tool doesn't wrap them in one.
3. **Matching rules between code and index.** Confirm that the 4.9 write path compares emails exactly as the index will: case-sensitivity, whitespace, and normalization. If the code compares case-insensitively and the index is on raw `email`, the guarantees don't match. The 4.12 sign-up error handling depends on them matching.
4. **Attaching the index.** `ALTER TABLE ... ADD CONSTRAINT ... UNIQUE USING INDEX` takes a short `ACCESS EXCLUSIVE` lock. Set a `lock_timeout` so it can't queue behind a long transaction and block the table.

## Required changes

1. **Before the release window,** run a duplicate check on production or an up-to-date replica:
   ```sql
   SELECT tenant_id, email, count(*)
   FROM customers
   GROUP BY tenant_id, email
   HAVING count(*) > 1;
   ```
   Use the same normalization the index will use.
2. **If it returns rows,** merge or fix those accounts in a separate, reviewed data fix. That fix will touch customer accounts, so it needs product and support sign-off. Then run the check again until it returns nothing.
3. **Change the migration's drop step** to `DROP INDEX CONCURRENTLY IF EXISTS`. Add a documented step for removing an `INVALID` index if the build fails.
4. **Add a `lock_timeout`** for the constraint-attach step.

Once the duplicate check returns nothing, the rest of the plan is sound. That includes the approach (build concurrently, then attach) and relying on the 4.9 write path for new rows.

VERDICT: NO_GO