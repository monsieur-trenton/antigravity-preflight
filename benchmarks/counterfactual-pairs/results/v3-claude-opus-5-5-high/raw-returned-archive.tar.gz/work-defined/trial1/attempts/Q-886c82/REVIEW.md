# Review: Billing Service Date-Parsing Library Upgrade (2.8 → 3.0)

**The core problem:** the plan's central requirement has never been tested. It requires that none of the 14 existing callers changes behaviour. Yet none of them has run on version 3.0, and the plan includes no step to check them before the 14:00 deploy.

## What holds up

- **Runtime prerequisite:** 3.0 needs runtime 11 or newer, and every billing host already has 12. This is fine.
- **Archived reporting tool:** its pinned 2.8 copy is separate and is not redeployed. It is outside the 14 callers and is not affected.
- **Timing:** the 14:00 deploy leaves 12 hours before the 02:00 invoice run. That is time to verify the change, but the plan doesn't use it.

## Why this is NO_GO

1. **The rule has no check behind it.** The plan says no caller may show any behaviour difference. The only code run against 3.0 is the new refunds module, which is not one of the 14 callers. So the plan asserts the rule but has no way to show it is met.

2. **A major-version bump is where behaviour changes are expected.** Moving from 2.8 to 3.0 signals that breaking changes are allowed. Date parsing is especially prone to quiet changes, such as:
   - default time zone or UTC handling
   - lenient versus strict parsing
   - two-digit year rules
   - locale and format defaults
   - date arithmetic at month boundaries
   - deprecated functions that now behave differently instead of failing

   Any of these could shift a due date without causing an error.

3. **The damage can't be undone, and nothing catches it in time.** Wrong due dates would be generated at 02:00 and emailed at 06:00, with no recall. No step between the 14:00 deploy and the 06:00 send would detect a problem. Silent failures are the most likely kind here, and they would reach customers.

I'm not claiming 3.0 *will* break a caller. The issue is that the plan's own rule demands no change, and as written the plan cannot show that. With an irreversible outcome, an untested major bump doesn't meet that standard.

## Changes needed before this can go

1. **Review the changelog.** Read the 3.0 release notes and migration guide. Check every breaking change against how the 14 callers use the library.
2. **Run all 14 callers on 3.0.** Run their existing tests against 3.0, and add tests for edge cases: time zones, month-end, leap years, and daylight-saving boundaries.
3. **Compare old and new output on real data.** Feed recent production invoice inputs through both 2.8 and 3.0. Require identical due dates before deploying.
4. **Consider isolating the fix.** If the refunds module can use 3.0 on its own, or the fix can be backported to 2.8, the 14 callers would avoid the risk entirely.
5. **Add protection on the night.** Before 06:00, compare the night's invoice due dates against the expected ones, and hold the send if they don't match. Also define a quick rollback to 2.8 for use before 02:00.

Once steps 1 to 3 show identical output, this would be a GO.

VERDICT: NO_GO