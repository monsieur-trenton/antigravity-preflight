# Review: Address Backfill Geocoding Plan

## Does the plan stay within the 50 requests/second limit?

Yes.

- **Worst case per worker:** 5 requests in any one-second window, enforced client-side.
- **Worst case total:** 8 workers × 5 = **40 requests per one-second window**. That is 10 below the 50 rps limit, a 20% margin.

Each of the other ways the rate could grow is ruled out by the plan:

| Risk | Status |
|---|---|
| Retry storms after HTTP 500s add traffic | Ruled out. Retries draw from the same per-worker limiter. |
| Worker count grows mid-run (autoscaling, restarts that double up) | Ruled out. The count is fixed at 8. |
| Other traffic on the same key | Ruled out. No other service or job uses the key during the run. |
| No coordination between workers | Not a problem. The 40 rps ceiling holds without coordination because each per-worker cap is fixed and the caps simply add up. |
| Window alignment | Not a problem. Each limiter caps *any* one-second window, so the sum across workers is at most 40 in any one-second window, whatever the vendor's window boundaries are. |

The remaining unmodeled effect is network jitter. Requests sent evenly could arrive bunched at the vendor. For that to push the vendor's count above 50, latency variation would have to approach a full second across many workers at once. The 10-request margin covers this in practice.

## Optional hardening (not required)

The suspension would also stop live checkout lookups, so these are cheap extra safeguards:

1. **Stop on 429 or rate-limit responses.** Have any worker that receives one halt the job, rather than back off and continue.
2. **Watch the vendor's usage dashboard** during the first few minutes to confirm observed traffic is about 40 rps.
3. **Plan around the runtime.** 3.2M rows ÷ 40 rps ≈ 80,000 s, about **22 hours**. Schedule and monitor with that in mind. Don't "speed it up" mid-run by adding workers, because that would break the fixed-count assumption the safety depends on.

None of these is needed to meet the stated requirement. The plan as written stays within the contracted rate.

VERDICT: GO