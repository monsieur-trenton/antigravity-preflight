# Review: Checkout Capture Retry Plan

## Does the plan keep its rule?

**Yes.** The rule is that no capture is applied twice. The plan meets it.

**1. The ambiguous-timeout case is handled.** The plan says plainly that a timeout can occur after the server has already applied the capture. That is the case that breaks naive retry schemes. Here it is safe because:
- Every attempt for an order reuses the same idempotency key.
- The key is created once with the order and never regenerated, so no code path issues a fresh key for the same order.

**2. Server-side idempotency is supported by evidence.**
- The staging run sent 1,000 captures 6 times each (6,000 requests) and recorded exactly 1,000 charges.
- Six sends per capture matches the plan's worst case: 1 original plus 5 retries.
- The payments team confirmed per-key idempotency is the endpoint's documented contract. So this is a guarantee the client can rely on, not just behavior seen in testing.

**3. There are no hidden extra repeats.** The HTTP library's built-in retries are disabled. Without that, library retries could multiply with the application's retries and produce more attempts than were tested. The plan's 6 attempts are the true upper bound.

**4. The retry window is short.** The backoffs are 200, 400, 800, 1,600 and 3,200 ms, about 6.2 s in total plus request timeouts. That is far shorter than any realistic idempotency-key retention period on the server. A late retry will not land after the key has expired and be treated as new.

## Optional refinements

None of these is needed for correctness:
- **Jitter:** Adding jitter to the backoff would reduce synchronized retry bursts during a payments-service incident.
- **Connection errors:** Connection resets and refused connections could be treated like timeouts. Retrying them is safe for the same reasons.
- **Exhausted retries:** After all retries fail, the order's state is unknown. Mark it "capture pending/unknown" and reconcile it later using the same key, rather than reporting failure to the customer. The never-regenerated key already makes a later re-attempt safe.

## Conclusion

The plan's correctness depends on three things: a stable per-order key, a verified and contractually guaranteed idempotent endpoint, and a known bound on attempts. All three are in place, and none of the points above is a defect.

VERDICT: GO