# Review: Shared Redis Cache for Rendered Dashboards

## The blocking problem: the cache key has no tenant

The plan's facts combine into a direct violation of its own isolation rule:

1. One Redis cluster is shared by all tenants.
2. Dashboard IDs restart at 1 in each tenant, so `42` exists in many tenants and means different data in each.
3. The key is `dash:{dashboard_id}:{range}`, with no tenant component.

**Failure scenario:**
- Tenant A requests dashboard 42 for range `7d`. It's a miss, so the handler renders A's data and stores it under `dash:42:7d`.
- Within 300 seconds, Tenant B requests its own dashboard 42 for `7d`.
- The handler derives the same key, `dash:42:7d`, gets a hit, and returns **Tenant A's dashboard to Tenant B**.

This is the cross-tenant leak the isolation rule forbids. It needs no attacker, bug, or race. It happens in normal use whenever two tenants view the same dashboard number and range within the TTL. Low IDs like 1, 2 and 3 exist in nearly every tenant, so collisions will be frequent.

The other safeguards don't help:
- **Gateway authentication** correctly identifies the caller as Tenant B, but the handler never uses `tenant_id` in the lookup, so the stamped identity has no effect on what is returned.
- **"Touches no key other than the one derived from the request"** is true, but the derived key is itself ambiguous across tenants.
- **Omitting user ID** is fine within a tenant. The problem is the missing tenant ID, not the missing user ID.

## Secondary problem: invalidation crosses tenants too

"Editing a dashboard removes its cached entries immediately" can only target `dash:42:*`. So:
- An edit in Tenant A evicts the cached dashboard 42 of every tenant. This causes needless cache churn and lets one tenant's activity affect others' performance.
- Worse, if Tenant B's entry currently holds A's leaked data, A's edit clears it, but the next B request may re-cache from either tenant depending on who misses first. The leak persists.

Separately, the plan doesn't say how "its cached entries" are found across all `{range}` values. `KEYS`/`SCAN` on a shared cluster is costly and, in Redis Cluster, spans nodes. A per-dashboard index set, or a version/generation counter in the key, is more reliable.

## Required changes

1. **Put the tenant in the key**, using the gateway-stamped value only and never a client-supplied header or parameter:
   `dash:{tenant_id}:{dashboard_id}:{range}`
   Make sure `range` is normalized and validated, e.g. an allow-list of ranges or canonical timestamps, so it can't contain `:` or inject key structure.
2. **Scope invalidation to the tenant**: delete only `dash:{tenant_id}:{dashboard_id}:*`. Implement it with a tracked set of keys per `(tenant, dashboard)` or a generation number, e.g. `dash:{tenant_id}:{dashboard_id}:v{gen}:{range}`, where an edit increments `gen`.
3. **Consider Redis Cluster hash tags** such as `dash:{t123:42}:7d`, so all ranges of one tenant's dashboard sit in the same slot and invalidation is a single-node operation.

## Recommended hardening (defense in depth)

- Store `tenant_id` inside the cached value and check it on read. Treat a mismatch as a miss and log an alert. This catches any future key-construction regression.
- Add a test with two tenants that both have dashboard 42 and the same range, and assert that neither ever receives the other's payload, including after edits.
- Put key construction in one helper function that takes `tenant_id` as a required argument, so call sites can't omit it.

## Summary

The caching approach (TTL, immediate invalidation on edit, no per-user keys) is reasonable. However, the key format as written causes cross-tenant data disclosure in ordinary use, which breaks the plan's own isolation rule. Adding the authenticated `tenant_id` to the key and scoping invalidation to the tenant would fix it.

VERDICT: NO_GO