# Review: Per-Request Logging for the Payments Gateway

## Blocking issue: bearer tokens are written to the logs

The plan logs every request header name and value at INFO, and redacts only `Cookie` and `X-Api-Key`. Callers send a bearer token in the `Authorization` header on every request, and that header is not redacted. So:

- **Every request writes a live bearer token** to the log line.
- **Production runs at INFO**, so this happens in production, not just in debug builds.
- **Logs go to the shared cluster**, where every engineer can search them for 90 days. Anyone with search access could collect valid tokens and replay them against the payments gateway.

This directly breaks the service's own rule that logs must never contain bearer tokens. The plan cannot ship as written.

## Other concerns

1. **The denylist approach is fragile.** Redacting named headers fails open. Any credential-bearing header not on the list leaks. Examples include `Proxy-Authorization`, `X-Auth-Token`, `X-Session-Id`, custom partner key headers, and headers added later by clients or upstream proxies.
2. **Response headers.** The plan only covers request headers. If response headers are ever logged, `Set-Cookie` would leak session cookies. The plan should state explicitly that response headers are excluded or covered by the same policy.
3. **Remediation of anything already logged.** If any version of this has run in a test or staging environment that ships to the shared cluster, those tokens should be purged and rotated.

## What is fine

- The access line (method, path without query string, status, latency, request ID) is reasonable. Dropping the query string avoids leaking keys or tokens passed as URL parameters.
- Not logging request or response bodies at any level is correct for a payments service.
- A random 128-bit request ID that isn't derived from caller input is good for tracing and leaks nothing.

## Recommended changes

- **Switch to an allowlist.** Log only headers known to be safe and useful for tracing slow upstream calls, such as `User-Agent`, `Content-Type`, `Content-Length`, `Accept`, and `X-Forwarded-For` (if your privacy policy allows it). Drop or redact everything else by default.
- **Always redact credentials.** At minimum, `Authorization`, `Proxy-Authorization`, `Cookie`, `Set-Cookie` and `X-Api-Key` should always be redacted, even if someone later adds them to the allowlist by mistake.
- **Consider whether full header dumps belong at INFO at all.** The stated goal is tracing slow upstream calls. The access line plus upstream timing (upstream host, upstream latency, retry count) would likely serve that better than request headers.
- **Add a test** that sends a request with a known bearer token and API key and asserts that neither string appears in the log output.

VERDICT: NO_GO