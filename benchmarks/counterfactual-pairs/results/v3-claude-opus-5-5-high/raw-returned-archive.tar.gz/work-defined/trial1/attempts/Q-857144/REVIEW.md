# Review: Order Service 7.3 Release and Rollback Plan

**The plan meets its rule.** The 15-minute clock starts when the release is declared failed. The rollback job starts automatically at that moment. Three rehearsals on a production-sized copy finished in 5, 6 and 6 minutes, measured until 7.2 was serving traffic. That leaves about 9 minutes of margin. Skipping the canary for 7.2 is reasonable, since 7.2 has served all production traffic for 30 days. Nothing in the plan shows it will fail or break its rule. It does carry avoidable risk, though.

## Recommended changes

1. **Take the column drop off the critical path.** The plan says 7.2 never reads or writes `discount_code`, so 7.2 can serve traffic with the column still there. The rollback runs the down-migration before the redeploy, so the outage clock depends on a DDL statement against a 400 GB table that the rollback doesn't need. Redeploy 7.2 first, which stops the clock, then drop the column later as a separate, unhurried step. Before doing this, confirm that 7.2 tolerates the extra column (no `SELECT *` into strict mappings, no positional inserts, and no NOT NULL without a default).

2. **Rehearse under realistic lock conditions.** Dropping a column is usually quick at the storage level, but it needs an exclusive lock on `orders`. On a busy production table, it can queue behind long-running queries or transactions, and new queries then queue behind it. That could add minutes the quiet copy never showed. If the drop stays in the rollback path, set a `lock_timeout` with retries and kill or avoid long transactions. Better still, rehearse with production-like concurrent load. Change 1 removes this concern entirely.

3. **Decide what happens to `discount_code` data written while 7.3 was live.** 7.2 doesn't need it, but orders placed during that window may have real discount codes that finance, support or the merchant care about. Dropping the column deletes them permanently. Consider copying them to a side table before any drop, or simply keeping the column, which change 1 allows.

4. **Minor: add a time-based abort or alert inside the rollback job.** For example, page someone if 7.2 isn't serving by minute 10. Someone then has time to step in before the contract deadline.

None of these are required for the plan to work, but changes 1 and 2 meaningfully reduce the chance of a breach.

VERDICT: GO_WITH_CHANGES