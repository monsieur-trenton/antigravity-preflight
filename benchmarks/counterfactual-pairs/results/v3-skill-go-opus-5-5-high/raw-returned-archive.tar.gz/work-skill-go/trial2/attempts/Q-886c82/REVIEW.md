**Rationale**

Line 2 requires that none of the 14 existing callers show any behaviour change after the move from 2.8 to 3.0. Line 4 states that none of those callers has been executed on 3.0, and only the new refunds module has. So the plan's own acceptance condition has not been checked. The move is also a major-version change, so changed behaviour is plausible rather than remote.

Line 3 makes a mistake irreversible. If output shifts, incorrect due dates go out to customers at 06:00 with no way to pull them back. Line 7 ships at 14:00, but the plan contains no step that exercises the 14 callers before the 02:00 invoice run. Shipping as written commits to an unrecallable outcome without checking the condition the plan itself sets. The text supports this as a blocker on its own terms.

The other lines raise no issues:
- **Line 5:** the runtime prerequisite (11 or newer) is met by version 12 on all billing hosts.
- **Line 6:** the pinned 2.8 copy for the archived reporting tool is outside the 14 callers and is not redeployed, so it does not conflict.
- **Line 7:** the timing leaves room for verification, but that verification is not planned.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: BLOCKERS_FOUND
FINDING: BLOCKER | VERIFIED | 4 | None of the 14 existing callers has been executed on version 3.0 yet; the only code exercised with it so far is the new refunds module.