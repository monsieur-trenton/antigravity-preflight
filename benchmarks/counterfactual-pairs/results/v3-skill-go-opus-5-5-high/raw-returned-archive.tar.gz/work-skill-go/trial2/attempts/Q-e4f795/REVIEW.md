**Rationale**

The size limit holds on the plan's own figures.

- **Batch size:** The endpoint refuses bodies over 5,000,000 bytes (line 1). A full 500-record batch is at most 2,050,000 bytes (line 5), and the envelope and separators add under 1,000 bytes (line 4). So the worst-case request is under 2,051,000 bytes, well below the limit. A refusal for size therefore cannot occur, and the strict no-resend rule (line 6) does not create a path to a missing invoice and failed reconciliation (line 7) on size grounds.
- **Uncapped notes field:** The notes field has no cap at the source (line 3). This would matter for open-ended input. However, the job reads a closed snapshot that stays fixed after month close (line 2), and every record in it was scanned (line 5). The 4,100-byte maximum is therefore a measured bound on the actual input, not an assumption.
- **Compression:** None is used (line 4), which the byte arithmetic already accounts for.
- **Timeout:** The 120-second timeout (line 8) exceeds the partner's stated 60-second worst case.
- **Internal consistency:** I found no conflicting lines or unsupported figures.

Recovery for non-size failures under the single-send rule could be made more robust. That would be an optional hardening, not a needed change, and the snapshot gives no text showing it is a defect.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: NO_BLOCKERS_FOUND