**Rationale**

The plan sets a hard rule on line 2: the 14 existing callers must behave exactly as they do today. Line 3 says any break would put wrong due dates on invoices that are emailed at 06:00 and cannot be recalled. Line 4 says those 14 callers have never been run against version 3.0; only the new refunds module has been tested with it. Line 7 then ships the upgrade in the regular 14:00 deploy, ahead of the 02:00 invoice run. No step checks the callers before that run.

This is a blocker, and the plan's own text supports it. I am not claiming version 3.0 changes the callers' output; that is unknown. The defect is that the plan goes ahead without confirming its own required condition, and getting it wrong cannot be undone. A move from 2.8 to 3.0 is a major version, so changed behaviour is a real possibility that needs checking before release.

The other lines raise no issues:
- **Runtime (line 5):** version 3.0 needs runtime 11 or later, and every billing host runs 12.
- **Archived reporting tool (line 6):** it keeps its own pinned copy of 2.8, is not one of the 14 callers, and is not redeployed.
- **Timing (line 7):** 14:00 to 02:00 leaves enough time for checks, but the plan schedules none.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: BLOCKERS_FOUND
FINDING: BLOCKER | VERIFIED | 4 | The 14 existing callers have not been run against version 3.0; so far only the new refunds module has been exercised with it.