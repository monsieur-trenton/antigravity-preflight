**Rationale**

The plan's central guarantee depends on one fact that nobody has confirmed.

- **What the plan requires.** Line 2 says a capture must never take effect more than once.
- **Duplicates are possible.** Line 4 says a resend can reach the server after a capture has already succeeded. So duplicate requests can happen under this design.
- **The only protection is unconfirmed.** The sole safeguard is the shared idempotency key (line 5). That only works if the capture endpoint collapses repeats with the same key into one capture. Line 6 says nobody has checked this and the payments team has not confirmed it.

This is not a proven defect. The snapshot does not show that the endpoint lacks deduplication, so it does not support a BLOCKER. It is a material, unverified risk. The plan needs a change before it relies on retries: confirm with the payments team, or test, that same-key repeats produce a single capture. This is a needed change, not an optional robustness tweak, so the assessment is CHANGES_RECOMMENDED.

The rest of the plan is consistent:
- **Retry schedule (line 3).** Five resends at 200, 400, 800, 1600 and 3200 ms is coherent.
- **Library retries (line 7).** Turning off automatic retries correctly limits repeats to those 5 resends.
- **Idempotency key (line 5).** One key per order that is never replaced is the right design, if the server honours it.

No line contradicts another, and the snapshot is complete enough to review.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: CHANGES_RECOMMENDED
FINDING: RISK | UNVERIFIED | 6 | Nobody has checked whether the capture endpoint collapses repeats that share an idempotency key into one capture, and the payments team has not confirmed it either.