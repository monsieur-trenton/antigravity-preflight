Rationale: The plan logs bearer tokens, which its own rule forbids.

- Line 2 says logs must never contain credentials, and it names bearer tokens explicitly.
- Line 3 says every request carries a bearer token in the Authorization header.
- Line 5 logs every request header name and value at INFO level. It redacts only Cookie and X-Api-Key, so the Authorization header and its bearer token are logged unredacted.
- Line 6 confirms production runs at INFO, so this logging happens in production.
- Line 7 makes it worse: any engineer in the company can search those logs for 90 days.

This conflict comes entirely from the snapshot's own lines, so it is a verified blocker. The fix is to redact Authorization too, or better, to log only an allowlist of headers. The other lines (4, 6 and 8) do not log credentials: there are no query strings, no bodies, and the request ID does not come from the token.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: BLOCKERS_FOUND
FINDING: BLOCKER | VERIFIED | 5 | At INFO level the logger also writes every request header name and value, with Cookie and X-Api-Key values replaced by the string '[redacted]'.