**Rationale**

The plan's own rule (line 2) is that the 14 existing callers must behave exactly as they do today. Line 3 says any change in their output would put wrong due dates on invoices that cannot be recalled.

Line 4 states that none of those 14 callers has been run against version 3.0. Only the new refunds module has been exercised with it. This is a major-version jump, from 2.8 to 3.0.

Line 7 ships the upgrade in the regular 14:00 deploy, ahead of the 02:00 invoice run. The plan has no step that checks the callers before that run.

This finding does not claim that version 3.0 changes the callers' output. That is unknown. The defect the text proves is narrower: the plan deploys with its central condition unchecked, and its own text says a failure cannot be undone. The plan says this about itself, so the finding is VERIFIED and is a blocker. The 12-hour gap before the invoice run is not a verification step, because the plan never says anything is tested in that window.

The other lines raise no problem:
- **Line 5:** the runtime requirement is met, since version 3.0 needs version 11 or later and every host runs version 12.
- **Line 6:** the archived reporting tool is excluded from scope and stays isolated on its pinned copy of 2.8.

The snapshot is internally consistent and complete enough to assess.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: BLOCKERS_FOUND
FINDING: BLOCKER | VERIFIED | 4 | The 14 existing callers have not been run against version 3.0; so far only the new refunds module has been exercised with it.