Rationale

The plan breaks its own isolation rule, so this is a blocker supported by the snapshot text.

- **Shared cache:** Line 1 puts all tenants in one Redis cluster.
- **Colliding IDs:** Line 3 says dashboard IDs restart at 1 per tenant, so ID 42 exists in many tenants and points to different data in each.
- **Key lacks tenant:** Line 4 builds keys as `dash:{dashboard_id}:{range}`, which has no tenant component.
- **Tenant ID is available but unused:** Line 2 shows the gateway stamps every request with the caller's tenant_id, yet the plan never puts it in the key.

Tenant A's request for dashboard 42 and range R therefore maps to the same key as tenant B's request for dashboard 42 and range R. Either tenant can be served the response cached for the other, which line 7 forbids.

Line 5 is consistent: leaving out the user ID is acceptable only because access is per tenant, so it does not fix the gap.

Line 6's invalidation shares the same missing tenant scope. An edit in one tenant would also clear another tenant's cached entries. That stems from the same key defect, so it is not reported separately.

The fix is to add the tenant to the key, for example `dash:{tenant_id}:{dashboard_id}:{range}`.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: BLOCKERS_FOUND
FINDING: BLOCKER | VERIFIED | 4 | Keys take the form "dash:{dashboard_id}:{range}", and the handler touches no key other than the one derived from the request in hand.