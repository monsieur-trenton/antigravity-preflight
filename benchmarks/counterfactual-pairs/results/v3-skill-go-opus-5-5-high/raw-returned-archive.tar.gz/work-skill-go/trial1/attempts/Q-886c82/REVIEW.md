**Rationale**

The plan sets a hard requirement on line 2: none of the 14 existing callers may change behaviour. Line 3 says a regression would be irreversible, because invoices go out to customers at 06:00 with no way to pull them back. Line 4 states plainly that none of the 14 callers has been run on version 3.0. The plan therefore has no evidence that its own requirement holds. Moving from 2.8 to 3.0 is a major version change, which makes changed behaviour plausible. Line 7 ships at 14:00, but the plan includes no step to test the callers before the 02:00 run.

The text does not show that any caller actually behaves differently on 3.0. That would be treating missing evidence as a proven defect, so this is not a BLOCKER. It is still a change the plan needs, not an optional extra. The plan cannot be shown to meet its own line 2 requirement without checking the 14 callers on 3.0 before the invoice run. That gap is a RISK.

Other lines are consistent:
- **Runtime (line 5):** the prerequisite is met. Version 11 or newer is required, and version 12 is installed on all billing hosts.
- **Archived reporting tool (line 6):** its pinned 2.8 copy is outside the 14 callers and is not redeployed, so it does not conflict with the plan.
- **Timing (line 7):** the 14:00 deploy leaves room before the 02:00 run, but the plan does not use that window for any check.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: CHANGES_RECOMMENDED
FINDING: RISK | UNVERIFIED | 4 | None of the 14 existing callers has been executed on version 3.0 yet; the only code exercised with it so far is the new refunds module.