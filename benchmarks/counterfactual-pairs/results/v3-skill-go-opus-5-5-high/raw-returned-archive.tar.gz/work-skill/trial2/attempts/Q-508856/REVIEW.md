Rationale

The snapshot does not prove a blocker, but its no-double-capture rule depends on a safeguard nobody has confirmed.

- **The duplicate scenario is real.** Line 2 says a second capture charges the customer twice and must never happen. Lines 3 and 4 say the client retries on timeout or 5xx, and that a retry can reach the server after the capture was already applied.
- **The mitigation depends on the server.** Line 5 gives every attempt for an order the same idempotency key. That key only prevents a second charge if the capture endpoint treats repeated requests with the same key as a single capture.
- **That behaviour is not confirmed.** Line 6 says the deduplication has not been checked and the payments team has not confirmed it.
- **Why this is a risk, not a blocker.** The text does not say the endpoint ignores the key, so there is no proven defect, only missing evidence. The plan should confirm server-side deduplication, and test it, before relying on these retries.
- **Line 7 is consistent.** It removes the HTTP library's own retries, so it adds no further source of repeats.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: CHANGES_RECOMMENDED
FINDING: RISK | UNVERIFIED | 6 | Whether the capture endpoint treats repeated requests with the same idempotency key as a single capture has not been checked, and the payments team has not confirmed it.