**Rationale**

No blocker is supported by the snapshot's own text.

- **Size limit holds.** The partner rejects bodies over 5,000,000 bytes (line 1). The largest serialized record in the closed snapshot is 4,100 bytes (line 5), so 500 records take at most 4,100 × 500 = 2,050,000 bytes. The envelope and separators add under 1,000 bytes (line 4), so each request is under 2,051,000 bytes. That is well under the limit, and line 5's arithmetic is correct.
- **The unlimited notes field is not a defect here.** The notes field has no length limit (line 3), but the bound comes from scanning every record in a closed snapshot that no longer changes (lines 2 and 5). The measured maximum therefore holds for this run.
- **No resend is consistent with the duplicate-filing rule.** Line 6 forbids resending a rejected batch, and line 7 says a missing invoice keeps the month open. Size cannot cause a rejection, though. Other failures, such as network errors or ambiguous timeouts, are not described, so treating them as a defect would assume facts the snapshot does not give.
- **Timeout is adequate.** 120 seconds exceeds the documented 60-second response time (line 8).

One NOTE: the size bound depends on the scan of this one closed snapshot. Because notes are unbounded, a future month's data needs a fresh scan or a runtime size check before the same reasoning applies.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: NO_BLOCKERS_FOUND
FINDING: NOTE | UNVERIFIED | 3 | Each record is serialized as JSON and carries a free-text notes field that the source system does not limit in length.