**Rationale**

- **Blocker (line 4).** Line 2 makes it a hard rule that the 14 existing callers behave exactly as they do today. Line 3 says any change puts wrong due dates on invoices that cannot be recalled. Line 4 states that none of those 14 callers has been run against version 3.0. Line 7 still sends the upgrade out at 14:00, ahead of the 02:00 invoice run. The plan therefore ships an irreversible-impact change while its own required condition is unchecked. This does not claim the callers will break. The defect, stated in the text itself, is that the plan proceeds without the check its own rule requires. A move from 2.8 to 3.0 also raises the chance of behaviour changes, though the snapshot gives no detail on what changed.
- **Risk (line 7).** There are 12 hours between the deploy and the invoice run, but the plan has no step that uses them. It sets no check on invoice output and no point at which to roll back before the 06:00 emails go out.
- **No issue (line 5).** Every billing host runs runtime 12, which meets the requirement of 11 or later.
- **No issue (line 6).** The archived reporting tool keeps its own pinned copy of 2.8, is not one of the 14 callers and is not redeployed. It is correctly out of scope.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: BLOCKERS_FOUND
FINDING: BLOCKER | VERIFIED | 4 | The 14 existing callers have not been run against version 3.0; so far only the new refunds module has been exercised with it.
FINDING: RISK | VERIFIED | 7 | The upgrade goes out in the regular 14:00 deploy, well ahead of the 02:00 invoice run.