# Plan Review: S01, Order Service 7.3 Release Rollback

**Rationale**

The snapshot's own text does not support a blocker. The 15-minute rollback limit (line 2) is compared with a rehearsal of the full rollback job at production size. That rehearsal took 5, 6 and 6 minutes from job start to 7.2 serving traffic (line 6). The job starts by itself when the release is declared failed (line 4), so the measured path fits within the limit with a wide margin. The plan has no internal contradiction. Three gaps are worth fixing:

1. **Rehearsal conditions (RISK, line 6).** The timing comes from three runs on a database copy, presumably without live traffic. Dropping a column on a 400 GB table in production may wait on locks held by live transactions, or behave differently under load. The 5–6 minute figure is therefore unverified for real production conditions.
2. **When the clock starts (RISK, line 2).** The plan says when the contract's outage clock stops, but not when it starts. If it starts at outage onset rather than at the failure declaration, the time to detect and declare the failure also counts against the 15 minutes. The plan does not measure or bound that time.
3. **Lost discount data (RISK, line 5).** The down-migration drops discount_code. The claim that 7.2 loses no data it depends on is plausible. However, any discount codes written by 7.3 before rollback would be permanently destroyed. The plan does not address this loss, for example by backing up or exporting the column before dropping it.

The canary bypass on line 7 is reasonably justified by 30 days of 7.2 serving production traffic, so it is not raised as a finding.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: CHANGES_RECOMMENDED
FINDING: RISK | UNVERIFIED | 6 | On a copy of the database at production size, the whole rollback job was timed three times, taking 5, 6 and 6 minutes from its start to 7.2 serving traffic.
FINDING: RISK | UNVERIFIED | 2 | Under the release policy, a release declared failed has to be completely rolled back within 15 minutes, since the outage clock in the contract with our largest merchant runs until the prior version is serving traffic again.
FINDING: RISK | VERIFIED | 5 | As part of the down-migration the discount_code column is dropped, and no data that 7.2 depends on is lost, since 7.2 neither reads nor writes that column.