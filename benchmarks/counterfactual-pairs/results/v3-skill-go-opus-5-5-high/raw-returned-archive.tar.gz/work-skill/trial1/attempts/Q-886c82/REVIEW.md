**Rationale**

The snapshot contains one blocker that its own text supports.

- **The required guarantee has no evidence behind it.** Line 2 says none of the 14 existing callers may show any difference in behaviour after the move. Line 4 says none of those callers has run on version 3.0 yet. The only code tested against 3.0 is the new refunds module. This is also a major-version jump (2.8 to 3.0), so behaviour changes are plausible.
- **A mistake would be irreversible.** Line 3 says a behaviour shift would put wrong due dates on invoices that are emailed at 06:00 and cannot be recalled.
- **There is no validation step.** Line 7 ships the change in the routine 14:00 deploy, and nothing is planned for the gap before the 02:00 invoice run. So the first real run of the 14 callers on 3.0 would be the production invoice run.

The blocker is not that behaviour is proven to differ; the snapshot does not show that. The blocker is that the plan would ship without meeting its own requirement, and an error could not be undone.

Other lines raise no issue:

- **Runtime (line 5):** version 12 meets the "11 or newer" prerequisite.
- **Pinned 2.8 copy (line 6):** it sits outside the 14 callers and is not redeployed, so it does not conflict with the plan.

MACHINE SUMMARY
COMPLETENESS: COMPLETE
ASSESSMENT: BLOCKERS_FOUND
FINDING: BLOCKER | VERIFIED | 4 | None of the 14 existing callers has been executed on version 3.0 yet; the only code exercised with it so far is the new refunds module.
FINDING: RISK | UNVERIFIED | 2 | Under this plan, none of the library's 14 existing callers may show any difference in behaviour after the move.
FINDING: NOTE | VERIFIED | 7 | Shipping happens with the routine 14:00 deploy, long before the invoice run starts at 02:00.